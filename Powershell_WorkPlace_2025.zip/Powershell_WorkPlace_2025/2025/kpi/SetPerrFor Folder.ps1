﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"

    #Set Config Parameters
    $SiteURL="https://smartholdingcom.sharepoint.com/sites/sbs_hr"
    $FolderRelativeURL="/sites/sbs_hr/Kpi/2023/Квартал 4"

    $SiteURL="https://smartholdingcom.sharepoint.com/sites/sh_portal_test"#"https://smartholdingcom.sharepoint.com/sites/sbs_hr"
    $FolderRelativeURL1="/sites/sh_portal_test/testLib/2024"
    $FolderRelativeURL2="/sites/sh_portal_test/testLib/2024/Квартал 2"
  #  https://smartholdingcom.sharepoint.com/:f:/r/sites/sh_portal_test/testLib/2024?csf=1&web=1&e=j9qGLi


try
{ 
    #Get Credentials to connect
    $Cred= Get-Credential

     $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
     $Ctx.Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)
      
     #Get the Folder
     $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderRelativeURL)
     $Ctx.Load($Folder)
     $Ctx.ExecuteQuery()

     $SubFolders=$Folder.Folders  
     $Ctx.Load($SubFolders)  
     $Ctx.ExecuteQuery() 

     $UsersPermissCollection = @()
     foreach($SubFolder in $SubFolders)
     {
        Write-Host $SubFolder.Name -f Yellow

        $SubFolder.ListItemAllFields.Retrieve("HasUniqueRoleAssignments")
        $Ctx.ExecuteQuery()

        if ($SubFolder.ListItemAllFields.HasUniqueRoleAssignments)
        {
            Write-host -ForegroundColor Green "Folder has unique Permissions:" $SubFolder.ListItemAllFields.HasUniqueRoleAssignments

            $RoleAssignments = $SubFolder.ListItemAllFields.RoleAssignments
            $Ctx.Load($RoleAssignments)
            $Ctx.ExecuteQuery()
            
            #$PermissionCollection = @()
            Foreach($RoleAssignment in $RoleAssignments)
            {
                $perm =$null
                $Ctx.Load($RoleAssignment.Member)
                $Ctx.executeQuery()

                $userInArr =  $UsersPermissCollection | Where-Object {$_.Name -like $RoleAssignment.Member.Title}

                if  (!$userInArr)
                {

                    #Get the User Type
                    $PermissionType = $RoleAssignment.Member.PrincipalType

                    $Ctx.Load($RoleAssignment.RoleDefinitionBindings)
                    $Ctx.ExecuteQuery()

                    $Name = $RoleAssignment.Member.Title # $RoleAssignment.Member.LoginName

                    Write-Host $Name " "  $PermissionType  -f Green
                    $perm=$RoleAssignment.RoleDefinitionBindings | Where-Object {$_.Name -like "Чтение"}#| Select -ExpandProperty Name  | Where-Object {$_.Name -like "Чтение"}
                    #$perm
                    Write-Host "    --------      "

                    if($perm -and ($PermissionType -eq "User") )
                    {
                        $Name= $RoleAssignment.Member.Title
                        $Login = $RoleAssignment.Member.LoginName
                        $PermissionType = $RoleAssignment.Member.PrincipalType
                        $Permissions = New-Object PSObject
                        $Permissions | Add-Member NoteProperty Name($Name)
                        $Permissions | Add-Member NoteProperty Login($Login)
                        $Permissions | Add-Member NoteProperty Type($PermissionType)
                        $UsersPermissCollection += $Permissions
                    }
                }

            }
    
        }
 
     }


     foreach($UserPerm in $UsersPermissCollection)
     {
        Write-Host "--- Start for " $UserPerm.Name

        try{
            $User = $Ctx.Web.EnsureUser($UserPerm.Login)
            $Ctx.Load($User)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.Web.RoleDefinitions.GetByName("Чтение")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)
          
            #add sharepoint online group to folder using powershell
            $UserPermissions  = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)

            Write-Host "end " -f Blue
        }
        catch
        {
            Write-Host " error set perm folder: $($_.Exception.Message)"
        }

        Write-Host "     ------        "

     }

}
catch
{
    Write-Host "error: $($_.Exception.Message)" -f Red
}
  
#Function to Get Folder Permissions
Function Get-SPOFolderPermission([String]$SiteURL, [String]$FolderRelativeURL)
{
    Try{
        #Setup the context
        $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
        $Ctx.Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)
      
        #Get the Folder
        $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderRelativeURL)
        $Ctx.Load($Folder)
        $Ctx.ExecuteQuery()

        $Folder.HasUniqueRoleAssignments

           $Folder.ListItemAllFields.Retrieve("HasUniqueRoleAssignments")
            $Ctx.ExecuteQuery()

             Write-host -ForegroundColor Green "Folder has unique Permissions:" $Folder.ListItemAllFields.HasUniqueRoleAssignments



 
        #Get permissions assigned to the Folder
        $RoleAssignments = $Folder.ListItemAllFields.RoleAssignments
        $Ctx.Load($RoleAssignments)
        $Ctx.ExecuteQuery()
 
        #Loop through each permission assigned and extract details
        $PermissionCollection = @()
        Foreach($RoleAssignment in $RoleAssignments)
        {
            $Ctx.Load($RoleAssignment.Member)
            $Ctx.executeQuery()
 
            #Get the User Type
            $PermissionType = $RoleAssignment.Member.PrincipalType
 
            #Get the Permission Levels assigned
            $Ctx.Load($RoleAssignment.RoleDefinitionBindings)
            $Ctx.ExecuteQuery()
            $PermissionLevels = ($RoleAssignment.RoleDefinitionBindings | Select -ExpandProperty Name) -join ","
             
            #Get the User/Group Name
            $Name = $RoleAssignment.Member.Title # $RoleAssignment.Member.LoginName
 
            #Add the Data to Object
            $Permissions = New-Object PSObject
            $Permissions | Add-Member NoteProperty Name($Name)
            $Permissions | Add-Member NoteProperty Type($PermissionType)
            $Permissions | Add-Member NoteProperty PermissionLevels($PermissionLevels)
            $PermissionCollection += $Permissions
        }
        Return $PermissionCollection
    }
    Catch {
    write-host -f Red "Error Getting Folder Permissions!" $_.Exception.Message
    }
}
  
#Set Config Parameters
$SiteURL="https://smartholdingcom.sharepoint.com/sites/sbs_hr"
$FolderRelativeURL="/sites/sbs_hr/Kpi/2024/Квартал 1"
  
#Get Credentials to connect
$Cred= Get-Credential
  
#Call the function to Get Folder Permissions
Get-SPOFolderPermission $SiteURL $FolderRelativeURL