﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
   

$SiteURL= "https://smartholdingcom-my.sharepoint.com/personal/s_gashenko_veres_com_ua"

#Get Credentials to connect
$Cred = Get-Credential

$Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.UserName,$Cred.Password)
      
$Lists = $Ctx.Web.Lists
        $Ctx.Load($Lists)
        $Ctx.ExecuteQuery()

$Lists |  Select -Property Title, BaseType

foreach($List in $Lists)
{
            #Get the List
            $List = $Ctx.Web.Lists.GetByTitle($List.Title)
            $Ctx.Load($List)
            $Ctx.ExecuteQuery()
            $Ctx.Load($List.RootFolder)
            $Ctx.ExecuteQuery()

            Write-Host "List $($List.Title) total  items: $($List.ItemCount) "
                        Write-Host "-----   $($List.RootFolder.ServerRelativeUrl) " -f Green
                         Write-Host "       "

}