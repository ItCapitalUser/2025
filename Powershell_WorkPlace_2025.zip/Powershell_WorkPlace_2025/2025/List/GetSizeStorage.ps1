﻿
$SiteURL= "https://smartholdingcom-my.sharepoint.com/personal/t_gumenyuk_veres_com_ua"

$Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
$Ctx.Credentials = $Credentials
$Site = $Ctx.Site
$Ctx.Load($Site)
 
#Get Storage Details
$Site.Retrieve("Usage")
$Ctx.ExecuteQuery()
$Site.Usage.Storage/1024

$Site.Usage.StoragePercentageUsed


   