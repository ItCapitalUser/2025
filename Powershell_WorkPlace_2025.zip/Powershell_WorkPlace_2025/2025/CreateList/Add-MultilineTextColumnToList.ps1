﻿Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
 
#Custom function to add column to list
Function Add-MultilineTextColumnToList()
{ 
    param
    (
        [Parameter(Mandatory=$true)] [string] $SiteURL,
        [Parameter(Mandatory=$true)] [string] $ListName,
        [Parameter(Mandatory=$true)] [string] $Name,
        [Parameter(Mandatory=$true)] [string] $DisplayName,
        [Parameter(Mandatory=$false)] [string] $Description=[string]::Empty,
        [Parameter(Mandatory=$false)] [string] $IsRequired = "FALSE",
        [Parameter(Mandatory=$false)] [string] $IsRichText="FALSE",
        [Parameter(Mandatory=$false)] [string] $NumLines = "6",
        [Parameter(Mandatory=$false)] [string] $EnhancedRichText = "FALSE"
    )
 
    #Generate new GUID for Field ID
    $FieldID = New-Guid
 
    Try {
        <#$Cred= Get-Credential
        $Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)
 
        #Setup the context
        $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
        $Ctx.Credentials = $Credentials#>
         
        #Get the List
        $List = $Ctx.Web.Lists.GetByTitle($ListName)
        $Ctx.Load($List)
        $Ctx.ExecuteQuery()
 
        #Check if the column exists in list already
        $Fields = $List.Fields
        $Ctx.Load($Fields)
        $Ctx.executeQuery()
        $NewField = $Fields | where { ($_.Internalname -eq $Name) -or ($_.Title -eq $DisplayName) }
        if($NewField -ne $NULL)  
        {
            Write-host "Column $Name already exists in the List!" -f Yellow
        }
        else
        {
            #Define XML for Field Schema
            if($EnhancedRichText -eq "TRUE") #Enhanced Rich Text Mode
            {
                $FieldSchema = "<Field Type='Note' ID='{$FieldID}' DisplayName='$DisplayName' Name='$Name' Description='$Description' Required='$IsRequired' NumLines='$NumLines' RichText='TRUE' RichTextMode='FullHtml' IsolateStyles='TRUE' />"
            }
            else  #Plain Text or Rich Text
            {
                $FieldSchema = "<Field Type='Note' ID='{$FieldID}' DisplayName='$DisplayName' Name='$Name' Description='$Description' Required='$IsRequired' NumLines='$NumLines' RichText='$IsRichText' />"
            }
             
            $NewField = $List.Fields.AddFieldAsXml($FieldSchema,$True,[Microsoft.SharePoint.Client.AddFieldOptions]::AddFieldInternalNameHint)
            $Ctx.ExecuteQuery()    
 
            Write-host "New Column Added to the List Successfully!" -ForegroundColor Green  
        }
    }
    Catch {
        write-host -f Red "Error Adding Column to List!" $_.Exception.Message
    }
} 
 
#Set parameter values
$ListName="Подані позови eng"

$Name="Claimant"
$DisplayName="Claimant"
$Description="Claimant"
$IsRichText="FALSE" #FALSE for Plain text / TRUE for Rich text
$EnhancedRichText="FALSE" #FALSE for Rich text / TRUE for Enhanced Rich Text, Takes Precedence over IsRichText parameter value
 
#Call the function to add column to list
Add-MultilineTextColumnToList -SiteURL $SiteURL -ListName $ListName -Name $Name -DisplayName $DisplayName -Description $Description -IsRichText $IsRichText -EnhancedRichText $EnhancedRichText

$Name="Respondent"
$DisplayName="Respondent"
$Description="Respondent"
$IsRichText="FALSE" #FALSE for Plain text / TRUE for Rich text
$EnhancedRichText="FALSE" #FALSE for Rich text / TRUE for Enhanced Rich Text, Takes Precedence over IsRichText parameter value
 
#Call the function to add column to list
Add-MultilineTextColumnToList -SiteURL $SiteURL -ListName $ListName -Name $Name -DisplayName $DisplayName -Description $Description -IsRichText $IsRichText -EnhancedRichText $EnhancedRichText

$Name="StatedClaims"
$DisplayName="Stated claims"
$Description="Stated claims"
$IsRichText="FALSE" #FALSE for Plain text / TRUE for Rich text
$EnhancedRichText="FALSE" #FALSE for Rich text / TRUE for Enhanced Rich Text, Takes Precedence over IsRichText parameter value

Add-MultilineTextColumnToList -SiteURL $SiteURL -ListName $ListName -Name $Name -DisplayName $DisplayName -Description $Description -IsRichText $IsRichText -EnhancedRichText $EnhancedRichText

$Name="Court"
$DisplayName="Court"
$Description="Court"
$IsRichText="FALSE" #FALSE for Plain text / TRUE for Rich text
$EnhancedRichText="FALSE" #FALSE for Rich text / TRUE for Enhanced Rich Text, Takes Precedence over IsRichText parameter value

Add-MultilineTextColumnToList -SiteURL $SiteURL -ListName $ListName -Name $Name -DisplayName $DisplayName -Description $Description -IsRichText $IsRichText -EnhancedRichText $EnhancedRichText
 
$Name="Status"
$DisplayName="Status"
$Description="Status"
$IsRichText="TRUE" #FALSE for Plain text / TRUE for Rich text
$EnhancedRichText="TRUE" #FALSE for Rich text / TRUE for Enhanced Rich Text, Takes Precedence over IsRichText parameter value
 
#Call the function to add column to list
Add-MultilineTextColumnToList -SiteURL $SiteURL -ListName $ListName -Name $Name -DisplayName $DisplayName -Description $Description -IsRichText $IsRichText -EnhancedRichText $EnhancedRichText

