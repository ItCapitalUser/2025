﻿#Get the List
        $List = $Ctx.Web.Lists.GetByTitle($ListName)
        $Ctx.Load($List)
        $Ctx.ExecuteQuery()

$ListItemInfo = New-Object Microsoft.SharePoint.Client.ListItemCreationInformation
        $ListItem = $List.AddItem($ListItemInfo)
        $ListItem["Title"] = "Test Title"
        $ListItem["SubjAppeal"]= "1;#Non-residents"
        $ListItem.Update()
        $Ctx.ExecuteQuery()

        $lookupValue = New-Object Microsoft.SharePoint.Client.FieldLookupValue
$lookupValue.LookupId = 4

$lookupValue.LookupValue="Non-residents"

$ListNameDict = "Субʼєкт оскарження"

$ListDic = $Ctx.Web.Lists.GetByTitle($ListNameDict)
        $Ctx.Load($ListDic)
        $Ctx.ExecuteQuery()

        $ListItems = $ListDic.GetItems([Microsoft.SharePoint.Client.CamlQuery]::CreateAllItemsQuery()) 
$Ctx.Load($ListItems)
$Ctx.ExecuteQuery()  

$collClaimant=@()
Foreach($item in $ListItems)
{
  Write-Host $item["Title"]

  $collClaimant += $item.Id.ToString()+";#"+$item["TitleEng"]
}

$Search = "*Owners and Trustees*"

 $collClaimant -like $Search