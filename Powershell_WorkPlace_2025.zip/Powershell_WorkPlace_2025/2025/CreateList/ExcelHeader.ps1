﻿$excelData = Import-Excel -Path "C:\1\Test.xlsx" -WorksheetName "Аркуш1" 

$ExcelObj = New-Object -comobject Excel.Application
$currDate = Get-Date -Format "ddMMyyy HHmm"
$ExcelWorkBook = $ExcelObj.Workbooks.Open("C:\1\Eng.xlsx")#"C:\Temp\Example2023Q3.xlsx")
$ExcelWorkBook = $ExcelObj.Workbooks.Open("C:\1\Test.xlsx")#"C:\Temp\Example2023Q3.xlsx")
$ExcelWorkBook = $ExcelObj.Workbooks.Open("C:\1\rrr.xlsx")#"C:\Temp\Example2023Q3.xlsx")

$ExcelWorkBook | fl Name, Path, Author

$ExcelWorkBook.Close($false)
$ExcelObj.Quit()


$ExcelWorkSheet = $ExcelWorkBook.Sheets.Item("Сurrent")
$ExcelWorkSheet.UsedRange.Cells(2,1).Text

    $Table = $ExcelWorkSheet.ListObjects.Item("dev") 

     $Data = $Table.Range.Value() Value2

     $DataW= $Table.Range.ListHeaderRows


     $headers = $Table.HeaderRowRange.Cells | Select-Object -ExpandProperty Text

     $Table.ListRows.Item("1")

     foreach ($row in  $Table.ListRows) {
    # Access cells within the row, e.g., $row.Range.Cells(1, 1).Value2
    Write-Host "Row: $($row.Index) - First Cell Value: $($row.Range.Column[1].Value2)"
}

\

     $Results = @()
    $Header = $Data[1,1] # Assuming the first row is the header
    for ($i = 1; $i -lt $Data.Length; $i++) {
        $Obj = [ordered]@{}
        for ($j = 0; $j -lt $Header.Length; $j++) {
            $Obj.($Header[$j]) = $Data[$i][$j]
        }
        $Results += [PSCustomObject]$Obj
    }

    $Data


    $usedRange = $ExcelWorkSheet.UsedRange
    $rowCount = $usedRange.Rows.Count
    for ($i = 1; $i -le $rowCount; $i++) {
    $row = $ExcelWorkSheet.Rows.Item($i)
    if ($row.OutlineLevel -gt 1) {
        Write-Output "Рядок $i має рівень структури: $($row.OutlineLevel)"
        $groupedRowsFound = $true
    }
}

if (-not $groupedRowsFound) {
    Write-Output "Згрупованих рядків не знайдено."
}