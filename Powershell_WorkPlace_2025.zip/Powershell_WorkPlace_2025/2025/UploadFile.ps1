﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
 
#Set parameter values
$SiteURL="https://smartholdingcom.sharepoint.com/sites/msteams_d6b661"
$SourceFilePath="C:\Temp\Contracts_SH.aspx"
$TargetFolderRelativeURL ="/sites/msteams_d6b661/SitePages"
 
#Setup Credentials to connect
$Cred= Get-Credential
$Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)
  
Try {
    #Setup the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = $Credentials
       
    #Get the Target Folder to upload
    $Web = $Ctx.Web
    $Ctx.Load($Web)
    $TargetFolder = $Web.GetFolderByServerRelativeUrl($TargetFolderRelativeURL)
    $Ctx.Load($TargetFolder)
    $Ctx.ExecuteQuery() 
 
    #Get the source file from disk
    $FileStream = ([System.IO.FileInfo] (Get-Item $SourceFilePath)).OpenRead()
    #Get File Name from source file path
    $SourceFileName = Split-path $SourceFilePath -leaf  
    $TargetFileURL = $TargetFolderRelativeURL+"/"+$SourceFileName
 
    #Upload the File to SharePoint Library Folder
    $FileCreationInfo = New-Object Microsoft.SharePoint.Client.FileCreationInformation
    $FileCreationInfo.Overwrite = $true
    $FileCreationInfo.ContentStream = $FileStream
    $FileCreationInfo.URL = $TargetFileURL
    $FileUploaded = $TargetFolder.Files.Add($FileCreationInfo)  
    $Ctx.ExecuteQuery()  
 
    #Close file stream
    $FileStream.Close()
    Write-host "File '$TargetFileURL' Uploaded Successfully!" -ForegroundColor Green
}
catch {
    write-host "Error Uploading File to Folder: $($_.Exception.Message)" -foregroundcolor Red
}