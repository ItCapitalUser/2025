﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
   
#Function to Check out a file from given URL
Function Checkout-Document($SiteURL, $FileRelativeURL, $Credentials)
{
 
    #Setup the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = $Credentials
 
    Try {
        #Try to get the File from URL
        $File = $Ctx.web.GetFileByServerRelativeUrl($FileRelativeURL)
        $Ctx.Load($File)
        $Ctx.ExecuteQuery()
         
        #check if the file is already checked out
        If($File.CheckOutType -ne "None")
        {
            write-host "File is already checked-out!" -f Yellow
            break
        }
        #Checkout the document
        $File.CheckIn("Checked in by Admin",  [Microsoft.SharePoint.Client.CheckinType]::MajorCheckIn)
        $Ctx.ExecuteQuery()
 
        write-host "Document has been checked-out successfully!" -f Green
    }
    Catch {
        write-host -f Red "Error checking out Document!" + $_.Exception.Message
    }    
}
 
#Set Variables for Site URL, List Name and Column Name
$SiteURL= "https://smartholdingcom.sharepoint.com/sites/cs/SHCD/shams"
$FileRelativeURL="/sites/cs/SHCD/shams/Garage/Doc/20141222_ТБ АМСТОР_ЕНЕРГО КОНСАЛТ_Дог_241215_Акт прийм-перед облад_v1.pdf"
 
#Setup Credentials to connect
$Cred = Get-Credential
$Cred = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.UserName,$Cred.Password)
 
#Call the function to Checkout file
Checkout-Document -SiteURL $SiteURL -FileRelativeURL $FileRelativeURL -Credentials $Cred

foreach($itemA in $DataSort)
    {
        Write-Host $itemA.RelativeURL -ForegroundColor Yellow
        $File = $Ctx.Web.GetFileByServerRelativeUrl($itemA.RelativeURL)
        $Ctx.Load($File)
        $Ctx.ExecuteQuery()

        $File.CheckIn("Checked in by Admin",  [Microsoft.SharePoint.Client.CheckinType]::MajorCheckIn)
        $Ctx.ExecuteQuery()

         write-host "Document has been checked-out successfully!" -f Green
    }
