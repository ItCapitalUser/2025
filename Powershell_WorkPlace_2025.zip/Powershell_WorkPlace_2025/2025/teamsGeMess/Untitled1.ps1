﻿$html = '<html><body><h1>Hello, world!</h1><p>This is a paragraph.</p></body></html>'
$wc = New-Object System.Net.WebClient
$text = $wc.DownloadString("data:text/html;charset=utf-8,$($html)")
$text = $text -replace '<[^>]+>', ''
$text = $text.Trim()
Write-Host $text

$html = '<p><at id="0">Сушко</at>&nbsp;<at id="1">Юлія</at>, <at id="2">Бєлова</at>&nbsp;<at id="3">Тетяна</at></p>
   
<p>Колеги, надсилаю пустий шаблон та приклад заповнення структури.</p>'
 $html=$message.Attachments.content
$htmlDoc = New-Object -ComObject "HTMLFile"
$htmlDoc.IHTMLDocument2_write($html)
$text = $htmlDoc.body.innerText
Write-Host $text








