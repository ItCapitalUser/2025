﻿ Connect-MgGraph -Scopes "ChannelMessage.Read.All"
 $Details = Get-MgContext
$Scopes = ($Details | Select -ExpandProperty Scopes) -Join ", "
$OrgName = (Get-MgOrganization).DisplayName

Write-Host "Microsoft Graph Connection Information"
Write-Host "--------------------------------------"
Write-Host ("Connected to Tenant {0} ({1}) as account {2}" -f $Details.TenantId, $OrgName, $Details.Account)
Write-Host ("The following permission scopes are defined: {0}" -f $Scopes)