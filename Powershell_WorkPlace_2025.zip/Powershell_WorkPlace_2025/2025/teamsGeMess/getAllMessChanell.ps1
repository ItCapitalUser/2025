﻿Connect-MgGraph -Scopes "Group.Read.All" 
 Connect-MgGraph -Scopes "ChannelMessage.Read.All"
Connect-MgGraph -Scopes "TeamSettings.Read.All"

$teamId = "07841d42-368a-4cd0-9262-9a5f5acab91c"
$channelId = "19:aX_5_A6edj67kw-OlhFqU4JiLgRM5GNp6uVaPedmf581@thread.tacv2"

$teamId = "42e43da1-ce27-45f3-a648-9a5fcc408fe6"
$channelId = "19:295c9c24cd9d4af381d57d3029b418fc@thread.tacv2"

class ChannelMessage {
    [string] $MessageId 
    [string] $PostOrReply
    [string] $Author
    [string] $Content
    [string] $CreatedDateTime
    [string] $LastModifiedDateTime
    [string] $DeletedDateTime
    [string] $ReplyToId
    [string] $MessageType
    [string] $Subject
    
    [string] $Summary
    [string] $Etag
    [string] $countReply
    [String] $Attachments


}

# Get all main messages in the channel
$channelMessages = Get-MgTeamChannelMessage -TeamId $teamId -ChannelId $channelId -All

$channelMessages1= $channelMessages| Where-Object -Property  MessageType -eq "message"

# Iterate through each main message to get its replies
foreach ($message in $channelMessages) {
    Write-Host "Main Message ID: $($message.Id)"
    Write-Host "Main Message Content: $($message.Body.Content)"

    # Get replies for the current main message
    $messageReplies = Get-MgTeamChannelMessageReply -TeamId $teamId -ChannelId $channelId -ChatMessageId $message.Id -All

    if ($messageReplies) {
        foreach ($reply in $messageReplies) {
            Write-Host "  Reply ID: $($reply.Id)"
            Write-Host "  Reply Content: $($reply.Body.Content)"
        }
    } else {
        Write-Host "  No replies found for this message."
    }
    Write-Host "---"
}

$idM= "1748347922059"
$mes  = Get-MgTeamChannelMessage -TeamId $teamId -ChannelId $channelId -ChatMessageId $idM

$messageReplies = Get-MgTeamChannelMessageReply -TeamId $teamId -ChannelId $channelId -ChatMessageId $idM -All

 $allMessages = @()
foreach ($message in $channelMessages1) {
    Write-Host "------ Start for Message ID: $($message.Id)"
    Write-Host "Main Message Content: $($message.Body.Content)"
    
       $authorName = $message.from.user.displayName
       $messageContent = $message.body.content
       $messageDate = $message.createdDateTime
       $allMessages += [PSCustomObject]@{
         MessageId = $message.id
         Author = $authorName
         Content = $messageContent
         Date = $messageDate
         

       }

    Write-Host "- - - End - - -"
}

 $allPosts = @()
foreach ($message in $channelMessages1) {
    Write-Host "------ Start for Message ID: $($message.Id)"
    Write-Host "Main Message Content: $($message.Body.Content)"
    
        $authorName = $message.from.user.displayName
        #$messageContent = $message.body.content
        $htmlDoc = New-Object -ComObject "HTMLFile"
        $htmlDoc.IHTMLDocument2_write($message.body.content)
        $messageContent = $htmlDoc.body.innerText

           $Post= [ChannelMessage]@{
             MessageId  = $message.id.ToString()
             PostOrReply="Post"
             Author = $authorName
             Content = $messageContent
             CreatedDateTime = $message.CreatedDateTime
             LastModifiedDateTime=$message.LastModifiedDateTime
             DeletedDateTime=$message.DeletedDateTime
             ReplyToId=$message.ReplyToId
             MessageType=$message.MessageType
             Subject=$message.Subject
             Summary=$message.Summary
             #Etag=$message.Etag
           }

           $messageReplies = Get-MgTeamChannelMessageReply -TeamId $teamId -ChannelId $channelId -ChatMessageId $message.Id -All

            if ($messageReplies) {
               <# foreach ($reply in $messageReplies) {
                    Write-Host "  Reply ID: $($reply.Id)"
                    Write-Host "  Reply Content: $($reply.Body.Content)"
                }#>

                $Post.countReply= $messageReplies.Count.ToString()
            } else {
                $Post.countReply= "  No replies found for this message."
            }

            if($message.Attachments)
            {
                Write-Host "Attachments" -f Yellow
                if ($message.Attachments.ContentUrl)
                {
                    Write-Host "ContentUrl" -f Green
                    $Post.Attachments =  $message.Attachments.ContentUrl -join ", "

                }
                elseif($message.Attachments.Content )
                {
                    Write-Host "Json" -f Blue
                    $AttachmentsContentJson=$message.Attachments.Content | ConvertFrom-Json
                    $Post.Attachments = $AttachmentsContentJson.type
                }
                else
                {
                $Post.Attachments ="No"
                }
                
            }
            else{
                $Post.Attachments ="No"
            }

            $allPosts += $Post

            if ($messageReplies) {

                $arrSortByCreateDate=$messageReplies | Sort-Object -Property CreatedDateTime 

                foreach ($reply in $arrSortByCreateDate) {
                
                   # $reply =  $messageReplies[$i]
                    Write-Host "  Reply ID: $($reply.Id)"
                    Write-Host "  Reply Content: $($reply.Body.Content)"

                    $htmlDocReply = New-Object -ComObject "HTMLFile"
                    $htmlDocReply.IHTMLDocument2_write($reply.body.content)
                    $ReplyContent = $htmlDocReply.body.innerText

                    $ReplyPost= [ChannelMessage]@{
                     MessageId  = $reply.id.ToString()
                     PostOrReply="Reply"
                     Author = $reply.from.user.displayName
                     Content = $ReplyContent
                     CreatedDateTime = $reply.CreatedDateTime
                     LastModifiedDateTime=$reply.LastModifiedDateTime
                     DeletedDateTime=$reply.DeletedDateTime
                     ReplyToId=$reply.ReplyToId
                     MessageType=$reply.MessageType
                     Subject=$reply.Subject
                     Summary=$reply.Summary
                     #Etag=$reply.Etag
                   }

                    if($reply.Attachments)
                    {
                        Write-Host "Attachments" -f Yellow
                        if ($reply.Attachments.ContentUrl)
                        {
                            Write-Host "ContentUrl" -f Green
                            $ReplyPost.Attachments =  $reply.Attachments.ContentUrl -join ", "

                        }
                        elseif($reply.Attachments.Content )
                        {
                            Write-Host "Json" -f Blue
                            $AttachmentsContentJson=$reply.Attachments.Content | ConvertFrom-Json
                            $ReplyPost.Attachments = $AttachmentsContentJson.type
                        }
                        else
                        {
                        $ReplyPost.Attachments ="No"
                        }
                
                    }
                    else{
                        $ReplyPost.Attachments ="No"
                    }

                   $allPosts += $ReplyPost
                }

            }

    Write-Host "- - - End - - -"
}

$ReportOutput = "C:\Temp\MesgTeamsGeneral_22.csv"

 $allPosts | Export-Csv $ReportOutput -NoTypeInformation -Encoding UTF8


