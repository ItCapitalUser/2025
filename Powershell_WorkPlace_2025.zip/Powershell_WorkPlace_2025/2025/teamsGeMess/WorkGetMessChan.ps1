﻿Install-Module Microsoft.Graph

  Connect-MgGraph -Scopes "ChannelMessage.Read.All"
  $teamId ="a93d0089-61e6-4d45-8d06-ee04fcef680e"# "3fa29ee0-d2c2-44f7-924d-a836ee3473b4"
  $channelId = "19:cb3a8c41ae844e54baf119971b9507dc@thread.tacv2"#"19%3Ac1f7d1e3954a45829a1c21d00b029bf3%40thread.tacv2"

   # Get the team by display name
   $team = Get-MgTeam -DisplayName "СХ-ІТ. Проєкт. SmartDocs"

   # Get the General channel
   $channel = Get-MgTeamChannel -TeamId $team.Id -DisplayName "General"

   $messages= Get-MgTeamChannelMessage -TeamId $teamId -ChannelId $channelId -Top 10

# Output the messages (or process them as needed)
$messages | Format-List

   $messages[0]

   Connect-MgGraph -Scopes "Group.Read.All" 
   Connect-MgGraph -Scopes "TeamSettings.Read.All"

    $message = Get-MgTeamChannelMessage -TeamId $teamId -ChannelId $channelId -ChatMessageId $messageId -Select "body"
   $jsonC= $message.Attachments.Content | ConvertFrom-Json
   $jsonC.type

   $message.Attachments.ContentUrl -join ", "
     if($message.Attachments.Content)
     {
     Write-Host "true"
     }
     else{
     Write-Host "false"
     }
    $message.id.ToString()



    $messageReplies = Get-MgTeamChannelMessageReply -TeamId $teamId -ChannelId $channelId -ChatMessageId $messageId -All
    $io = 
    foreach ($reply in $messageReplies) {
            Write-Host "  Reply ID: $($reply.Id)"
            Write-Host "  Reply Content: $($reply.Body.Content)"
        }

          $ttttt=$messageReplies | Sort-Object -Property CreatedDateTime -Descending 

    $messageId = "1752756255230"
    $message.

    # Access the content of the message body
    $messageBodyContent = $message.Body.Content
    Write-Host "Message Body: $messageBodyContent"

    $o=$message.Attachment
    foreach ($Attachment in $message.Attachments) {
        Write-Host "  Attachment Name: $($Attachment.Name)"
        Write-Host "  Attachment Type: $($Attachment.OdataType)"
        # For file attachments, you might want to get the content bytes
        # This requires an additional call if you need the actual file content
    }

    $message.From.User.DisplayName

    foreach($m in $messages)

    {
    Write-Host "----"
     $messageId = $m.Id 
     Write-Host $messageId -f Green
       $message = Get-MgTeamChannelMessage -TeamId $teamId -ChannelId $channelId -ChatMessageId  $messageId
       $messageBodyContent = $message.Body.Content
    Write-Host "Message Body: $messageBodyContent"

    }

     $team = Get-MgTeam -DisplayName "ИТ. Управление изменениями. Портал Lizard"
     Get-MgTeam -
   $channel = Get-MgTeamChannel -TeamId $team.Id -DisplayName "General"

   Get-MgTeam -Filter  "DisplayName eq 'ИТ. Управление изменениями. Портал Lizard'"