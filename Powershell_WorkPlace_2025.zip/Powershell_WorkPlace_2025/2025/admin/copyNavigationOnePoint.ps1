﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
    
#Config Parameters
$SiteURL="https://smartholdingcom.sharepoint.com/sites/sh_cabGIA"
#$SiteURL="https://smartholdingcom.sharepoint.com/sites/it_cabMAN"

$NewURL="https://smartholdingcom.sharepoint.com/sites/it_cabMAN" #"https://smartholdingcom.sharepoint.com/sites/it_testTemp1"
 
#Setup Credentials to connect
$Cred= Get-Credential
$Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)
 
#Setup the context
$Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
$Ctx.Credentials = $Credentials

$CtxNew = New-Object Microsoft.SharePoint.Client.ClientContext($NewURL)
$CtxNew.Credentials = $Credentials


Function Add-SPONavigationNode()
{
    Param(
        [Microsoft.SharePoint.Client.NavigationNodeCollection]$Navigation,
        [parameter(Mandatory=$false)][String]$ParentNodeTitle,
        [String]$Title,
        [String]$URL
    )
    #Populate New node data
    $NavigationNode = New-Object Microsoft.SharePoint.Client.NavigationNodeCreationInformation
    $NavigationNode.Title = $Title
    $NavigationNode.Url = $URL
    $NavigationNode.AsLastNode = $true

    #region Check level menu
   <# if($ParentNodeTitle -like "*/*")
    {
        $arrParentsNode = $ParentNodeTitle -split "/"
        $topNavigation = $Navigation
        for($i=0; $i -lt $arrParentsNode.count; $i++)
        {
            Write-Host "Part:" $arrParentsNode[$i]
            #$topNavigation
            $topNode = $topNavigation | Where-Object {$_.Title -eq $arrParentsNode[$i]}
            If($topNode -eq $null)
            {
                Write-Host "Don't find node $($arrParentsNode[$i])" -f Red
                return;
            }
            else
            {
                Write-Host "Get childrenNode" -f Green
                $Ctx.Load($topNode)
                $childrenNode = $topNode.Children
                $Ctx.Load($childrenNode)
                $Ctx.ExecuteQuery()

                $topNavigation = $childrenNode
            }
  
        }
        $ParentNode=$topNavigation
    }
    else
    {
        #Get the Parent Node
        $ParentNode = $Navigation | Where-Object {$_.Title -eq $ParentNodeTitle}
     }#>
    #endregion

    
 
    #Add New node to the navigation
    if( [string]::IsNullOrEmpty($ParentNodeTitle))
    {
        #Check if the Link with Title exists already
        $Node = $Navigation | Where-Object {$_.Title -eq $Title}
        If($Node -eq $Null)
        {
            #Add Link to Root node of the Navigation
            $CtxNew.Load($Navigation.Add($NavigationNode))
            $CtxNew.ExecuteQuery()
            Write-Host -f Green "New Navigation Node '$Title' Added to the Navigation Root!"
        }
        Else
        {
            Write-Host -f Yellow "Navigation Node '$Title' Already Exists in Root!"
        }
    }
    else
    {
        #Get the Parent Node
        #$Ctx.Load($ParentNode)
        #$Ctx.Load($ParentNode.Children)
        #$Ctx.ExecuteQuery()


        $arrParentsNode = $ParentNodeTitle -split "/"
        $topNavigation = $Navigation
        for($i=0; $i -lt $arrParentsNode.count; $i++)
        {
            Write-Host "Part:" $arrParentsNode[$i] -f Yellow
            #$topNavigation
            $topNode = $topNavigation | Where-Object {$_.Title -eq $arrParentsNode[$i]}
            If($topNode -eq $null)
            {
                Write-Host "Don't find node $($arrParentsNode[$i])" -f Red
                return;
            }
            else
            {
                Write-Host "Get childrenNode" -f Green
                $CtxNew.Load($topNode)
                $childrenNode = $topNode.Children
                $CtxNew.Load($childrenNode)
                $CtxNew.ExecuteQuery()

                $topNavigation = $childrenNode
                $topNavigation
                Write-Host "-------------"
            }
  
        }

  
        $Node = $topNavigation  | Where-Object {$_.Title -eq $Title}
        If($Node -eq $Null)
        {
            Write-Host "==========="
            #Add Link to Parent Node
            $CtxNew.Load($topNavigation.Add($NavigationNode))
            $CtxNew.ExecuteQuery()
            Write-Host -f Green "New Navigation Link '$Title' Added to the Parent '$ParentNodeTitle'!"
        }
        Else
        {
            Write-Host -f Yellow "Navigation Node '$Title' Already Exists in Parnet Node '$ParentNodeTitle'!"
        }
    }
}
 
#Get the Quick launch Navigation of the web 
$QuickLaunch = $Ctx.Web.Navigation.QuickLaunch
$Ctx.load($QuickLaunch)
$Ctx.ExecuteQuery()

$QuickLaunchNew = $CtxNew.Web.Navigation.QuickLaunch
$CtxNew.load($QuickLaunchNew)
$CtxNew.ExecuteQuery()

$FindItem = $QuickLaunchNew | Where-Object {$_.Title -like "Internet"}

if($FindItem -ne $null){
    Write-Host "Find"

    $CtxNew.Load($FindItem)
    $CtxNew.Load($FindItem.Children)
    $CtxNew.ExecuteQuery()

    $arrLinksFirstL = $FindItem.Children
     #Get Second level Links
    For($i = $arrLinksFirstL.Count - 1; $i -ge 0; $i--)
    {
        
        Write-Host  -f Green "Quick Launch Link '$($arrLinksFirstL[$i].Title)' Find!"
        $arrLinksSecondL = $arrLinksFirstL[$i].Children
        $CtxNew.Load($arrLinksSecondL)
        $CtxNew.ExecuteQuery()


        For($j = $arrLinksSecondL.Count - 1; $j -ge 0; $j--)
        {
            Write-Host  -f Blue "Quick Launch Link '$($arrLinksSecondL[$j].Title)' Find!"

            $arrLinksSecondL[$j].DeleteObject()
            $CtxNew.ExecuteQuery()
            Write-Host  " ------- Removed " 
        }

        $arrLinksFirstL[$i].DeleteObject()
        $CtxNew.ExecuteQuery()
        Write-Host  " ------- Removed First" 

        
    }

}else{
    Write-Host "Null"

}

$FindItemPrototype = $QuickLaunch | Where-Object {$_.Title -like "Internet"}

 
#Loop through Each link in Quick Launch Navigation
ForEach($QuickLaunchLink in $FindItemPrototype)
{
    $Ctx.Load($QuickLaunchLink)
    $Ctx.Load($QuickLaunchLink.Children)
    $Ctx.ExecuteQuery()

    $Title = $QuickLaunchLink.Title
     $URL= $QuickLaunchLink.Url


    Write-Host -f Green " ------ Quick Launch Link: '$($Title)' Start!"
    if($Title -like "Pages")
    {
    }
    else
    {
  <# $NavigationNode = New-Object Microsoft.SharePoint.Client.NavigationNodeCreationInformation
    $NavigationNode.Title = $Title
    #$NavigationNode.Url = $URL
    $NavigationNode.AsLastNode = $true

    $CtxNew.Load($QuickLaunchNew.Add($NavigationNode))
    $CtxNew.ExecuteQuery()#>
    }

 
    $FirstNode =  $Title
 
    #Get Second level Links
    Foreach($Link in $QuickLaunchLink.Children)
    {
        $Ctx.Load($Link)
        $Ctx.ExecuteQuery()

        # Write-Host  -f Green "Quick Launch Link '$($Link.Title)' Updated!"

         $SecondNode = $Link.Title
         $URLCh1= $Link.Url


        #Add-SPONavigationNode -Navigation $QuickLaunchNew -ParentNodeTitle  $FirstNode  -Title $SecondNode -URL $URLCh1
        $ParentNode = $QuickLaunchNew | Where-Object {$_.Title -eq $FirstNode}
        $CtxNew.Load($ParentNode)
        $CtxNew.Load($ParentNode.Children)
        $CtxNew.ExecuteQuery()

        $NavigationNodeCh1 = New-Object Microsoft.SharePoint.Client.NavigationNodeCreationInformation
        $NavigationNodeCh1.Title = $SecondNode
        $NavigationNodeCh1.Url = $URLCh1
        $NavigationNodeCh1.AsLastNode = $true
  
         
            #Add Link to Parent Node
            $CtxNew.Load($ParentNode.Children.Add($NavigationNodeCh1))
            $CtxNew.ExecuteQuery()
            Write-Host -f Green "New Navigation Link '$SecondNode' Added !"
       


        $Ctx.Load($Link.Children)
        $Ctx.ExecuteQuery()
        $nameParentNode= $FirstNode+"/"+$SecondNode

        Foreach($Link1 in $Link.Children)
        {
            $Ctx.Load($Link1)
            $Ctx.ExecuteQuery()

             $Titlech2 = $Link1.Title
             $URLCh2= $Link1.Url

             Write-Host  -f Blue "Quick Launch Link '$($Link1.Title)' Updated!"

                                        Add-SPONavigationNode -Navigation $QuickLaunchNew -ParentNodeTitle  $nameParentNode  -Title $Titlech2 -URL $URLCh2

          <#  $ParentNode = $QuickLaunchNew | Where-Object {$_.Title -eq $nameParentNode}
        $CtxNew.Load($ParentNode)
        $CtxNew.Load($ParentNode.Children)
        $CtxNew.ExecuteQuery()

        $NavigationNodeCh1 = New-Object Microsoft.SharePoint.Client.NavigationNodeCreationInformation
        $NavigationNodeCh1.Title = $SecondNode
        $NavigationNodeCh1.Url = $URLCh1
        $NavigationNodeCh1.AsLastNode = $true
  
         
            #Add Link to Parent Node
            $CtxNew.Load($ParentNode.Children.Add($NavigationNodeCh1))
            $CtxNew.ExecuteQuery()
            Write-Host -f Green "New Navigation Link '$SecondNode' Added !"#>


        }



    }
} 


ForEach($QuickLaunchLink in $QuickLaunch[1..$QuickLaunch.Count])
{
    $Ctx.Load($QuickLaunchLink)
    $Ctx.Load($QuickLaunchLink.Children)
    $Ctx.ExecuteQuery()

    $Title = $QuickLaunchLink.Title
     $URL= $QuickLaunchLink.Url
     

      if($Title -like "Pages")
      { Write-Host "ddddddd" 
      }


    Write-Host -f Green " ------ Quick Launch Link: '$($Title)' Start!"


} 
