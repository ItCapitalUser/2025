﻿﻿#Load SharePoint CSOM Assemblies  
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"  
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"  
   
Function Copy-AllFilesWithMetadata  
{  
  param  
    (  
        [Parameter(Mandatory=$true)] [Microsoft.SharePoint.Client.Folder] $SourceFolder,  
        [Parameter(Mandatory=$true)] [Microsoft.SharePoint.Client.Folder] $TargetFolder  
    )  
    Try {  
        #Get all Files from the source folder  
        $SourceFilesColl = $SourceFolder.Files  
        $SourceFolder.Context.Load($SourceFilesColl)  
        $SourceFolder.Context.ExecuteQuery()  
   
        #Iterate through each file and copy  
        Foreach($SourceFile in $SourceFilesColl)  
        {  
           Write-host -f blue "Copied File '$($SourceFile.ServerRelativeUrl)' start"  

            #Get the source file  
            $FileInfo = [Microsoft.SharePoint.Client.File]::OpenBinaryDirect($SourceFolder.Context, $SourceFile.ServerRelativeUrl)  
                         Write-host -f Yellow "1"  

            #Copy File to the Target location  
            $TargetFileURL = $TargetFolder.ServerRelativeUrl+"/"+$SourceFile.Name  
            #Write-host -f Yellow "Copied File '$($TargetFileURL)' creatt 111"  
            [Microsoft.SharePoint.Client.File]::SaveBinaryDirect($TargetFolder.Context, $TargetFileURL, $FileInfo.Stream,$True)  
             #Write-host -f Yellow "2"  
            #Copy Metadata field values  
            $SourceListItem = $SourceFile.ListItemAllFields  
            $SourceFolder.Context.Load($SourceListItem)  
            $SourceFolder.Context.ExecuteQuery()  
               #Write-host -f Yellow "3" 
            #Get the new file created  
            $TargetFile = $TargetFolder.Context.Web.GetFileByServerRelativeUrl($TargetFileURL)  
            $TargetListItem = $TargetFile.ListItemAllFields  
               Write-host -f Yellow "4" 
            #Set Metadata values from the source  
            $Author =$TargetFolder.Context.web.EnsureUser($SourceListItem["Author"].Email)  
            $TargetListItem["Author"] = $Author  
            $Editor =$TargetFolder.Context.web.EnsureUser($SourceListItem["Editor"].Email)  
            $TargetListItem["Editor"] = $Editor  
            $TargetListItem["Created"] = $SourceListItem["Created"]  
            $TargetListItem["Modified"] = $SourceListItem["Modified"]  
            $TargetListItem.Update()  
            $TargetFolder.Context.ExecuteQuery()  
   
            Write-host -f Green "Copied File '$($SourceFile.ServerRelativeUrl)' to '$TargetFileURL'"  
        }  
   
        #Process Sub Folders  
        $SubFolders = $SourceFolder.Folders  
        $SourceFolder.Context.Load($SubFolders)  
        $SourceFolder.Context.ExecuteQuery()  
        Foreach($SubFolder in $SubFolders)  
        {  
            If($SubFolder.Name -ne "Forms")  
            {  
                #Prepare Target Folder  
                Write-host "SubFolder :" $SubFolder.ServerRelativeUrl -f Magenta
                 <#Write-host "Folder :" $FolderS.ServerRelativeUrl -f Green
                Write-host "Folder :" $FolderTarget.ServerRelativeUrl -f Green#>
                #$TargetFolderURL = $SubFolder.ServerRelativeUrl -replace $SourceLibrary.RootFolder.ServerRelativeUrl, $TargetLibrary.RootFolder.ServerRelativeUrl  
                $TargetFolderURL = ($SubFolder.ServerRelativeUrl).Replace($FolderS.ServerRelativeUrl,$FolderTarget.ServerRelativeUrl)#$SubFolder.ServerRelativeUrl -replace $FolderS.ServerRelativeUrl, $FolderTarget.ServerRelativeUrl  
                Write-host "TargetFolderURL  :" $TargetFolderURL -f Magenta 
                Try {  
                        Write-host "Find folder" -f Blue 
                        $Folder=$TargetFolder.Context.web.GetFolderByServerRelativeUrl($TargetFolderURL)  
                        $TargetFolder.Context.load($Folder)  
                        $TargetFolder.Context.ExecuteQuery()  
                    }  
                catch {  
                        #Create Folder  
                        if(!$Folder.Exists)  
                        {  
                           Write-host "Start create Folder" -f Blue  
                            $TargetFolderURL  
                            $Folder=$TargetFolder.Context.web.Folders.Add($TargetFolderURL)  
                            $TargetFolder.Context.Load($Folder)  
                            $TargetFolder.Context.ExecuteQuery()  
                            Write-host "Folder Added:"$SubFolder.Name -f Blue  
                        }  
                    }  
                #Call the function recursively  
                Copy-AllFilesWithMetadata -SourceFolder $SubFolder -TargetFolder $Folder  
            }  
        }  
    }  
    Catch {  
        write-host -f Red "Error Copying File!" $_.Exception.Message  
    }  
}  
   
#Set Parameter values  
$SourceSiteURL="https://smartholdingcom.sharepoint.com/sites/SH_TOP_238-24"  
$TargetSiteURL="https://smartholdingcom.sharepoint.com/sites/SH_TOP_381-24.new"  
   
$SourceLibraryName="Documents"  
$TargetLibraryName="Documents"

$LoginName ="spsitecoladm@smart-holding.com"
$LoginPassword ="uZ#RJpSS2%U9!PR"
$SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
$Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)  
   
#Setup Credentials to connect  
<#$Cred= Get-Credential  
$Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)  #>
   
#Setup the contexts  
$SourceCtx = New-Object Microsoft.SharePoint.Client.ClientContext($SourceSiteURL)  
$SourceCtx.Credentials = $Credentials  
$TargetCtx = New-Object Microsoft.SharePoint.Client.ClientContext($TargetSiteURL)  
$TargetCtx.Credentials = $Credentials  
        
#Get the source library and Target Libraries  
$SourceLibrary = $SourceCtx.Web.Lists.GetByTitle($SourceLibraryName)  
$SourceCtx.Load($SourceLibrary)  
$SourceCtx.Load($SourceLibrary.RootFolder)  
$SourceCtx.ExecuteQuery()  
   
$TargetLibrary = $TargetCtx.Web.Lists.GetByTitle($TargetLibraryName)  
$TargetCtx.Load($TargetLibrary)  
$TargetCtx.Load($TargetLibrary.RootFolder)  
$TargetCtx.ExecuteQuery()  


$ServerRelativeUrl= "/sites/testEmptySite/testSearch1/Тест 23 02 23" 
$ServerRelativeUrl= "/sites/SH_TOP_381-24.new/Shared Documents/24. Аудит (поруки) new" 
 $FolderTarget = $TargetCtx.Web.GetFolderByServerRelativeUrl($ServerRelativeUrl)
    $TargetCtx.Load($FolderTarget)
    $TargetCtx.ExecuteQuery() 
    
$ServerRelativeUrl= "/sites/testEmptySite/testStudyL/folder1" 
$ServerRelativeUrl= "/sites/SH_TOP_238-24/Shared Documents/24. Аудит (поруки)" 
 $FolderS = $SourceCtx.Web.GetFolderByServerRelativeUrl($ServerRelativeUrl)
    $SourceCtx.Load($FolderS)
    $SourceCtx.ExecuteQuery() 
   
#Call the function  
Copy-AllFilesWithMetadata -SourceFolder $SourceLibrary.RootFolder -TargetFolder $TargetLibrary.RootFolder
Copy-AllFilesWithMetadata -SourceFolder $FolderS -TargetFolder $FolderTarget