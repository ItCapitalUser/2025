﻿#Load SharePoint CSOM Assemblies  
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"  
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"  

$SiteURL="https://smartholdingcom.sharepoint.com/sites/sbs_fs"#"https://smartholdingcom.sharepoint.com/sites/sbs_hr"
$CSVPath = "C:\Temp\Test_050325_1.csv"

$Cred= Get-Credential

class ItemReport {
    [string]$Title
    [string]$Type
    [string]$Url
    [int]$OrderN

}

try{

    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)
    
    $Web = $Ctx.Web
    $Ctx.Load($Web)
    $Ctx.ExecuteQuery()
    $SitePermissionCollection = @()
    
    $RoleAssignments =  $Ctx.Web.RoleAssignments
    $Ctx.Load($RoleAssignments)
    $Ctx.ExecuteQuery()
    
    $ElemSite = New-Object -TypeName ItemReport
    $ElemSite.Title = $Web.Title 
    $ElemSite.Url = $SiteURL
    $ElemSite.Type = "Site"

    Foreach($RoleAssignment in $RoleAssignments)
    {
        $Ctx.Load($RoleAssignment.Member)
        $Ctx.executeQuery()
 
        #Get the Permission Levels assigned
        $Ctx.Load($RoleAssignment.RoleDefinitionBindings)
        $Ctx.ExecuteQuery()           
             
            #Get the User/Group Name
            $Name = $RoleAssignment.Member.Title # $RoleAssignment.Member.LoginName

            Write-Host  $Name, $RoleAssignment.RoleDefinitionBindings.Count
 
            $count = $RoleAssignment.RoleDefinitionBindings.Count
            if ($count -gt 1)
            {
                $PermissionLevels = $RoleAssignment.RoleDefinitionBindings | Select -ExpandProperty Name
                $ElemPermissionLevel=$PermissionLevels[0]}
            else 
            { 
                $ElemPermissionLevel=$RoleAssignment.RoleDefinitionBindings | Select -ExpandProperty Name
            }

            $ElemSite | Add-Member -MemberType NoteProperty -Name $Name -Value $ElemPermissionLevel

            #Add the Data to Object
            <#$Permissions = New-Object PSObject
            $Permissions | Add-Member NoteProperty Name($Name)
            $Permissions | Add-Member NoteProperty Type($PermissionType)
            $Permissions | Add-Member NoteProperty PermissionLevels($ElemPermissionLevel)
            $PermissionCollection += $Permissions#>
        }

        $SitePermissionCollectionForTest=  $ElemPermissionCollection
         $SitePermissionCollection += $ElemPermissionCollection
         $CSVPath = "C:\Temp\Test_050325_1.csv"

          $SitePermissionCollection | Export-Csv -Path $CSVPath -Force -NoTypeInformation -Encoding UTF8
     $Lists = $Web.Lists
     $Ctx.Load($Lists)
     $Ctx.ExecuteQuery()

     $CustomLists =  $Lists| Where {$_.Hidden -eq $False}#  | Select -Property Title, BaseType

     $ListPermissionCollection = @()
     foreach($List in $CustomLists[0..2])
     {
        $List.Retrieve("HasUniqueRoleAssignments")
        $Ctx.ExecuteQuery()

         If( $List.HasUniqueRoleAssignments -eq $True)
         {
            Write-Host " Has Unique Perm" + $List.Title

         #Call the function to check permissions
            
             $RoleAssignments = $List.RoleAssignments
             $Ctx.Load($RoleAssignments)
             $Ctx.ExecuteQuery()

             $Ctx.Load($List.RootFolder)
             $Ctx.ExecuteQuery()

             $ElemList = New-Object -TypeName ItemReport
             $ElemList.Title = $List.Title 
             $ElemList.Url = $List.RootFolder.ServerRelativeUrl
             $ElemList.Type = $List.BaseType
             $ElemList.OrderN = 1

             $RoleAssignmentsList = $List.RoleAssignments
             $Ctx.Load($RoleAssignmentsList)
             $Ctx.ExecuteQuery()

             Foreach($RoleAssignmentList in $RoleAssignmentsList)
             {
                $Ctx.Load($RoleAssignmentList.Member)
                $Ctx.executeQuery()
 
                #Get the Permission Levels assigned
                $Ctx.Load($RoleAssignmentList.RoleDefinitionBindings)
                $Ctx.ExecuteQuery()           
             
                #Get the User/Group Name
                 $Name = $RoleAssignmentList.Member.Title # $RoleAssignment.Member.LoginName

                 Write-Host  $Name, $RoleAssignmentList.RoleDefinitionBindings.Count
 
                $count = $RoleAssignmentList.RoleDefinitionBindings.Count
                if ($count -gt 1)
                {
                    $PermissionLevels = $RoleAssignmentList.RoleDefinitionBindings | Select -ExpandProperty Name
                    $ElemPermissionLevelList=$PermissionLevels[0]}
                else 
                { 
                    $ElemPermissionLevelList=$RoleAssignmentList.RoleDefinitionBindings | Select -ExpandProperty Name
                }

                $ElemList | Add-Member -MemberType NoteProperty -Name $Name -Value $ElemPermissionLevelList

                #Add the Data to Object
                <#$Permissions = New-Object PSObject
                $Permissions | Add-Member NoteProperty Name($Name)
                $Permissions | Add-Member NoteProperty Type($PermissionType)
                $Permissions | Add-Member NoteProperty PermissionLevels($ElemPermissionLevel)
                $PermissionCollection += $Permissions#>
            }

             $ListPermissionCollection +=$ElemList 
  
         }
     }

     foreach($i in  $ListPermissionCollection){
     $SitePermissionCollection+= $i
     }


     $CSVPath = "C:\Temp\Test_050325_3.csv"

     $ido = $SitePermissionCollection  +$ListPermissionCollection

          $SitePermissionCollection | Export-Csv -Path $CSVPath -Force -NoTypeInformation -Encoding UTF8
    $test1= $SitePermissionCollection+ $ListPermissionCollection
}
catch
{
    Write-Host "error: $($_.Exception.Message)" -f Red
}
     
