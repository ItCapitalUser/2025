﻿class Tree {
    [int]$Height
    [int]$Age
    [string]$Color
}

$o = [Tree]@{
    Height=1
    Age=2
    Color='ccc'

}
$o | Add-Member -MemberType NoteProperty -Name 'MemberE' -Value 'eee'

$val1= 'MemberF'
$val2= 'MemberG'

$o | Add-Member -MemberType NoteProperty -Name $val1 -Value 'fff'
$o | Add-Member -MemberType NoteProperty -Name $val2

$o.$val1='kkk'

$PermissionCollection = @()
 $PermissionCollection += $o