﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
  
#Variables for Processing
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/sh_portal"
$GroupName="Sales Managers"
$PermissionLevel="Read"

$listGroup= @("Генеральний директор СХ", "Директор з юр. забезпечення", "Радники з юридичних питань", "Головнй юрисконсульт", "Юрисконсульти", "Радник з кримінально-правового захисту", 
"PM.Санкції FOUNDER", "Team.Санкції FOUNDER", "PM.База судових проваджень", "Team.База судових проваджень",
"PM.Харківобленерго",	"Team.Харківобленерго",	"PM.ІНТЕР АКТИВ", "Team.ІНТЕР АКТИВ",	"PM.Драбинка", "Team.Драбинка","PM.Океан", "Team.Океан", "PM.Проект А",	"Team.Проект А" 
)

$listGroup= @("Content Manager PR",	"Content Manager HR", "Content Manager Learning CG", "Content Manager Learning Finance", "Content Manager Learning HR",	
"Content Manager Learning IT", "Content Manager Learning Legal", "Content Manager Learning PR", "Content Manager Learning Security",
"Content Manager Regulations CG", "Content Manager Regulations Finance", "Content Manager Regulations HR", "Content Manager Regulations IT",
"Content Manager Regulations Legal", "Content Manager Regulations PR", "Content Manager Regulations Security"
)

 
#Setup Credentials to connect
$Cred = Get-Credential
$Cred = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.UserName,$Cred.Password)
 
Try {
    #Setup the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = $Cred
 
    #Get all existing groups of the site
    $Groups = $Ctx.Web.SiteGroups
    $Ctx.load($Groups)
    $Ctx.ExecuteQuery()
     
    #Get Group Names
    $GroupNames =  $Groups | Select -ExpandProperty Title
     
    #Check if the given group doesn't exist already
    #If($GroupNames -notcontains $GroupName)
    Foreach($GroupName in $listGroup)
    {
        #sharepoint online powershell create group
        $GroupInfo = New-Object Microsoft.SharePoint.Client.GroupCreationInformation
        $GroupInfo.Title = $GroupName     
        $Group = $Ctx.web.SiteGroups.Add($GroupInfo)
        $Ctx.ExecuteQuery()
 
        #Assign permission to the group
        $RoleDef = $Ctx.web.RoleDefinitions.GetByName($PermissionLevel)
        $RoleDefBind = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDefBind.Add($RoleDef)
        $Ctx.Load($Ctx.Web.RoleAssignments.Add($Group,$RoleDefBind))
        $Ctx.ExecuteQuery()
 
        write-host  -f Green "User Group $($GroupName)  has been Added Successfully!"
    }
   <# else
    {
        Write-host -f Yellow "Group Exists already!"
    }#>
}
Catch {
    write-host -f Red "Error Creating New user Group!" $_.Exception.Message
}