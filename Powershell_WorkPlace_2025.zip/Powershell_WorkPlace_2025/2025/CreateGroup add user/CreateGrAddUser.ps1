﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
  
#Variables for Processing
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/SH_SEC_024"
$GroupName="Менеджер департаменту безпеки СХ"
$PermissionLevel="Contribute"
$UserAccount = "yevhen.shevchenko@smart-holding.com"

$arr_userAccount = @("o.allahverdyan@veres.com.ua", "A.Galata@veres.com.ua")

 
#Setup Credentials to connect
$Cred = Get-Credential
$Cred = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.UserName,$Cred.Password)
 
Try {
    #Setup the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = $Cred
 
    #Get all existing groups of the site
    $Groups = $Ctx.Web.SiteGroups
    $Ctx.load($Groups)
    $Ctx.ExecuteQuery()
     
    #Get Group Names
    $GroupNames =  $Groups | Select -ExpandProperty Title
     
    #Check if the given group doesn't exist already
    If($GroupNames -notcontains $GroupName)
    {
        #sharepoint online powershell create group
        $GroupInfo = New-Object Microsoft.SharePoint.Client.GroupCreationInformation
        $GroupInfo.Title = $GroupName     
        $Group = $Ctx.web.SiteGroups.Add($GroupInfo)
        $Ctx.ExecuteQuery()
 
        #Assign permission to the group
        $RoleDef = $Ctx.web.RoleDefinitions.GetByName($PermissionLevel)
        $RoleDefBind = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDefBind.Add($RoleDef)
        $Ctx.Load($Ctx.Web.RoleAssignments.Add($Group,$RoleDefBind))
        $Ctx.ExecuteQuery()

         $User=$Ctx.web.EnsureUser($UserAccount)
 
    #Add user to the group
    $Result = $Group.Users.AddUser($User)
    $Ctx.Load($Result)
    $Ctx.ExecuteQuery()

    foreach($UserAccountItem in $arr_userAccount)
    {
        $User=$Ctx.web.EnsureUser($UserAccountItem)
 
        #Add user to the group
        $Result = $Group.Users.AddUser($User)
        $Ctx.Load($Result)
        $Ctx.ExecuteQuery()
    }
 
        write-host  -f Green "User Group has been Added Successfully!"
    }
    else
    {
        Write-host -f Yellow "Group Exists already!"
    }
}
Catch {
    write-host -f Red "Error Creating New user Group!" $_.Exception.Message
}