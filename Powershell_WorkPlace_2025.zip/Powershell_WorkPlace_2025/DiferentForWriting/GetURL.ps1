﻿$List.RootFolder.ServerRelativeUrl
$Ctx.Load($List.RootFolder)
$Ctx.ExecuteQuery()


        $Web.ServerRelativeUrl
        $List.ParentWebUrl