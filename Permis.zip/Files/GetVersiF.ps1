﻿Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
    
#Variables for Processing
$SiteUrl = "https://crescent.sharepoint.com/sites/marketing"
$FileURL = "https://smartholdingcom-my.sharepoint.com/personal/n_morozova_veres_com_ua/Documents/Рабочий стол/VG UNIVER.lnk"
 
#Get Credentials to connect
$Cred = Get-Credential
  
Try { 
    #Set up the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteUrl) 
    $Ctx.Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.UserName,$Cred.Password)
  
    #powershell sharepoint online get file by url
    $File = $Ctx.web.GetFileByUrl($FileURL)
    $Ctx.Load($File)
    $Ctx.ExecuteQuery()

    $Versions = $File.Versions
    $Ctx.Load($Versions)
    $Ctx.Load($Item.File) #To get File Name
    $Ctx.ExecuteQuery()

    $Versions.Count

    $VersionsToKeep= 5 #$Versions.Count/2

    While($File.Versions.Count -gt $VersionsToKeep)
            {
                $Versions[0].DeleteObject()
                $Ctx.ExecuteQuery()
                Write-host -f Green "`tDeleted Version:" $Versions[0].VersionLabel
     
                #Reload versions
                $Ctx.Load($File.Versions)
                $Ctx.ExecuteQuery()
            }


     
    Write-host "File Size:" ($File.Length/1KB)    
}
catch {
    write-host "Error: $($_.Exception.Message)" -Foregroundcolor Red
} 