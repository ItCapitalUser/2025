﻿#Config Parameters
$AdminSiteURL="https://M365x535786-admin.sharepoint.com"
$ReportInput="C:\Temp\SPOStorageQuota.csv"
 
#Get Credentials to connect to SharePoint Admin Center
$Cred = Get-Credential
 
#Connect to SharePoint Online Admin Center
Connect-SPOService -Url $AdminSiteURL –Credential $Cred
 
#Get all Updates Sites


$updatesites = Import-Csv -Path $ReportInput -Delimiter ","

Write-Host "Updating Site collections Found:"$updatesites.count -f Yellow
 
Foreach($Site in $updatesites)
{
    
    $newquota=[Int]$Site.NewQuota*1024
    $newwarnlevel=0.9*$newquota
    Write-Host "Processing Site Collection :"$Site.SiteURL,$newquota,$newwarnlevel -f Yellow

    Get-SPOSite -Identity $Site.SiteURL | Set-SPOSite -StorageQuota $newquota -StorageQuotaWarningLevel $newwarnlevel
 
}
 
 
Write-Host "Site Quota Update Successfully!" -f Green

