﻿Connect-AzureAD -Credential $Credential


$UserAccount =  Get-AzureADUser -Filter "userPrincipalName eq 'vira.chorna@it-capital.com.ua'" -ErrorAction SilentlyContinue
$UserAccount.CompanyName

Connect-MicrosoftTeams
$Credential = Get-Credential
Connect-ExchangeOnline -Credential $Credential -ShowBanner:$False
Connect-ExchangeOnline
Get-UnifiedGroup
	
Import-Module ExchangeOnlineManagement
$Teams =  Get-Team -Archived:$false


#Iterate through Each team and get SharePoint Site URL
ForEach ($Team in $Teams)
{
    #Collect SharePoint Sites of the teams
    [PSCustomObject] @{
        TeamName      = $Team.DisplayName
        SharePointURL = Get-UnifiedGroup -Identity $Team.GroupId | Select -ExpandProperty SharePointSiteURL
    }
}


#Read more: https://www.sharepointdiary.com/2020/02/find-sharepoint-sites-associated-with-microsoft-teams.html#ixzz8nfuFVYbo
    }
}

Get-Team -DisplayName "ИТ-IFS. Demo Planner" | Select -ExpandProperty SharePointSiteURL

Get-Team -DisplayName $Team | Select GroupId
$SPOURL = (Get-Team -Identity $Team.GroupId | Select -ExpandProperty SharePointSiteURL)
	
Get-Module -ListAvailable | Where-Object { $_.Name -eq "ExchangeOnlineManagement" }


$Teams.Count


$TenantID= "758e0274-4556-419d-be32-fddec46d6a04"
$ApplicationId = "30f9999e-20ce-4e18-bb00-cb03b7899ee3"

$password = "passwoed"

$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2("C:\Users\vira.chorna\Documents\power\cer\pnp.pfx",$password)
Connect-MicrosoftTeams -Certificate $cert -ApplicationId $ApplicationId -TenantId $TenantID