﻿$TenantAdminURL = "https://smartholdingcom-admin.sharepoint.com/"


$orgName = "smartholdingcom" 
$tenant = "$orgName.onmicrosoft.com"
$clientid="30f9999e-20ce-4e18-bb00-cb03b7899ee3"

    Connect-PnPOnline $TenantAdminURL -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")
Connect-MicrosoftTeams -Credential $cred -ErrorAction Stop

 $list = Get-PnPList -Identity "/Lists/DO_NOT_DELETE_SPLIST_TENANTADMIN_AGGREGATED_SITECO" -ErrorAction Stop
 Get-PnPField -List "DO_NOT_DELETE_SPLIST_TENANTADMIN_AGGREGATED_SITECOLLECTIONS"
    $sites = Get-PnPListItem -List $list -ErrorAction Stop | Select -Property

    $sites.Count

    $teams = Get-Team -ErrorAction Stop

    $Hashtable = @()
foreach($team in $teams)
{
  $channels = Get-TeamChannel -GroupId $team.GroupId
   
    if($team.Archived -eq $false)
    {
        $status = "Active"
    }
    if($team.Archived -eq $true)
    {
        $status = "Archived"
    }
    $connectedSPSite = $sites.FieldValues | Where-Object{$_.GroupId -eq $team.GroupId}
    $Hashtable += New-Object psobject -Property @{
    'DisplayName'           = $team.DisplayName;
    'Channels'              = $channels.Count;
    
    'Privacy'               = $team.Visibility;
    'Status'                = $status;
    'Description'           = $team.Description;
    'Classification'        = $team.Classification
    'Group ID'              = $team.GroupId;
    'MailNickName'          = $team.MailNickName;
    'Connected SP Site'     = $connectedSPSite.SiteUrl;
    'Storage Used'          = $connectedSPSite.StorageUsed;
    'Num Of Files'          = $connectedSPSite.NumOfFiles;
    }
  }

  $CSVFilePath = "C:\Users\vira.chorna\Documents\temp\AllTeams_041024.csv"

  $Hashtable| Export-Csv -Path $CSVFilePath -Force -NoTypeInformation -Encoding UTF8

  $SiteCollections = Get-PnPTenantSite | Select -Property  Title, Url, Template, GroupId, ArchiveStatus
  $CSVFilePath = "C:\Users\vira.chorna\Documents\temp\AllSitelGroup_041024_1.csv"

    $SiteCollections| Export-Csv -Path $CSVFilePath -Force -NoTypeInformation -Encoding UTF8
