﻿$orgName = "smartholdingcom" 
$tenant = "$orgName.onmicrosoft.com"


$adminURL = "https://$orgName-admin.sharepoint.com"

 

$clientid="30f9999e-20ce-4e18-bb00-cb03b7899ee3"

#Get user module pnp https://pnp.github.io/powershell/cmdlets/index.html
Connect-PnPOnline $adminURL -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")

$user = Get-PnPAzureADUser -Identity vira.chorna@it-capital.com.ua


#Get user module AzAccount
$ApplicationId = "30f9999e-20ce-4e18-bb00-cb03b7899ee3"


Connect-AzAccount -ApplicationId $ApplicationId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")

$userTest = Get-AzADUser -UserPrincipalName "l.gaiduchok@smartbs.com.ua" -Select CompanyName, Department
$userTest.CompanyName
$userTest.Department




#region get user Module AzureAD have error connect

Connect-AzureAD -Credential $Credential
$UserAccount =  Get-AzureADUser -Filter "userPrincipalName eq 'vira.chorna@it-capital.com.ua'" -ErrorAction SilentlyContinue
$UserAccount.CompanyName

	
Get-Module AzureAD -ListAvailable

$TenantID= "758e0274-4556-419d-be32-fddec46d6a04"

$serT="D9117DB09488F52B5C943F1C47280B9E8B955066"

 Connect-AzureAD -TenantId  $TenantID -ApplicationId $ApplicationId -CertificateThumbprint $serT
 

 get-module -listavailable

 #get user in AD 
 Import-Module ActiveDirectory

 help Get-ADUser

 Get-ADUser –Identity vira.chorna -properties Company, departure
