﻿2
3
4
Get-PnPHubSite | ForEach-Object {
    Write-host -f Yellow "Hub Site '$($_.Title)' URL: $($_.SiteUrl)"
    Get-PnPHubSiteChild -Identity $_.SiteUrl
}


#Read more: https://www.sharepointdiary.com/2019/12/get-all-sites-associated-with-sharepoint-online-hub-site-using-powershell.html#ixzz8numznZji