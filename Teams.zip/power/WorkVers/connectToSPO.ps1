﻿
#Config Variables
$AdminCenterURL = "https://smartholdingcom-admin.sharepoint.com/"
$SiteURL="https://smartholdingcom.sharepoint.com/sites/sbs_fs"
$SiteURL="https://smartholdingcom.sharepoint.com/sites/demo-09-2024"
$GroupName= "Team Site Members"
 
#Connect to SharePoint Online
Connect-SPOService -url $AdminCenterURL -Credential (Get-Credential)
   
#sharepoint online powershell get group members
Get-SPOUser -Site $SiteURL -Limit all | Format-Table -Wrap -AutoSize 
	
Get-SPOSiteGroup -Site $SiteURL
Get-SPOSiteGroup -site $SiteURL | Select Title, Roles, Users

Connect-PnPonline -Url $AdminCenterURL 
  
#Get the Root web
$Web = Get-PnPWeb -Includes RoleAssignments


#Read more: https://www.sharepointdiary.com/2019/01/sharepoint-online-get-all-groups-with-full-control-permissions.html#ixzz8mVdoWgGA


