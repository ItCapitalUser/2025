﻿$orgName = "smartholdingcom" 
$tenant = "$orgName.onmicrosoft.com"

 

$clientid="30f9999e-20ce-4e18-bb00-cb03b7899ee3"


$VaultName = "M365MGraphKV" # Azure Key Vault Name
$certName = "SPOAuditCert4app" # Certificate Name as in Azure Key Vault
 

# Tenant Site Collection URL

$adminURL = "https://$orgName-admin.sharepoint.com"

Connect-AzAccount


$secretSecureString = Get-AzKeyVaultSecret -VaultName $vaultName -Name $certName 


$bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secretSecureString.SecretValue)
$secretPlainText = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)