﻿
# Construct the authentication URL
$uri = "https://login.microsoftonline.com/ Jump $tenantId/oauth2/v2.0/token"
 
#The Client ID from App Registrations
$clientId = "9f9c4be5-53e1-4f15-9fed-3ea4807e2b"
 
#The Tenant ID from App Registrations
$tenantId = "758e0274-4556-419d-be32-fddec46d6a04"
 
#The Client ID from certificates and secrets section
$clientSecret = '-UBNrhrsD5rcA=ap=/5snjdkt5e4x-kG'
 
 
# Construct the body to be used in Invoke-WebRequest
$body = @{
    client_id     = $clientId
    scope         = "https://graph.microsoft.com/.default Jump "
    client_secret = $clientSecret
    grant_type    = "client_credentials"
}
 
# Get Authentication Token
$tokenRequest = Invoke-WebRequest -Method Post -Uri $uri -ContentType "application/x-www-form-urlencoded" -Body $body -UseBasicParsing
 
# Extract the Access Token
$token = ($tokenRequest.Content | ConvertFrom-Json).access_token
$token
