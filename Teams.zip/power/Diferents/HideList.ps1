﻿$listName = "Пользователи"
$site = "https://smartholdingcom.sharepoint.com/sites/sh_mong_test/economic_monitoring"

Connect-PnPOnline -Url $site -UseWebLogin
Set-PnPList -Identity $listName -Hidden $false

Disconnect-PnPOnline