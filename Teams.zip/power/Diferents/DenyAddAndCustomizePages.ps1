﻿get-sposite - identity "https://smartholdingcom.sharepoint.com/sites/hub_it" | FL

#Set Parameters
$AdminSiteURL="https://smartholdingcom-admin.sharepoint.com"
$SiteURL="https://smartholdingcom.sharepoint.com/sites/hub_it"
 
#Connect to SharePoint Online Admin Center
Connect-SPOService -Url $AdminSiteURL -Credential (Get-Credential)
 
#Get site properties
Get-SPOSite $SiteURL | FL

Set-SPOSite $SiteURL -DenyAddAndCustomizePages 0
