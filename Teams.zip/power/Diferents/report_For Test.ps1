﻿#pre-setup

# On the Browser

# https://login.microsoftonline.com/organizations/v2.0/adminconsent?client_id=31359c7f-bd7e-475c-86db-fdb8c937548e&scope=https://graph.microsoft.com/Group.Read.All

# https://login.microsoftonline.com/organizations/v2.0/adminconsent?client_id=31359c7f-bd7e-475c-86db-fdb8c937548e&scope=https://graph.microsoft.com/User.Read.All

# accept

 
$orgName = "smartholdingcom" 
 

# Tenant Site Collection URL

$tenantSiteURL = "https://$orgName-admin.sharepoint.com"
 

# Output Path

$outPath = "c:\temp"
 

# Tenant admin user Credentials

$UserName = "spsitecoladm@smart-holding.com"
$Password = "uZ#RJpSS2%U9!PR"
$SecurePassword= $Password | ConvertTo-SecureString -AsPlainText -Force
$credential=new-object -typename System.Management.Automation.PSCredential -argumentlist $UserName, $SecurePassword


 

 

#create variables for output file

 

$date = Get-Date -format yyyy-MM-dd

 

$time = Get-Date -format HH-mm-ss

 

$outputfilename = "SPPInventory" + $date + "_" + $time + ".csv"

 

$outputpath = $outPath + "\" + $outputfilename

 

$outputfilename_err = "SPPInventoryErr" + $date + "_" + $time + ".csv"

 

$outputpath_err = $outPath + "\" + $outputfilename_err

 

## Get List teams groups

Connect-PnPOnline -Scopes "Group.Read.All","User.Read.All" -Credentials $credential

#Store variables

$teamsgroups = @()

$allTeams = Get-PnPTeamsTeam

#Loop through each Team

 

foreach($team in $allTeams){

    #$allOwners = Get-PnPTeamsUser -Team $team.DisplayName -Role Owner

    $group= Get-PnPMicrosoft365Group -Identity $team.DisplayName
    
    $owner=""

    $o365groupowners = Get-PnPMicrosoft365GroupOwners -Identity $group.GroupId

                           For($i=0; $i -le ($o365groupowners.count-1); $i++)

                            {

                            $owner=$owner+$o365groupowners[$i].UserPrincipalName+" "

                            }

                            $owner=$owner.TrimEnd();

    $teamsgroups += [pscustomobject][ordered]@{

                Team = $team.DisplayName;

                SiteUrl=$group.SiteUrl;

                GroupID=$group.GroupId;

                Email=$group.Mail;

                Owner=$owner;

                Description=$group.Description;

            }

        }

# $teamsgroups - teams group list with needed parameters

 

Disconnect-PnPOnline

 

# Connects and Creates Context for sharepoint

 

Connect-PnPOnline -Url $tenantSiteURL -Credentials $credential

 

# Retrieve HubSites List

 

$hubsites = @()

 

$hubs=Get-PnPHubSite

 

foreach ($hub in $hubs){

 

$hubchild=Get-PnPHubSiteChild -Identity $hub.SiteUrl

 

$hubsites += [pscustomobject][ordered]@{

                HubName = $hub.Title;

                HubURL= $hub.SiteUrl;

                ChildSiteUrl= [pscustomobject]$hubchild;

            }

}

 

# Retrieves site collections on o365 site

 

    $sites = Get-PnPTenantSite -Detailed

 

    # Displays the site collections from tenant on the console

 

    Write-Host "There are:" $sites.count " site collections present" -ForegroundColor Green

   

    $workingcount=0

    $errorcount=0

 

    $data=@()

    $errorsites=@()

 

    Disconnect-PnPOnline

    # Loop through Sites

   

    

    

    

    foreach ($site in $sites) {

 

   

       # $sitevar= $site | Select-Object Title, Url, Owner, Template, StorageUsage, StorageMaximumLevel, SharingCapability, LastContentModifiedDate, Description

 
       
              

       Try  {

       $conn = Connect-PnPOnline -Url $site.Url -Credentials $credential -ReturnConnection

       write-host $site.Url "- connected" -ForegroundColor White

        #| Select-Object Title, Url, Owner, Template, StorageUsage, StorageMaximumLevel, SharingCapability, LastContentModifiedDate, Description

       
        #check list presence

 

        $list=Get-PnPList -Identity 'Audits parameters' -Connection $conn

 

        If ($list.Title -eq 'Audits parameters'){

 

            #get list parameters

            $libitems = (Get-PnPListItem -List 'Audits parameters' -Fields "Title","OwnerCompany","OwnerDepartment","TypeSite","Owner","UsersCompanies","InTeams","CentralSite","InHub","BusinessApp","NumberITIL","Archive","InYammer" -Connection $conn).FieldValues

 

              foreach($libitem in $libitems)

                {                                       

                    $owner=""
                   
                    $sitedescription=""

                    #looking for owners

                    $flag=$false

 

                    if ($site.Template -eq "GROUP#0") {

                        #check in teams,yammer,m365group

                        #find teams group name

                        $groupname=$site.Title

                       

                        for ($i=0; $i -le ($teamsgroups.Count-1); $i++){

                        $teamvar = $teamsgroups[$i]

                       

                        if  ($site.Url -eq $teamvar.SiteUrl) {

                       

                        $owner=$teamvar.Owner
                        

                        $sitedescription=$teamvar.Description

                        $flag=$true

                            break;

                        }

                        }

                       

                         if ($flag -eq $false) {

                          Connect-PnPOnline -Scopes "Group.Read.All","User.Read.All" -Credentials $credential                                             

                          $o365groupowners = Get-PnPMicrosoft365GroupOwners -Identity $groupname

                           For($i=0; $i -le ($o365groupowners.count-1); $i++)

                            {

                            $owner=$owner+$o365groupowners[$i].UserPrincipalName+" "

                            }

                            $owner=$owner.TrimEnd();
                          
                          $sitedescription=(Get-PnPMicrosoft365Group -Identity $groupname).Description   
                 

                         }

                      }

                    else {

                        $owner=$site.Owner

                        $web = Get-PnPWeb -Includes ParentWeb.Description -Connection $conn
                                                             
                        Get-PnPProperty -ClientObject $web -Property Url,Description
                         
                        $sitedescription=$web.Description
                      
                         }    

                   

                    #search hubsite name

                    $inhub=""

                     foreach($hubsite in $hubsites){

                        foreach ($child in $hubsite.ChildSiteUrl)

                        {

                           

                            if ($site.Url -eq [String]$child) {

                            $inhub=$hubsite.HubName

                            break;

                            }

                            else{

                                if ($site.Url -eq $hubsite.HubUrl){

                                $inhub=$hubsite.HubName

                                break;

                                }

 

                       

                            }

                           

                        }

                        if ($inhub.Length -lt 0)

                        {

                            break;

                        }

 

                    }

 

                    #create array record

                    $data=$data+@([pscustomobject]@{

                        Title=$site.Title;

                        Url=$site.Url;

                        Template=$site.Template;

                        Owner=$owner;

                        StorageUsage_GB=[string]([int][string]$site.StorageUsage/1024);

                        StorageMaximumLevel_GB=[string]([int]$site.StorageMaximumLevel/1024);

                        SharingCapability=$site.SharingCapability;

                        LastContentModifiedDate=$site.LastContentModifiedDate;

                        Description=$sitedescription;

                        OwnerCompany=[string]$libitem["OwnerCompany"].Label;

                        OwnerDepartment=[string]$libitem["OwnerDepartment"].Label;

                        TypeSite=[string]$libitem["TypeSite"].Label;

                        OwnerInternal=$libitem["Owner"].LookupValue;

                        UsersCompanies=[string]$libitem["UsersCompanies"].Label;

                        InTeams=$libitem["InTeams"];

                        CentralSite=$libitem["CentralSite"];

                        InHub=$libitem["InHub"];

                        HubName=$inhub;

                        BusinessApp=$libitem["BusinessApp"];

                        NumberITIL=$libitem["NumberITIL"];

                        Archive=$libitem["Archive"];

                        InYammer=$libitem["InYammer"];

                        })

 

                       

 

                $workingcount=$workingcount+1

 

                }

        }

        else {

         write-host $site.Url "- haven't system list" -ForegroundColor Red

       $errorcount=$errorcount+1

       $errorsites=$errorsites+@([pscustomobject]@{

                        Title=$site.Title;

                        Url=$site.Url;

                        Reason="Haven't system list";

                        })

        }

Disconnect-PnPOnline

}

       Catch [Exception] {

       write-host $site.Url $Error[0] -ForegroundColor Red

       $errorcount=$errorcount+1

       $errorsites=$errorsites+@([pscustomobject]@{

                        Title=$site.Title;

                        Url=$site.Url;

                        Reason=$Error[0];

                        })

       }

 

 }

 

# Write final csv file

 

$data | export-csv $outputpath -Delimiter ";" -Encoding UTF8

 

if ($errorcount -gt 0) {

$errorsites | export-csv $outputpath_err -Delimiter ";" -Encoding UTF8

}

 

 

# Display Site Collection Inventory complete

Write-Host "There are working " $workingcount " site collections" -ForegroundColor Green

Write-Host "There are connection error " $errorcount " site collections" -ForegroundColor Red