﻿Connect-PnPOnline -Url $SiteURL -Interactive
 
#Set the Page Layout 
#Set-PnPPage -Identity $PageName  -LayoutType $PageLayout

#Get-PnPPage -Identity "Home.aspx"


#Work this command
$PageName = "MShuranov"
$LoginUrl = "https://smartholdingcom.sharepoint.com/sites/sh_portal"

Connect-PnPOnline -Url $LoginUrl -UseWebLogin
Set-PnPClientSidePage -Identity $PageName -LayoutType Home