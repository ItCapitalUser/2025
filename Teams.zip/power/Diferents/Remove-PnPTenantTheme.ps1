﻿#Config Variables
$AdminSiteURL = "https://smartholdingcom-admin.sharepoint.com/"
$ThemeName = "Corporate Theme"
 
#Connect to PnP Online
Connect-PnPOnline -Url $AdminSiteURL -Interactive
 
#Get the Custom Theme
$Theme = Get-PnPTenantTheme | Where {$_.Name -eq $ThemeName}
 
If ($Theme.Count -eq 0) 
{ 
    Write-host "The specified Theme '$themeName' doesn't exist!" -ForegroundColor Yellow
    Break; 
}
 
#Remove the Theme
Remove-PnPTenantTheme -name $Theme.Name
Write-host "Custom Theme '$ThemeName' Removed Successfully!" -ForegroundColor Green