﻿
	
#Parameters
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/hub_veres"
$PageName = "test1"
$PageLayout = "Home" #Home, Article, SingleWebPartApp
 
#Connect to PnP Online
Connect-PnPOnline -Url $SiteURL -Interactive
 
#Set the Page Layout 
#Set-PnPPage -Identity $PageName  -LayoutType $PageLayout

#Get-PnPPage -Identity "Home.aspx"


#Work this command
$PageName = "WellDone"
$LoginUrl = "https://smartholdingcom.sharepoint.com/sites/hub_veres"

Connect-PnPOnline -Url $LoginUrl -UseWebLogin
Set-PnPClientSidePage -Identity $PageName -LayoutType Home