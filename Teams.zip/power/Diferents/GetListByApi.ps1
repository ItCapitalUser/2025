﻿#Parameters
$SiteURL= "https://smartholdingcom.sharepoint.com/sites/testEmptySite"
 
#Connect to the Site
Connect-PnPOnline -Url $SiteURL -Interactive
 
#Define the Rest Method
$RestMethodURL = $SiteURL+'/_api/web/lists?$select=Title'
 
#Invoke Rest Call to Get All Lists
$Lists = Invoke-PnPSPRestMethod -Url $RestMethodURL
$Lists.value

Disconnect-PnPOnline 