﻿#Variable for SharePoint Online Admin Center URL
$AdminSiteURL="https://smartholdingcom-admin.sharepoint.com/"
$CSVFile = "C:\Users\vira.chorna\Documents\temp\OneDrivesStorage_031025_Veres.csv"
  
#Connect to SharePoint Online Admin Center
Connect-SPOService -Url $AdminSiteURL -credential (Get-Credential)
 
#Get All OneDrive Sites usage details and export to CSV
$allOneDrive = Get-SPOSite -IncludePersonalSite $true -Limit all -Filter "Url -like '-my.sharepoint.com/personal/'" | Select URL, Owner, StorageQuota, StorageUsageCurrent, LastContentModifiedDate 

$OneDriveSites = Get-SPOSite -Limit ALL -includepersonalsite $True -Filter {"Owner -like '@veres.com.ua'" -and "Url -like '-my.sharepoint.com/personal/'"}



$allOneDrive | Export-Csv -Path $CSVFile -NoTypeInformation -Encoding UTF8

$Result=@()
# Get storage quota of each site
Foreach($Site in $OneDriveSites)
{
    $StorageUsageCurrent=$Site.StorageUsageCurrent/1024
    $StorageQuota=$Site.StorageQuota/1024
    $Result += New-Object PSObject -property @{
    URL = $Site.URL
    Owner= $Site.Owner
    Size_inMb = $Site.StorageUsageCurrent
    StorageQuota_inMb = $Site.StorageQuota
    Size_inGb = $Site.StorageUsageCurrent/1024
    StorageQuota_inGB = $Site.StorageQuota/1024
    InPercent =  [math]::Round(($StorageUsageCurrent*100)/$StorageQuota)
    }
}
 
$Result | Format-Table
 
#Export the data to CSV
$Result | Export-Csv $CSVFile  -NoTypeInformation


