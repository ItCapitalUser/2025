﻿$orgName = "smartholdingcom" 
$tenant = "$orgName.onmicrosoft.com"

 

$clientid="30f9999e-20ce-4e18-bb00-cb03b7899ee3"


$VaultName = "M365MGraphKV" # Azure Key Vault Name
$certName = "SPOAuditCert4app" # Certificate Name as in Azure Key Vault
 

# Tenant Site Collection URL

$adminURL = "https://$orgName-admin.sharepoint.com"

Connect-AzAccount


$secretSecureString = Get-AzKeyVaultSecret -VaultName $vaultName -Name $certName 


$bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secretSecureString.SecretValue)
$secretPlainText = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
 

# Output Path

$outPath = "C:\Users\vira.chorna\Documents\temp"

#create variables for output file

 

$date = Get-Date -format yyyy-MM-dd

 

$time = Get-Date -format HH-mm-ss

 

$outputfilename = "SPPInventory" + $date + "_" + $time + ".csv"

 

$outputpath = $outPath + "\" + $outputfilename

 

$outputfilename_err = "SPPInventoryErr" + $date + "_" + $time + ".csv"

 

$outputpath_err = $outPath + "\" + $outputfilename_err

#region Read Library Web permission
$siteUrlItSite= "https://smartholdingcom.sharepoint.com/sites/it_hub"
$ListName = "SPO" #!!!
$BatchSize = 500

Connect-PnPOnline $siteUrlItSite -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")


 $Ctx = Get-PnPContext
 $List =$Ctx.Web.Lists.GetByTitle($ListName)
      
    #Define CAML Query to Get List Items in batches
    $Query = New-Object Microsoft.SharePoint.Client.CamlQuery
    $Query.ViewXml ="
    <View Scope='RecursiveAll'>
        <Query>
            <OrderBy><FieldRef Name='ID' Ascending='TRUE'/></OrderBy>
        </Query>
        <RowLimit Paged='TRUE'>$BatchSize</RowLimit>
    </View>"
 
    $DataCollection = @()
    Do
    {
        #get List items
        $ListItems = $List.GetItems($Query) 
        $Ctx.Load($ListItems)
        $Ctx.ExecuteQuery() 
 
        #Iterate through each item in the document library
        ForEach($ListItem in $ListItems)
        {
        
            #Collect data        
            $Data = New-Object PSObject -Property ([Ordered] @{
                IdF=$ListItem.FieldValues.ID
                Name  = $ListItem.FieldValues.FileLeafRef
                RelativeURL = $ListItem.FieldValues.FileRef
                Len=$ListItem.FieldValues.FileRef.Length
                Type =  $ListItem.FileSystemObjectType
                CreatedBy =  $ListItem.FieldValues.Author.Email
                CreatedOn = $ListItem.FieldValues.Created
                ModifiedBy =  $ListItem.FieldValues.Editor.Email
                ModifiedOn = $ListItem.FieldValues.Modified
                FileSize = $ListItem.FieldValues.File_x0020_Size
            })
            $DataCollection += $Data
        }
        $Query.ListItemCollectionPosition = $ListItems.ListItemCollectionPosition
    }While($Query.ListItemCollectionPosition -ne $null)
    $DataCollection

    $nameFolder = 'msteams_6b2fba_798180-ExchangeOnline'

    $DataSort = $DataCollection  | Sort-Object Len -Descending | Where-Object { ($_.RelativeURL -like '*SPO/Reports/ExportSitePermissions/*' -and $_.Type -contains "Folder") -and $_.Name -like $nameFolder }
    $DataSort1 = $DataSort| Where-Object { $_.RelativeURL -like $nameFolder} #($_.RelativeURL -like '*SPO/Reports/ExportSitePermissions/*' -and $_.Type -contains "Folder") -and

    $CSVPath = "C:\Users\vira.chorna\Documents\temp\DocumentITDoc_250924_5.csv"
    $DataSort | Export-Csv -Path $CSVPath -Force -NoTypeInformation -Encoding UTF8

#endregion 


## Get List teams groups

#Connect-PnPOnline -Scopes "Group.Read.All","User.Read.All" -Credentials $credential

#Popov
#Connect-PnPOnline -ClientId $clientid -CertificateBase64Encoded $secretPlainText -url $adminURL  -Tenant $tenant

Connect-PnPOnline $adminURL -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")


#Store variables


$teamsgroups = @()

$allTeams = Get-PnPMicrosoft365Group -IncludeSiteUrl -IncludeClassification | Where-Object {$_.HasTeam -eq $true}

 

foreach($team in $allTeams){

    #$allOwners = Get-PnPTeamsUser -Team $team.DisplayName -Role Owner
    #$group= Get-PnPMicrosoft365Group -Identity $team.DisplayName

    #$group= Get-PnPMicrosoft365Group -Identity $team.GroupID

    #write-host $team.GroupId 
        
    $owner=""


     try{
        $o365groupowners = Get-PnPMicrosoft365GroupOwners -Identity $team.GroupId

    } 
    catch{
    $owner="no owner"
    Write-Host  $team.DisplayName "check2!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    }


     if ($o365groupowners -eq $null)
    {
    $owner="no owner"
    }
    else
    {
    

                           For($i=0; $i -le ($o365groupowners.count-1); $i++)

                            {

                            $owner=$owner+$o365groupowners[$i].UserPrincipalName+" "
                       

                            }

                            $owner=$owner.TrimEnd();
                            Write-Host $owner

      }

#write-host $o365groupowners.Count

    $teamsgroups += [pscustomobject][ordered]@{

                Team = $team.DisplayName;

                SiteUrl=$team.SiteUrl;

                GroupID=$team.GroupId;

                Email=$team.Mail;

                Owner=$owner;

                Description=$team.Description;

            }

        }

# $teamsgroups - teams group list with needed parameters

 

Disconnect-PnPOnline

 

# Connects and Creates Context for sharepoint

 

Connect-PnPOnline -ClientId $clientid -CertificateBase64Encoded $secretPlainText -url $adminURL  -Tenant $tenant
Connect-PnPOnline $adminURL -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")


 

# Retrieve HubSites List

 

$hubsites = @()

 

$hubs=Get-PnPHubSite

 

foreach ($hub in $hubs){

 

$hubchild=Get-PnPHubSiteChild -Identity $hub.SiteUrl

 

$hubsites += [pscustomobject][ordered]@{

                HubName = $hub.Title;

                HubURL= $hub.SiteUrl;

                ChildSiteUrl= [pscustomobject]$hubchild;

            }

}

 

# Retrieves site collections on o365 site

 

   $sites = Get-PnPTenantSite -Detailed
   #$sites = Get-SPOTenantSite -Detailed

 

    # Displays the site collections from tenant on the console

 

    Write-Host "There are:" $sites.count " site collections present" -ForegroundColor Green

   

    $workingcount=0

    $errorcount=0

 

    $data=@()

    $errorsites=@()

 

    Disconnect-PnPOnline

    # Loop through Sites

   

    

    

    

    foreach ($site in $sites) {

 

   

       # $sitevar= $site | Select-Object Title, Url, Owner, Template, StorageUsage, StorageMaximumLevel, SharingCapability, LastContentModifiedDate, Description

 
       
              

       Try  {

       #$conn = Connect-PnPOnline -Url $site.Url -Credentials $credential -ClientId $clientid -CertificateBase64Encoded $secretPlainText #-ReturnConnection
      # $conn = Connect-PnPOnline -ClientId $clientid -CertificateBase64Encoded $secretPlainText -url $site.Url  -Tenant $tenant
       $conn = Connect-PnPOnline -ClientId $clientId  -url $site.Url -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")


       write-host $site.Url "- connected" -ForegroundColor White

        #| Select-Object Title, Url, Owner, Template, StorageUsage, StorageMaximumLevel, SharingCapability, LastContentModifiedDate, Description
        #region Get Ownre
         if ($site.Template -eq "GROUP#0") {

                        #check in teams,yammer,m365group

                        #find teams group name

                        $groupname=$site.Title

                       

                        for ($i=0; $i -le ($teamsgroups.Count-1); $i++){

                        $teamvar = $teamsgroups[$i]

                        

                        if  ($site.Url -eq $teamvar.SiteUrl) {

                        

                        $owner=$teamvar.Owner
                        
                        $sitedescription=$teamvar.Description

                        $flag=$true

                            break;

                        }

                        }

                       

                         if ($flag -eq $false) {

                          #Connect-PnPOnline -ClientId $clientid -CertificateBase64Encoded $secretPlainText -url $adminURL  -Tenant $tenant
                          Connect-PnPOnline  -url $adminURL   -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")

                          $groupid = Get-PnPMicrosoft365Group -Identity $site.GroupId.ToString() -IncludeSiteUrl -IncludeClassification -IncludeHasTeam                                           

                          #$o365groupowners = Get-PnPMicrosoft365GroupOwners -Identity $groupname
                          $o365groupowners = Get-PnPMicrosoft365GroupOwners -Identity $groupid.GroupId

                           For($i=0; $i -le ($o365groupowners.count-1); $i++)

                            {

                            $owner=$owner+$o365groupowners[$i].UserPrincipalName+" "

                            }

                            $owner=$owner.TrimEnd();
                          
                          $sitedescription=$groupid.Description   
                 

                         }

                      }

                    else {

                        $owner=$site.Owner

                        $web = Get-PnPWeb -Includes ParentWeb.Description -Connection $conn
                                                             
                        Get-PnPProperty -ClientObject $web -Property Url,Description
                         
                        $sitedescription=$web.Description
                      
                         }  
        #endregion

        #region Get hub
                           write-host "3"
                    #search hubsite name

                    $inhub=""

                     foreach($hubsite in $hubsites){

                        foreach ($child in $hubsite.ChildSiteUrl)

                        {

                           

                            if ($site.Url -eq [String]$child) {

                            $inhub=$hubsite.HubName

                            break;

                            }

                            else{

                                if ($site.Url -eq $hubsite.HubUrl){

                                $inhub=$hubsite.HubName

                                break;

                                }

 

                       

                            }

                           

                        }

                        if ($inhub.Length -lt 0)

                        {

                            break;

                        }

 

                    }
        #endregion
       
        #check list presence

        

       $list=Get-PnPList -Identity 'Audits parameters' -Connection $conn

 

      If ($list.Title -eq 'Audits parameters'){

 

            #get list parameters

            $libitems = (Get-PnPListItem -List 'Audits parameters' -Fields "Title","OwnerCompany","OwnerDepartment","TypeSite","Owner","UsersCompanies","InTeams","CentralSite","InHub","BusinessApp","NumberITIL","Archive","InYammer" -Connection $conn).FieldValues

 
              write-host "1" -ForegroundColor Red
              Write-Host  $libitems.Count -ForegroundColor Green

              foreach($libitem in $libitems)

                {  
                    $owner=""
                   
                    $sitedescription=""

                    #looking for owners

                    $flag=$false
                    write-host "2"
 

                     

                   



                    write-host "4" -ForegroundColor Yellow
                    #create array record

                    $data=$data+@([pscustomobject]@{

                        Title=$site.Title;

                        Url=$site.Url;

                        Template=$site.Template;

                        Owner=$owner;

                        StorageUsage_GB=[string]([int][string]$site.StorageUsageCurrent/1024);

                        StorageMaximumLevel_GB=[string]([int]$site.StorageQuota/1024);

                        SharingCapability=$site.SharingCapability;

                        LastContentModifiedDate=$site.LastContentModifiedDate;

                        Description=$sitedescription;

                        OwnerCompany=[string]$libitem["OwnerCompany"].Label;

                        OwnerDepartment=[string]$libitem["OwnerDepartment"].Label;
                        
                        TypeSite=[string]$libitem["TypeSite"].Label;

                        OwnerInternal=$libitem["Owner"].LookupValue;

                        UsersCompanies=[string]$libitem["UsersCompanies"].Label;

                        InTeams=$libitem["InTeams"];

                        CentralSite=$libitem["CentralSite"];

                        InHub=$libitem["InHub"];

                        HubName=$inhub;

                        BusinessApp=$libitem["BusinessApp"];

                        NumberITIL=$libitem["NumberITIL"];

                        Archive=$libitem["Archive"];

                        InYammer=$libitem["InYammer"];

                        })

 

                       

 

                $workingcount=$workingcount+1

 

                }

     }

        else {

         write-host $site.Url "- haven't system list" -ForegroundColor Red

       $errorcount=$errorcount+1

       $errorsites=$errorsites+@([pscustomobject]@{

                        Title=$site.Title;

                        Url=$site.Url;

                        Reason="Haven't system list";

                        })

                         $data=$data+@([pscustomobject]@{

                        Title=$site.Title;

                        Url=$site.Url;

                        Template=$site.Template;

                        Owner=$owner;

                        StorageUsage_GB=[string]([int][string]$site.StorageUsageCurrent/1024);

                        StorageMaximumLevel_GB=[string]([int]$site.StorageQuota/1024);

                        SharingCapability=$site.SharingCapability;

                        LastContentModifiedDate=$site.LastContentModifiedDate;

                        Description=$sitedescription;


                        HubName=$inhub

                        })


        }

Disconnect-PnPOnline

}

       Catch [Exception] {

       write-host $site.Url $Error[0] -ForegroundColor Red

       $errorcount=$errorcount+1

       $errorsites=$errorsites+@([pscustomobject]@{

                        Title=$site.Title;

                        Url=$site.Url;

                        Reason=$Error[0];

                        })

       }

 

 }

 

# Write final csv file

 

$data | export-csv $outputpath -Delimiter ";" -Encoding UTF8

 

if ($errorcount -gt 0) {

$errorsites | export-csv $outputpath_err -Delimiter ";" -Encoding UTF8

}

 

 

# Display Site Collection Inventory complete

Write-Host "There are working " $workingcount " site collections" -ForegroundColor Green

Write-Host "There are connection error " $errorcount " site collections" -ForegroundColor Red