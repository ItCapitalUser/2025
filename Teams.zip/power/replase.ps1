﻿# Original string with abbreviations
$string = "The GDP of USA is higher than that of UK and EU."

# Hashtable with replacements
$replacements = @{
    "USA" = "United States of America"
    "UK" = "United Kingdom"
    "EU" = "European Union"
}

# Apply replacements
foreach ($key in $replacements.Keys) {
    $string = $string.Replace($key, $replacements[$key])
}

# Output the modified string
Write-Output $string

2
3
$originalString = "Hello, |:@Wor#ld!"
$specialCharacters = "[\|:<>?*$#]"
$modifiedString = $originalString -replace $specialCharacters, ""


$replacements = @{
    "Cайт проекта" = "Cайт проєкта"
    "Бизнес-процес/функционал" = "Сайт, що є частиною custom системи"
    "Информационный сайт" = "Інформаційний сайт"
    "Сайт группы Yammer" = "Сайт групи М365"
    "Сайт для тестирования" = "Сайт для перевірок функціоналу"
    "Сайт подразделения" = "Сайт підрозділу"
    "Сайт создан автоматически при создании группы пользователь Office 365" = "Сайт групи М365"
    "Системный сайт" = "Системний сайт"

}