﻿#Get Context Ctx SPO

$Cred= Get-Credential
$Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)
 
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/it_hub"
$Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
$Ctx.Credentials = $Credentials 

#Get Site Collection Features
$SiteCollFeatures = $Ctx.Site.Features
$Ctx.Load($SiteCollFeatures)
$Ctx.ExecuteQuery() 

#Get Context Ctx Pnp 

$Ctx = Get-PnPContext
$Web = $Ctx.Web
$Ctx.Load($Web)

#Get Context CertificatePath

Connect-PnPOnline $siteUrlItSite -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")


 $Ctx = Get-PnPContext
 $List =$Ctx.Web.Lists.GetByTitle($ListName)

