﻿$SiteURL="https://smartholdingcom.sharepoint.com/sites/demo-09-2024"
$SiteURL="https://smartholdingcom.sharepoint.com/sites/fo-contEvents-test"
$siteUrlItSite= "https://smartholdingcom.sharepoint.com/sites/it_hub"
$TenantAdminURL = "https://smartholdingcom-admin.sharepoint.com/"


$orgName = "smartholdingcom" 
$tenant = "$orgName.onmicrosoft.com"
$clientid="30f9999e-20ce-4e18-bb00-cb03b7899ee3"
$CSVFilePath = "C:\Users\vira.chorna\Documents\temp\AllSitesCustomProperty_091024.csv"


$ListAdditParm = "Додаткові параметри SPO сайтів"
$ListAudits= "Audits parameters"


#region  replacements TypeSite and UsersCompanies

$replacementsTypeSite = @{
    "Cайт проекта" = "Cайт проєкта"
    "Бизнес-процес/функционал" = "Сайт, що є частиною custom системи"
    "Информационный сайт" = "Інформаційний сайт"
    "Сайт группы Yammer" = "Сайт групи М365"
    "Сайт для тестирования" = "Сайт для перевірок функціоналу"
    "Сайт подразделения" = "Сайт підрозділу"
    "Сайт создан автоматически при создании группы пользователь Office 365" = "Сайт групи М365"
    "Системный сайт" = "Системний сайт"
    "Портал"="Портал"
    "Файловий ресурс"="Файловий ресурс"

}

$replacementsUsersCompanies = @{
    "Внешние партнеры" = "Зовнішні партнери"
    "ГК Верес" = "ГК ВЕРЕС"
    "СМАРТ-МЕРИТАЙМ ГРУП ООО" = "СМАРТ-МЕРІТАЙМ ГРУП ТОВ"
    "ИТ КАПИТАЛ ООО" = "ІТ КАПІТАЛ ТОВ"
    "НАВАЛЬ ЛОГІСТІК ТОВ" = "НАВАЛЬ ЛОГІСТІК ТОВ"
    "СМАРТ-ХОЛДИНГ ООО" = "СМАРТ-ХОЛДИНГ ТОВ"
    "САНТИС ТФФ ТОВ" = "САНТИС ТФФ ТОВ"
    "СМАРТ БИЗНЕС СЕРВИС ООО" = "СМАРТ БІЗНЕС СЕРВІС ТОВ"
    "СМАРТ УРБАН СОЛЮШНС ТОВ" = "СМАРТ УРБАН СОЛЮШНС ТОВ"
    "ФОНД ТАКТИЧНИХ ІНВЕСТИЦІЙ" = "ФОНД ТАКТИЧНИХ ІНВЕСТИЦІЙ"
    "СМАРТ-ЕНЕРДЖІ ТОВ"= "СМАРТ-ЕНЕРДЖІ ТОВ"
    "Все компании" = "Всі компанії"
}


$search = "Сайт группы Yammer"
if($replacements["Сайт группы Yammer1"])
{Write-Host "yyy"}
else
{Write-Host "nnn" -f Magenta}


#endregion


#region init class 
class ListFields {
    [string]$Title
    [string]$Url
    [string]$Template
    [string]$Test
    [string]$TypeSite
    [string]$Owner
    [string]$UsersCompanies
    [string]$CentralSite
    [string]$InHub
    [string]$TitleHUB
    [string]$BusinessApp
    [string]$NumberITIL
    [string]$InEngage
    [string]$InExchange
    [string]$Archiv
}
#endregion 

try{

    #region Get Archive Ms Teams
    Connect-MicrosoftTeams
    $TeamsArchived =  Get-Team -Archived:$false 
    Disconnect-MicrosoftTeams
    #endregion

    #Connect to It hub
    Connect-PnPOnline $siteUrlItSite -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")

    $Ctx = Get-PnPContext
    $Web = $Ctx.Web
    $Ctx.Load($Web)

    $ListCustomParam=$Ctx.Web.Lists.GetByTitle($ListAdditParm)
    $Ctx.Load($ListCustomParam)
    $Ctx.ExecuteQuery()
  
   <# #sharepoint online powershell add list item
    $ListItemInfo = New-Object Microsoft.SharePoint.Client.ListItemCreationInformation 
    $ListItem = $List.AddItem($ListItemInfo)
     
    #Set Column Values
    $ListItem["Title"] =$SiteURL

 
    #add item to sharepoint online list powershell
    $ListItem.Update()
    $Ctx.ExecuteQuery()#>

    $Query = "<View><Query><OrderBy><FieldRef Name='Modified' Ascending='False'/></OrderBy></Query> <RowLimit Paged='TRUE'>1</RowLimit></View>"
    $ListItems = Get-PnPListItem -List $ListAdditParm -Query $Query
    $ListItems[0]
 
    #Get All Sites
    Connect-PnPOnline $TenantAdminURL -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")
    $SiteCollections= $null
    $SiteCollections = Get-PnPTenantSite| Select -Property  Title, Url, Template, GroupId | Where -Property Template -In ("GROUP#0", "STS#0", "SITEPAGEPUBLISHING#0", "BDR#0")#("GROUP#0", "TEAMCHANNEL#0","TEAMCHANNEL#1") #("STS#0", "SITEPAGEPUBLISHING#0") #| Where -Property Template -NotIn ("SRCHCEN#0", "REDIRECTSITE#0", "SPSMSITEHOST#0", "APPCATALOG#0", "POINTPUBLISHINGHUB#0", "EDISC#0", "STS#-1")
    Disconnect-PnPOnline

    

    $DataCollection = @()
    Foreach($ItemSite in $SiteCollections)
    { 
        try{
            $SiteURL=$ItemSite.Url
            Write-Host "Start $($SiteURL) Template $($ItemSite.Template)" -f Yellow  

            #create object ListItem
            $ListItemInfo = New-Object Microsoft.SharePoint.Client.ListItemCreationInformation 
            $NewItem = $ListCustomParam.AddItem($ListItemInfo)

            #region Check Teams is Archiv
            if ($ItemSite.Template -contains "GROUP#0")
            {
                $siteGroupId= $ItemSite.GroupId #"fd7b6911-fe2a-47c4-a982-5f4cc71a1269"
                $inArchiv =   $TeamsArchived | Where-Object GroupId -eq $siteGroupId 
                Write-Host $ItemSite.GroupId + " Archiv" -f Red
                    
               if ($inArchiv)
               {
                    #$OwnerSiteEmailValue = $null
                    $ArchiveValue = $true
               }
               else
               {
                    #$OwnerSiteEmailValue = $ListItems["Owner"].Email
                    $ArchiveValue = $false
               }
            }
            #endregion

            Connect-PnPOnline $SiteURL -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")
            
            $List = Get-PnPList -Identity $ListAudits

            if ($List)
            { 
                Write-Host "yes"

                #CAML Query to Filter List Items
                $Query = "<View><Query><OrderBy><FieldRef Name='Modified' Ascending='False'/></OrderBy></Query></View>"
                $ListItems = Get-PnPListItem -List $ListAudits -Query $Query            

                #$ListItems.GetType()

                if ($ListItems.Count -gt 0)
                {
                    #region check if teams in archiv
                    
                   <# $siteGroupId= $ItemSite.GroupId #"fd7b6911-fe2a-47c4-a982-5f4cc71a1269"
                    $inArchiv =   $TeamsArchived | Where-Object GroupId -eq $siteGroupId 
                    Write-Host $ItemSite.GroupId + " Archiv" -f Red

                    
                    if ($inArchiv)
                    {
                        $OwnerSiteEmailValue = $null
                        $ArchiveValue = "yes"
                    }
                    else
                    {
                        $OwnerSiteEmailValue = $ListItems["Owner"].Email
                         $ArchiveValue = "no"
                    }#>
                    #endregion

                    $OwnerSiteEmailValue = $ListItems["Owner"].Email
                    $TypeSiteValue =''
                    $ChoicesTypeSiteValue = @()
                    $ListItems["TypeSite"] | ForEach-Object {
                        #Write-host $_.Label
                        $TypeSiteValue += $replacementsTypeSite[$_.Label]
                        $ChoicesTypeSiteValue += $replacementsTypeSite[$_.Label]

                    }

                    #Write-Host $TypeSiteValue -f Green

                    $UsersCompaniesValue =''
                    $UsersCompaniesValueRus = ''
                    $ChoicesUsersCompValue = @()
                    $ListItems["UsersCompanies"] | ForEach-Object {
                        #Write-host $_.Label
                        $UsersCompaniesValue += $replacementsUsersCompanies[$_.Label]+";"
                        $UsersCompaniesValueRus+= $_.Label+";"
                        $ChoicesUsersCompValue += $replacementsUsersCompanies[$_.Label]
                    }
                     #Write-Host $UsersCompaniesValue -f Green
                                       
                     $BusinessAppValue = $ListItems["BusinessApp"]
                     $NumberITILValue = $ListItems["NumberITIL"]
                     $InEngageValue = $ListItems["InYammer"]
 
                     #$ArchiveValue = $ListItems["Archive"]
                     #Write-Host $CentralSiteValue -f Green


                     <#$ListItems["UsersCompanies"] | ForEach-Object {
        Write-host $_.Label

    }#>
                }
 
                $Data = New-Object ListFields -Property ([Ordered] @{
                Title=$SiteURL
                Test  = $UsersCompaniesValueRus 
                Template = $ItemSite.Template
                TypeSite = $TypeSiteValue
                Owner = $OwnerSiteEmailValue
                UsersCompanies= $UsersCompaniesValue
                CentralSite = $CentralSiteValue
                InHub = $InHubValue
                BusinessApp =  $BusinessAppValue 
                NumberITIL = $NumberITILValue
                InEngage = $InEngageValue 
                Archiv= $ArchiveValue
                })

                #region Set Field in SPO list
               
                Write-Host "-----Start ----" -f Green
                try
                {
                    $SPOUser = $Ctx.Web.EnsureUser($OwnerSiteEmailValue)
                    $Ctx.Load($SPOUser)
                    $Ctx.ExecuteQuery()

                    $NewItem["Owner"] =$SPOUser

                }
                catch{
                    $NewItem["Test"] =$OwnerSiteEmailValue
                }

                $NewItem["Title"] =$SiteURL
                $NewItem["Test"] =$OwnerSiteEmailValue
                $NewItem["UsersCompanies"] =$ChoicesUsersCompValue
                $NewItem["TypeSite"] =$TypeSiteValue
                $NewItem["BusinessApp"] =$BusinessAppValue 
                $NewItem["NumberITIL"] =$NumberITILValue
                $NewItem["InEngage"] =$InEngageValue 
                $NewItem["Template"] =$ItemSite.Template
                $NewItem["Archive"] =$ArchiveValue
                Write-Host "1------1------1"
                #endregion
            }
            else
            {
                Write-Host "no"

                $Data = New-Object ListFields -Property ([Ordered] @{
                Title=$SiteURL
                Test  = "no"
                Template = $ItemSite.Template
                })

                $NewItem["Title"] =$SiteURL
                $NewItem["Template"] =$ItemSite.Template
            }

            
             #$ListItem["Title"] =$SiteURL
             Write-Host "2-----2----2"
             $NewItem.Update()
             $Ctx.ExecuteQuery()
             Write-Host "3-----3----3"

            $DataCollection += $Data
        }
        catch {
            write-host "Error get list and create item : $($_.Exception.Message)" -foregroundcolor Red
        }
         Disconnect-PnPOnline
    }
    $DataCollection | Export-Csv -Path $CSVFilePath -Force -NoTypeInformation -Encoding UTF8

}
catch {
     write-host "Error : $($_.Exception.Message)" -foregroundcolor Red
}

 Get-PnPField -List $ListAudits