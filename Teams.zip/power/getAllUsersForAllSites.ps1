﻿#Variables for Processing
$AdminUrl = "https://smartholdingcom-admin.sharepoint.com/"
$UserName= "spsitecoladm@smart-holding.com"
$Password = "uZ#RJpSS2%U9!PR"

#region init class 
class ListPermission {
    [string]$UserEmail
    [string]$NameGroup
    [string]$Url
    [string]$Read
    [string]$Contribute
    [string]$Edit
    [string]$Design
    [string]$FullControl
    [string]$Limited
    [string]$OtherPermission
}
#endregion
  
#Setup Credentials to connect
$SecurePassword = $Password | ConvertTo-SecureString -AsPlainText -Force
$Credentials = New-Object -TypeName System.Management.Automation.PSCredential -argumentlist $UserName, $SecurePassword
 
#connect to the service
Connect-SPOService -Url $AdminUrl -Credential $Credentials

$SiteColl = Get-SPOSite -Limit All 
$data=   $SiteColl |  Where-Object  {$_.Template -contains "BDR#0" -or $_.Template -contains "STS#0" -or $_.Template -contains "SITEPAGEPUBLISHING#0" -or $_.Template -contains "GROUP#0" -or $_.Template -contains "TEAMCHANNEL#0" -or $_.Template -contains "TEAMCHANNEL#1" }| Select-Object  -Property  URl, Template 
   

Foreach($Site in $SiteColl)
{
    Write-host "Getting Users from Site collection:"$Site.Url -f Yellow
    Get-SPOUser -Limit ALL -Site $Site.Url | Select DisplayName, LoginName
}
$SiteUrl="https://smartholdingcom.sharepoint.com/sites/demo-09-2024"
$allGroupsWeb=Get-SPOSiteGroup -site $SiteUrl | Select Title, Roles, Users

$DataCollectionUa = @()
Foreach($GroupWeb in $allGroupsWeb)
{
    Write-Host   $GroupWeb.Title -ForegroundColor Red
    $newItem = [ListPermission]@{
            NameGroup=$GroupWeb.Title
            Url=$SiteUrl
        }

   Foreach($RoleWeb in $GroupWeb.Roles)
        {
          $RoleWeb
          
          switch ($RoleWeb) {
            "Read" {
                $newItem.Read = "Читання"  
            }
            "Contribute"{
                $newItem.Contribute = "True" 
            }
            "Edit"{
                $newItem.Edit = "True" 
            }
            "Design"{
                $newItem.Design = "True" 
            }
            "Full Control"{
                $newItem.FullControl = "True" 
            }
            "Limited"{
                $newItem.Limited = "True" 
            }
            default {
                 $newItem.OtherPermission  = $RoleWeb
            }
            }

        }
    
    if($GroupWeb.Users)
    {
        Foreach($UserInGroup in $GroupWeb.Users)
        {
            $newItem.UserEmail = $UserInGroup
            $DataCollectionUa += $newItem
        }
    }
    else
        {$DataCollectionUa += $newItem}
 
    
}

$allUsers = Get-SPOUser -Limit ALL -Site $SiteUrl  | Where-Object {}

#($_.LoginName -like "*@*") -and ($_.IsSiteAdmin -ne "True") -and

 $CSVPath = "C:\Users\vira.chorna\Documents\temp\test220924.csv"
    $DataCollection | Export-Csv -Path $CSVPath -Force -NoTypeInformation -Encoding UTF8

   $table= $DataCollection | Format-Table  -Wrap -AutoSize
    $table| Export-Excel -Path "C:\Users\vira.chorna\Documents\temp\test220924_a2.xlsx" -TableName TestT -AutoSize
    $DataCollection | Export-Excel -Path "C:\Users\vira.chorna\Documents\temp\test220924_a1112.xlsx"  -TableName WebPermission 
    
     $table | Out-File c:\Users\vira.chorna\Documents\temp\test220924_outF.xlsx -Force

  
  
    Install-Module ImportExcel -AllowClobber -Force
    Get-Module ImportExcel -ListAvailable | Import-Module -Force -Verbose
