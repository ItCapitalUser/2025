﻿$SiteURL="https://smartholdingcom.sharepoint.com/sites/demo-09-2024"
$SiteURL="https://smartholdingcom.sharepoint.com/sites/cs"
$siteUrlItSite= "https://smartholdingcom.sharepoint.com/sites/it_hub"
$TenantAdminURL = "https://smartholdingcom-admin.sharepoint.com/"


#Set Variables
$SiteURL = "https://smartholdingcom-admin.sharepoint.com/"
$orgName = "smartholdingcom" 
$tenant = "$orgName.onmicrosoft.com"
$clientid="30f9999e-20ce-4e18-bb00-cb03b7899ee3"
$specialCharacters = "[\|:<>?*$#]"

$CSVFilePath = "C:\Temp\AllSitesData230924.csv"

 
#Connect to PnP Online
Connect-PnPOnline $SiteURL -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")

 
#Connect to Admin Center
Connect-PnPOnline $TenantAdminURL -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")
    
#Get All Site collections - Exclude: Seach Center, Redirect site, Mysite Host, App Catalog, Content Type Hub, eDiscovery and Bot Sites
$SiteCollections = Get-PnPTenantSite | Where -Property Template -In ("STS#0", "SITEPAGEPUBLISHING#0") #| Where -Property Template -NotIn ("SRCHCEN#0", "REDIRECTSITE#0", "SPSMSITEHOST#0", "APPCATALOG#0", "POINTPUBLISHINGHUB#0", "EDISC#0", "STS#-1")
$SiteCollections| Select Title, URL, Owner,  Template | Export-Csv -path $CSVFilePath -NoTypeInformation  -Encoding UTF8
#Get-PnPTenantSite -Detailed | Select Title, URL, Owner, LastContentModifiedDate, WebsCount, Template, StorageUsage | Export-Csv -path $CSVFilePath -NoTypeInformation


#region init class 
class ListPermission {
    [string]$UserName
    [string]$NameGroup
    [string]$Type
    [string]$Url
    [string]$Read
    [string]$Contribute
    [string]$Edit
    [string]$Design
    [string]$FullControl
    [string]$Limited
    [string]$OtherPermission
}
#endregion 


#region Test2 
Connect-PnPOnline $SiteURL -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")
    
Write-Host "start $($SiteURL)" -f Green
$Web = Get-PnPWeb -Includes RoleAssignments

$PermissionCollection = @()
Foreach ($RoleAssignment in $Web.RoleAssignments)
{
    #Get the Permission Levels assigned and Member
    Get-PnPProperty -ClientObject $roleAssignment -Property RoleDefinitionBindings, Member
    Write-Host "For $($RoleAssignment.Member.Title)" -ForegroundColor Yellow

    #Get the Principal Type: User, SP Group, AD Group
    $PermissionType = $RoleAssignment.Member.PrincipalType
    $PermissionLevels = $RoleAssignment.RoleDefinitionBindings | Select -ExpandProperty Name  #($RoleAssignment.RoleDefinitionBindings | Select -ExpandProperty Name) -join ","

    $newItem = [ListPermission]@{
            Type =  $PermissionType
            Url=$urlS.Url
        }
    Write-Host $newItem.Type -f Cyan
    Foreach($PermissionLevel in $PermissionLevels )
        {
          $PermissionLevel
          
          switch ($PermissionLevel) {
            "Read" {
                $newItem.Read = "True"  
            }
            "Contribute"{
                $newItem.Contribute = "True" 
            }
            "Edit"{
                $newItem.Edit = "True" 
            }
            "Design"{
                $newItem.Design = "True" 
            }
            "Full Control"{
                $newItem.FullControl = "True" 
            }
            "Limited Access"{
                $newItem.Limited = "True" 
            }
            default {
                 $newItem.OtherPermission  = $PermissionLevel
            }
            }

        }
     
    #Get all permission levels assigned (Excluding:Limited Access)
   # $PermissionLevels = ($PermissionLevels | Where { $_ -ne "Limited Access"}) -join ","
   # If($PermissionLevels.Length -eq 0) {Continue}
 
    #Get SharePoint group members
    If($PermissionType -eq "SharePointGroup")
    {
        Write-Host $RoleAssignment.Member.Title -f Blue

        $newItem.NameGroup = $RoleAssignment.Member.LoginName 
        #Get Group Members
        $GroupMembers = Get-PnPGroupMember -Identity $RoleAssignment.Member.LoginName                
        #Leave Empty Groups
        If($GroupMembers.count -eq 0)
        {
            Write-host "Empty $($RoleAssignment.Member.LoginName)"  
            $PermissionCollection += $newItem
            Continue
        }
 
        ForEach($User in $GroupMembers)
        {
           #Add the Data to Object
            Write-host "$User.Title +  $($RoleAssignment.Member.LoginName)"  
           $newItem.UserName=$User.Title
          # $newItem
           $PermissionCollection += $newItem
        }
    }
    Else
    {
        #Add the Data to Object
        $newItem.UserName= $RoleAssignment.Member.Title
        
        $PermissionCollection += $newItem
    }
}
#Export Permissions to CSV File
$PermissionCollection

$nameFile= $Web.Title+ "-" + $currDate
$PkFilePath ="C:\Users\vira.chorna\Documents\temp\ForReportWebPerm230924\$($nameFile).xlsx"
$WebFolderPath = "https://smartholdingcom.sharepoint.com/sites/it_hub/M365/SharePoint%20Online/Reports/Permission/Communication" #Server Relative URL
$PermissionCollection | Export-Excel -Path $PkFilePath   -TableName WebPermission -AutoSize
Write-Host "End " -f Red
#endregion

Foreach($siteColl in $SiteCollections)
{
Connect-PnPOnline $siteColl.Url -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")
    
Write-Host "start $($siteColl.Url)" -f Green
$Web = Get-PnPWeb -Includes RoleAssignments

$PermissionWeb = @()
Foreach ($RoleAssignment in $Web.RoleAssignments)
{
    #Get the Permission Levels assigned and Member
    Get-PnPProperty -ClientObject $roleAssignment -Property RoleDefinitionBindings, Member
    Write-Host "For $($RoleAssignment.Member.Title)" -ForegroundColor Yellow

    #Get the Principal Type: User, SP Group, AD Group
    $PermissionType = $RoleAssignment.Member.PrincipalType
    $PermissionLevels = $RoleAssignment.RoleDefinitionBindings | Select -ExpandProperty Name  #($RoleAssignment.RoleDefinitionBindings | Select -ExpandProperty Name) -join ","

    $newRecordPermission = [ListPermission]::new()

    $newRecordPermission.Type= $PermissionType
    $newRecordPermission.Url=$SiteURL

    Write-Host $newItem.Type -f Cyan
    Foreach($PermissionLevel in $PermissionLevels )
        {
          #$PermissionLevel
          
          switch ($PermissionLevel) {
            "Read" {
                $newRecordPermission.Read = "True"  
            }
            "Contribute"{
                $newRecordPermission.Contribute = "True"
            }
            "Edit"{
                $newRecordPermission.Edit = "True" 
            }
            "Design"{
                $newRecordPermission.Design = "True"  
            }
            "Full Control"{
                $newRecordPermission.FullControl = "True"  
            }
            "Limited Access"{
                $newRecordPermission.Limited = "True" 
            }
            default {
                 $newRecordPermission.OtherPermission = $PermissionLevel
            }
            }

        }
     
    #Get all permission levels assigned (Excluding:Limited Access)
   # $PermissionLevels = ($PermissionLevels | Where { $_ -ne "Limited Access"}) -join ","
   # If($PermissionLevels.Length -eq 0) {Continue}
 
    #Get SharePoint group members
    If($PermissionType -eq "SharePointGroup")
    {
        Write-Host "Start SharePointGroup $( $RoleAssignment.Member.LoginName)"
        $newItem.NameGroup = $RoleAssignment.Member.LoginName 
        $newRecordPermission.NameGroup = $RoleAssignment.Member.LoginName 
        #Get Group Members
        $GroupMembers = Get-PnPGroupMember -Identity $RoleAssignment.Member.LoginName  |Select Title, Email              
        #Leave Empty Groups
        If($GroupMembers.count -eq 0)
        {
            $PermissionWeb +=$newRecordPermission
            Continue
        }        
 
        ForEach($User in $GroupMembers)
        {
            Write-Host "User $($User.Title) in $($RoleAssignment.Member.LoginName )" -f Magenta
            $newRecordUser= [ListPermission]::new()

            $newRecordUser.NameGroup=$RoleAssignment.Member.LoginName 
            $newRecordUser.UserName=$User.Title
            $newRecordUser.Type=$PermissionType
            $newRecordUser.Url=$SiteURL
            $newRecordUser.Read=$newRecordPermission.Read
            $newRecordUser.Contribute=$newRecordPermission.Contribute
            $newRecordUser.Edit=$newRecordPermission.Edit
            $newRecordUser.Design=$newRecordPermission.Design
            $newRecordUser.FullControl=$newRecordPermission.FullControl
            $newRecordUser.Limited=$newRecordPermission.Limited
            $newRecordUser.OtherPermission=$newRecordPermission.OtherPermission
           #Add the Data to Object
           Write-Host "----------------------"
           $PermissionWeb +=$newRecordUser
        }
         #$PermissionCollection
    }
    Else
    {
        #Add the Data to Object
        $newRecordPermission.UserName =$RoleAssignment.Member.Title
        $PermissionWeb +=$newRecordPermission
    }
}
#Export Permissions to CSV File

$currDate = Get-Date -Format "ddMMyyy HHmm"

$nameFile = $Web.Title-replace $specialCharacters, ""

$nameFile= $Web.Title+ "-" + $currDate+".xlsx"
$PcFilePath ="C:\Users\vira.chorna\Documents\temp\ForReportWebPerm230924\$($nameFile)"
$PermissionWeb | Export-Excel -Path $PcFilePath   -TableName WebPermission -AutoSize -TableStyle Medium5
Write-Host "End $($urlS.Url)" -f Red
}

$DestinationFolderPath= "sites/it_hub/M365/SharePoint%20Online/Reports/Permission/Communication"

Add-PnPFile -Path $PkFilePath -Folder $DestinationFolderPath -ErrorAction Stop

#region Upload file to SPO file
Connect-PnPOnline $siteUrlItSite -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")

$TargetFolderRelativeURL ="/sites/it_hub/M365/SharePoint%20Online/Reports/SitePermissions"
$nameSite = $SiteURL.Substring($SiteURL.LastIndexOf("/") + 1)



#Read more: https://www.sharepointdiary.com/2019/03/sharepoint-online-migrate-folder-with-files-subfolders-using-powershell.html#ixzz8mbH6zxZK

#region upload to RootFolder
$Ctx = Get-PnPContext
$LibraryName= "M365"
$Library = $Ctx.Web.Lists.GetByTitle($LibraryName)
$Ctx.Load($Library)
$Ctx.Load($Library.RootFolder)
$Ctx.ExecuteQuery()


$FileStream = New-Object IO.FileStream($PcFilePath,[System.IO.FileMode]::Open)
$FileCreationInfo = New-Object Microsoft.SharePoint.Client.FileCreationInformation
$FileCreationInfo.Overwrite = $true
$FileCreationInfo.ContentStream = $FileStream
$FileCreationInfo.URL = $nameFile
$Upload = $Library.RootFolder.Files.Add($FileCreationInfo)
$ctx.Load($Upload)
$ctx.ExecuteQuery()
#endregion


#Read more: https://www.sharepointdiary.com/2020/05/upload-large-files-to-sharepoint-online-using-powershell.html#ixzz8mfEOcDs6
 
#endregion


#Read more: https://www.sharepointdiary.com/2018/01/sharepoint-online-upload-file-to-folder-using-powershell.html#ixzz8mb6FXqZ6
https://smartholdingcom.sharepoint.com/:f:/r/sites/it_hub/M365/SharePoint%20Online/Reports/Permission/Communication