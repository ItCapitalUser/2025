﻿
	
#Config Parameters
$AdminSiteURL="https://smartholdingcom-admin.sharepoint.com"
$UserAccount = "Kiryanova@smart-holding.com"

$SiteURL="https://smartholdingcom.sharepoint.com/sites/sbs_fs"

  
#Connect to SharePoint Online Tenant Admin
Connect-SPOService -URL $AdminSiteURL -Credential (Get-Credential)
  
#Get all Site Collections
$SitesCollections = Get-SPOSite  -Limit ALL

$ComSites = $SitesCollections | Select -Property  Title, Url, Template| Where -Property Template -In ( "STS#0", "SITEPAGEPUBLISHING#0", "BDR#0")
 
#Iterate through each site collection
 $DataCollection = @()
ForEach($Site in $ComSites)
{
    Write-host -f Yellow "-----Checking Site Collection:"$Site.URL
  
    #Get the user from site collection
    $User = Get-SPOUser -Site $Site.URL | Where {$_.LoginName -eq $UserAccount}
  
    #Remove the User from site collection
    If($User)
    {
        #Remove the user from the site collection
        Remove-SPOUser -Site $Site.URL -LoginName $UserAccount
        Write-host -f Green "`tUser $($UserAccount) has been removed from Site collection!"
        $Data = New-Object PSObject -Property ([Ordered] @{
                Title=$Site.Title
                Url  = $Site.URL
                Name = $UserAccount
               
            })
            $DataCollection += $Data
    }

    #$User=у
}

 $DataCollection1= $DataCollection
$CSVFilePath = "C:\Users\vira.chorna\Documents\temp\Sites_Kiryanova@smart-holdingcom.csv"
  $DataCollection  | Export-Csv -Path $CSVFilePath -Force -NoTypeInformation -Encoding UTF8
