﻿
	
#Config Parameters
$AdminSiteURL="https://smartholdingcom-admin.sharepoint.com"
$UserAccount = "vladyslav.levchenko@ifsmart.com.ua"

$SiteURL="https://smartholdingcom.sharepoint.com/sites/sbs_fs"

  
#Connect to SharePoint Online Tenant Admin
Connect-SPOService -URL $AdminSiteURL -Credential (Get-Credential)
  
#Get all Site Collections
$SitesCollections = Get-SPOSite  -Limit ALL

$ComSites = $SitesCollections | Select -Property  Title, Url, Template| Where -Property Template -In ( "STS#0", "SITEPAGEPUBLISHING#0", "BDR#0")
$TeamsSites = $SitesCollections | Select -Property  Title, Url, Template| Where -Property Template -In ( "GROUP#0")
 
#Iterate through each site collection


 $DataCollection = @()
 $i=1
ForEach ($Site in $TeamsSites) #$ComSites
{
    Write-host -f Yellow "-----Checking Site Collection:"$Site.URL
  
    #Get the user from site collection
    $SiteUrl = "https://smartholdingcom.sharepoint.com/sites/IT_ksb_448"
    $User = Get-SPOUser -Site  $Site.URL | Where {$_.LoginName -eq $UserAccount}
  
    #Remove the User from site collection
    If($User)
    {
        #Remove the user from the site collection
        #Remove-SPOUser -Site $Site.URL -LoginName $UserAccount
        Write-host -f Green "`tUser $($UserAccount) has been removed from Site collection!"
        $Data = New-Object PSObject -Property ([Ordered] @{
                Title=$Site.Title
                Url  = $Site.URL
                Name = $UserAccount
               
            })
            $DataCollection += $Data
    }
      $i++
    #$User=у
}

 $DataCollection1= $DataCollection
$CSVFilePath = "C:\Users\vira.chorna\Documents\temp\Sites_Kiryanova@smart-holdingcom.csv"
  $DataCollection  | Export-Csv -Path $CSVFilePath -Force -NoTypeInformation -Encoding UTF8

  30000, 56798, 12432 | ForEach-Object -Process {$_/1024}

29.296875
55.466796875
12.140625

$UserAccount = "vira.chorna@it-capital.com.ua"

$arr1 = $TeamsSites[1..100]
$arr1 | ForEach-Object -Process {
  Write-host -f Yellow "-----Checking Site Collection:"$_.URL
  $SiteUrl =$_.URL
  $User = Get-SPOUser -Site $SiteUrl | Where {$_.LoginName -eq $UserAccount}
  If($User)
   {
        Write-Host "++"
        #Remove the user from the site collection
        #Remove-SPOUser -Site $Site.URL -LoginName $UserAccount
        Write-host -f Green "`tUser $($UserAccount) has been removed from Site collection!"
        $Data = New-Object PSObject -Property ([Ordered] @{
                Title=$Site.Title
                Url  = $Site.URL
                Name = $UserAccount
               
            })
            $DataCollection += $Data
    }

}

 
 $j=1
 $CountSites=$TeamsSites.Count
 $secondN= $block=100

 $DataCollection = @()
 $i=1
do
{
    Write-Host   $j, $secondN -f Blue
    $blockSites =$TeamsSites[$j..$secondN]

       $blockSites | ForEach-Object -Process {
      Write-host -f Yellow "-----Checking Site Collection:"$_.URL
      $SiteUrl =$_.URL
      $User = Get-SPOUser -Site $SiteUrl | Where {$_.LoginName -eq $UserAccount}
      If($User)
       {
            Write-Host "++"
            #Remove the user from the site collection
            #Remove-SPOUser -Site $Site.URL -LoginName $UserAccount
            Write-host -f Green "`tUser $($UserAccount) has been removed from Site collection!"
            $Data = New-Object PSObject -Property ([Ordered] @{
                    Title=$Site.Title
                    Url  = $Site.URL
                    Name = $UserAccount
               
                })
                $DataCollection += $Data
        }

    }

    $j=$secondN+1
    $secondN=$secondN+$block
    Write-Host "--" $secondN
}
While ($secondN -le $CountSites)

