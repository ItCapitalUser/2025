﻿Import-Module Microsoft.Online.SharePoint.PowerShell -DisableNameChecking
 
$TenantAdminURL = "https://smartholdingcom-admin.sharepoint.com"
$ThemeName = "Theme custom design 3"

Get-SPOTheme
 
#Connect-SPOService -Url $TenantAdminURL -Credential (Get-Credential)
 
#Get the custom theme to delete
$CustomTheme = Get-SPOTheme | Where {$_.Name -eq $ThemeName }
If($CustomTheme -ne $null)
{
    #Delete theme
    Remove-SPOTheme -Identity $ThemeName
    Write-Host "Theme '$ThemeName' Removed Successfully!" -f Green
}
Else
{
    Write-Host "Theme '$ThemeName' doesn't exist!" -f Yellow
}


#Read more: https://www.sharepointdiary.com/2019/05/sharepoint-online-remove-custom-theme-using-powershell.html#ixzz8zqxsh1if