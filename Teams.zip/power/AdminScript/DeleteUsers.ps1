﻿$orgName = "smartholdingcom" 
$tenant = "$orgName.onmicrosoft.com"
$clientid="30f9999e-20ce-4e18-bb00-cb03b7899ee3"

$TenantAdminURL = "https://smartholdingcom-admin.sharepoint.com/"
Connect-PnPOnline $TenantAdminURL -Credentials (Get-Credential)  #-UseWebLogin
Connect-PnPOnline $TenantAdminURL -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")
$SiteCollections= $null
$SiteCollections = Get-PnPTenantSite| Select -Property  Title, Url, Template, GroupId | Where -Property Template -In ("GROUP#0", "STS#0", "SITEPAGEPUBLISHING#0", "BDR#0")#("GROUP#0", "TEAMCHANNEL#0","TEAMCHANNEL#1") #("STS#0", "SITEPAGEPUBLISHING#0") #| Where -Property Template -NotIn ("SRCHCEN#0", "REDIRECTSITE#0", "SPSMSITEHOST#0", "APPCATALOG#0", "POINTPUBLISHINGHUB#0", "EDISC#0", "STS#-1")
Disconnect-PnPOnline

Connect-AzureAD -Credential $Credential

#region For all sites
Foreach($ItemSite in $SiteCollections)
{
    $SiteUrl = $ItemSite.Url 
    Write-Host "---- Start check $($SiteUrl)" -f Green
    #Connect-PnPOnline $SiteUrl -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")
    Connect-PnPOnline $SiteUrl -UseWebLogin

    $Ctx = Get-PnPContext

    $Users = $Ctx.Web.SiteUsers
    $Ctx.Load($Users) 
    $Ctx.ExecuteQuery()

    $select = $Users | Where-Object {($_.PrincipalType -eq "User")  -and ($_.Email)} #-and ($_.IsSiteAdmin -ne "True")
    #$select | ForEach-Object { Write-Host "$($_.Title) - $($_.Email) - $($_.PrincipalType) - $($_.IsSiteAdmin)"}
    foreach($Empl in $select)
    {

       $UserAccount =  Get-AzureADUser -Filter "userPrincipalName eq '$($Empl.UserPrincipalName)'" -ErrorAction SilentlyContinue

       If($UserAccount -eq $null) 
       { 
            Write-Host "Delete "+ $Empl.UserPrincipalName -f Red
            $LoginName = "i:0#.f|membership|"+$Empl.UserPrincipalName
            $Ctx.Web.SiteUsers.RemoveByLoginName($LoginName)
          $Ctx.ExecuteQuery()
  
       } 

    }

    Disconnect-PnPOnline
}
#endregion

#region For user for all sites
$userEmail = "lybov.bryazkalo@smartbs.com.ua"
Foreach($ItemSite in $SiteCollections)
{
    $SiteUrl = $ItemSite.Url 
    #$SiteUrl = "https://smartholdingcom.sharepoint.com/sites/it_hub"
    #$SiteUrl = "https://smartholdingcom.sharepoint.com/sites/sbs_hr"
    Write-Host "---- Start check $($SiteUrl)" -f Green
    Connect-PnPOnline $SiteUrl -ClientId $clientId -Tenant $tenant -CertificatePath 'C:\Users\vira.chorna\Documents\power\cer\pnp.pfx' -CertificatePassword (ConvertTo-SecureString -AsPlainText -Force "passwoed")
    $LoginName = "i:0#.f|membership|"+$userEmail

    $Ctx = Get-PnPContext
    try{

       $Ctx.Web.SiteUsers.RemoveByLoginName($LoginName)
       $Ctx.ExecuteQuery()
       Write-Host "Delete User $($SiteUrl)"
       }
       catch {
             #write-host "Error : $($_.Exception.Message)" -foregroundcolor Red
        }
       # Write-Host "---end $($SiteUrl)"
    Disconnect-PnPOnline
}
#endregion

