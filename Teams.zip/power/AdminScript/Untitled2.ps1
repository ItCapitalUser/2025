﻿$srcsiteUrl = "https://smartholdingcom.sharepoint.com/sites/it_cabMAN"
$destSiteUrl = "https://smartholdingcom.sharepoint.com/sites/it_testTemp1"
#connect source site url
Connect-PnPOnline -Url $srcsiteUrl -UseWebLogin
$TopNavs = Get-PnPNavigationNode -Location QuickLaunch | Select Title, Url
#connect destination site url
Connect-PnPOnline -Url $destSiteUrl -UseWebLogin
foreach($TopNav in $TopNavs) {
    if ($TopNav.Url) {
        Add-PnPNavigationNode -Location QuickLaunch -Title $TopNav.Title
    }
}