﻿$AdminSiteURL="https://smartholdingcom-admin.sharepoint.com"
$UserName="spsitecoladm@smart-holding.com"
$Password = "uZ#RJpSS2%U9!PR"
 
$SecurePassword = ConvertTo-SecureString -String $Password -AsPlainText -Force
$Cred = New-Object -TypeName System.Management.Automation.PSCredential -argumentlist $UserName, $SecurePassword
 
#connect to sharepoint online site using powershell
Connect-SPOService -URL $AdminSiteURL -Credential $Cred 


Import-Module AzureAD
$Credential = Get-Credential

#Lets connect to the Azure Active Directory
Connect-AzureAD -Credential $Cred $Credential

$SitesCollections = Get-SPOSite  -Limit ALL 

$ComSites = $SitesCollections | Select -Property  Title, Url, Template| Where -Property Template -In ( "STS#0", "SITEPAGEPUBLISHING#0", "BDR#0")
$TeamsSites = $SitesCollections | Select -Property  Title, Url, Template| Where -Property Template -In ( "GROUP#0")
$TeamsChannel = $SitesCollections | Select -Property  Title, Url, Template| Where -Property Template -In ( "TEAMCHANNEL#0",  "TEAMCHANNEL#1")

 
 $j=1
 $CountSites=$TeamsSites.Count
 $secondN= $block=100


 #region For user for all sites
Foreach($ItemSite in $TeamsChannel)
{
    $SiteUrl = $ItemSite.Url 
    Write-Host "---- Start check $($SiteUrl)" -f Green

    $Users =Get-SPOUser -Site $SiteUrl | Select-Object -Property  IsGroup, LoginName 

    $select = $Users | Where-Object {($_.IsGroup -ne "Fasle") -and ($_. LoginName -like "*@*") -and ($_. LoginName -notlike "*@sharepoint")}

    foreach($Empl in $select)
    {

       $UserAccount =  Get-AzureADUser -Filter "userPrincipalName eq '$($Empl.LoginName)'" -ErrorAction SilentlyContinue

       If($UserAccount -eq $null) 
       { 
            Write-Host "Delete "+ $Empl.LoginName -f Red
            Remove-SPOUser -Site $SiteUrl -LoginName $Empl.LoginName
       } 
    }

    Write-Host "----- end for $($ItemSite.Url) --"

   
}

Foreach($ItemSite in $TeamsChannel)
{
 $SiteCollURL = $ItemSite.Url
  Write-Host "---- Start check $($SiteCollURL)" -f Green 
    Set-SPOUser -site $SiteCollURL -LoginName $UserName -IsSiteCollectionAdmin $True
}
#endregion

#region delete one user $TeamsSites[571..595]
$loginUsersDelete= "Alyona.Kotuz@smartbs.com.ua" 



Foreach($ItemSite in $ComSites )
{
    $SiteUrl = $ItemSite.Url 
    Write-Host "---- Start check $($SiteUrl)" -f Green

    $findUser = $null
    $findUser = Get-SPOUser -Site $SiteUrl | Select-Object -Property  IsGroup, LoginName | Where-Object {$_.LoginName -like $loginUsersDelete} 

    if (-not [string]::IsNullOrEmpty($findUser)) {
        Write-Host "Delete "+ $loginUsersDelete -f Red
        Remove-SPOUser -Site $SiteUrl -LoginName $loginUsersDelete
    }


    Write-Host "----- end for $($ItemSite.Url) --"

   
}
#endregion



#region Delete by cycle
 
 $j=1
 $CountSites=$TeamsChannel.Count
 $secondN= $block=100

 $DataCollection = @()
 $i=1
do
{
    Write-Host   $j, $secondN -f Cyan

    Foreach($ItemSite in $TeamsChannel[$j..$secondN])
    {
        $SiteUrl = $ItemSite.Url 
        Write-Host "---- Start check $($SiteUrl)" -f Green

        $findUser = $null
        $findUser = Get-SPOUser -Site $SiteUrl | Select-Object -Property  IsGroup, LoginName | Where-Object {$_.LoginName -like $loginUsersDelete} 

        if (-not [string]::IsNullOrEmpty($findUser)) {
            Write-Host "Delete "+ $loginUsersDelete -f Red
            Remove-SPOUser -Site $SiteUrl -LoginName $loginUsersDelete
        }
    }
    Write-Host "Start sleep" -f Yellow
    Start-Sleep -Seconds 120
    
    $j=$secondN+1
    $secondN=$secondN+$block
    Write-Host "--" $secondN
}
While ($secondN -le $CountSites)
 #-------
$j=1
 $CountSites=$TeamsSites.Count
 $secondN= $block=100

 $DataCollection = @()
 $i=1
do
{
    Write-Host   $j, $secondN -f Cyan
    $blockSites =$TeamsSites[$j..$secondN]
    Foreach($ItemSite in $TeamsSites[$j..$secondN])
    {
        $SiteUrl = $ItemSite.Url 
        Write-Host "---- Start check $($SiteUrl)" -f Green

        $findUser = $null
        $findUser = Get-SPOUser -Site $SiteUrl | Select-Object -Property  IsGroup, LoginName | Where-Object {$_.LoginName -like $loginUsersDelete} 

        if (-not [string]::IsNullOrEmpty($findUser)) {
            Write-Host "Delete "+ $loginUsersDelete -f Red
            Remove-SPOUser -Site $SiteUrl -LoginName $loginUsersDelete
        }
    }
    Write-Host "Start sleep" -f Yellow
    Start-Sleep -Seconds 120
    
    $j=$secondN+1
    $secondN=$secondN+$block
    Write-Host "--" $secondN
}
While ($secondN -le $CountSites)

#endregion


$SiteUrl="https://smartholdingcom.sharepoint.com/sites/hub_veres"
$Users =Get-SPOUser -Site $SiteUrl | Select-Object -Property  IsGroup, LoginName 

$select = $Users | Where-Object {($_.IsGroup -ne "Fasle") -and ($_. LoginName -like "*@*") -and ($_. LoginName -notlike "*@sharepoint")}

foreach($Empl in $select)
    {

       $UserAccount =  Get-AzureADUser -Filter "userPrincipalName eq '$($Empl.LoginName)'" -ErrorAction SilentlyContinue

       If($UserAccount -eq $null) 
       { 
            Write-Host "Delete "+ $Empl.LoginName -f Red
            Remove-SPOUser -Site $SiteUrl -LoginName $Empl.LoginName
       }
   } 


$CSVFilePath = "C:\Users\vira.chorna\Documents\temp\TestDel.csv"
  $SitesCollections | Select -Property  Title, Url, Template | Export-Csv -Path $CSVFilePath -Force -NoTypeInformation -Encoding UTF8
