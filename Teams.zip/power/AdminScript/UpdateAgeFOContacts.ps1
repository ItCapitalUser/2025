﻿$SiteURL = "https://smartholdingcom.sharepoint.com/sites/fo-contacts-events"
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/ceo-events"
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/fo-contEvents-test"

$listUrl = '/Lists/Contacts'
$Cred = Get-Credential

Connect-PnPOnline –Url $SiteURL –Credentials $Cred

$site = Connect-PnPOnline -Url $siteUrl  -UseWebLogin

$allItems=Get-PnPListItem -List $listUrl
$allItems=Get-PnPListItem -List $listUrl |  Where-Object { $_.FieldValues["DateOfBirth"].Month -eq 12 } #Where-Object { $_.FieldValues["DateOfBirth"].Month -ne 12 } # | Where-Object { $_.FieldValues["DateOfBirth"].Month -eq 12 }ne

$today = Get-Date
foreach($item in $allItems)
{
 Write-Host "old age" : $item["Age"]
 Write-Host "DateOfBirth" : $item["DateOfBirth"]
 $birthday =$item["DateOfBirth"]

 $timedifference = $today - $birthday
  $ticks = $timedifference.Ticks
  $age = (New-Object DateTime -ArgumentList $ticks).Year 
  Write-Host "New age" : $age

  Set-PnPListItem -List $listUrl -Identity $item -Values @{"Age" = $age}
  Write-Host "Update age for" : $item["Title"]
} 