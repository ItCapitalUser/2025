﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"

#Variable Year and URL
$UrlFolderLib= "KPI/"
$nameQuarter = "2025/Квартал 4"
$nameYear= "2024/Річні"


#Variables SPO
$SiteURL="https://smartholdingcom.sharepoint.com/sites/sbs_hr" 
$nameLibraryEng = "Kpi"
$nameLibraryUkr = "KPI"
$partUrlSite = "/sites/sbs_hr/"
#group for permission stable 
$arrGroupEdit = "Керівник Центр сервісів з управління персоналом", "Провідний фахівець по роботі з персоналом"
$arrGroupRead = "Директор СБС"


$ExcelObj = New-Object -comobject Excel.Application
$currDate = Get-Date -Format "ddMMyyy HHmm"
$ExcelWorkBook = $ExcelObj.Workbooks.Open("https://smartholdingcom.sharepoint.com/sites/sbs_hr/Kpi/Files/ListQ42025.xlsx")#"C:\Temp\Example2023Q3.xlsx")
#$ExcelWorkBook | fl Name, Path, Author

#$ExcelWorkBook.Close($false)
#$ExcelObj.Quit()

$nameFileException = "C:\Temp\ErrorCreateKPI"+$currDate+".txt"

"Start create " | Out-File -FilePath $nameFileException -Append

#region init class  
class Division {
    [string]$NameDivision
    [string]$NameManager
    [string]$EmailManger
}

class Employee {
    [string]$NameDivision
    [string]$NameEmployee
    [string]$EmailEmployee
    [string]$EmailManger
}
#endregion

#Create folder block Quarter and set permission Створення папок на квартал
Try {
    #region get SPO obj

    $Cred= Get-Credential
    #region Setup the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)
   
    $Web = $Ctx.web
    #endregion

    #region Get data Divisions
    $ExcelWorkSheet = $ExcelWorkBook.Sheets.Item("Division")   

    $countRow = ($ExcelWorkSheet.UsedRange.Rows).count


    $allDiv = @() 
    for ($var = 2; $var -le $countRow; $var++) {
        #$divis = New-Object -TypeName Division

        if ($ExcelWorkSheet.UsedRange.Cells($var,1).Text)
        {  
           #Write-Host "1"
           #Write-Host $ExcelWorkSheet.UsedRange.Cells($var,1).Text

            if ($ExcelWorkSheet.UsedRange.Cells($var,2).Text)
            {
                #Write-Host "2"
                #Write-Host $ExcelWorkSheet.UsedRange.Cells($var,2).Text
                if ($ExcelWorkSheet.UsedRange.Cells($var,3).Text)
                {
                    Try {
                        $User = $Web.EnsureUser($ExcelWorkSheet.UsedRange.Cells($var,3).Text)
                        $Ctx.load($User)
                        $Ctx.ExecuteQuery()
                    
                        $ExcelWorkSheet.UsedRange.Cells($var,3).Text
                        $divis = [Division]::new()

                        $divis.NameDivision = $ExcelWorkSheet.UsedRange.Cells($var,1).Text
                        $divis.NameManager = $ExcelWorkSheet.UsedRange.Cells($var,2).Text
                        $divis.EmailManger = $ExcelWorkSheet.UsedRange.Cells($var,3).Text

                        $allDiv += $divis
                    }
                    Catch {
                        Add-Content -Path $nameFileException -Value "Get Division - Not  EmailManger not correct (row $var column 3)"
                   }

                }
                else
                {
                    Add-Content -Path $nameFileException -Value "Get Division - Not fill EmailManger (row $var column 3)"
                }
            }
            else
            {
                Add-Content -Path $nameFileException -Value "Get Division - Not fill NameManager (row $var column 2)"
            }
        }
        else
        {
            Add-Content -Path $nameFileException -Value "Get Division -  Not fill NameDivision (row $var  column 1)"
        }

         <#$divis = [Division]::new()

        $divis.NameDivision = $ExcelWorkSheet.UsedRange.Cells(2,1).Text
      

        $divis | Add-Member -Name $ExcelWorkSheet.UsedRange.Cells(1,1).Text -Value $ExcelWorkSheet.UsedRange.Cells($var,1).Text -MemberType NoteProperty
        $divis | Add-Member -Name $ExcelWorkSheet.UsedRange.Cells(1,2).Text -Value $ExcelWorkSheet.UsedRange.Cells($var,2).Text -MemberType NoteProperty
        $divis | Add-Member -Name $ExcelWorkSheet.UsedRange.Cells(1,3).Text -Value $ExcelWorkSheet.UsedRange.Cells($var,3).Text -MemberType NoteProperty
        $allDiv += $divis#>
    }
     $allDiv
    #endregion

    #region Get data Employee
    $ExcelWorkSheet = $ExcelWorkBook.Sheets.Item("Employee")

    $countRow = ($ExcelWorkSheet.UsedRange.Rows).count
    $allEmpl = @() 
    for ($var = 2; $var -le $countRow; $var++) {
        if ($ExcelWorkSheet.UsedRange.Cells($var,1).Text)
        {
            Write-Host "not empty"

            $data = $allDiv |  Where-Object {$_.NameDivision -eq $ExcelWorkSheet.UsedRange.Cells($var,1).Text}
            if($data)
            {
                $data
                if ($ExcelWorkSheet.UsedRange.Cells($var,2).Text)
                {
                    if ($ExcelWorkSheet.UsedRange.Cells($var,3).Text)
                    {
                        Try {
                            $User = $Web.EnsureUser($ExcelWorkSheet.UsedRange.Cells($var,3).Text)
                            $Ctx.load($User)
                            $Ctx.ExecuteQuery()
                    
                            #$ExcelWorkSheet.UsedRange.Cells($var,3).Text
                        
                            if($ExcelWorkSheet.UsedRange.Cells($var,4).Text)
                            {
                              Try {
                                    $UserManager = $Web.EnsureUser($ExcelWorkSheet.UsedRange.Cells($var,4).Text)
                                    $Ctx.load($UserManager)
                                    $Ctx.ExecuteQuery()

                                    $empl = [Employee]::new()

                                    $empl.NameDivision = $ExcelWorkSheet.UsedRange.Cells($var,1).Text
                                    $empl.NameEmployee = $ExcelWorkSheet.UsedRange.Cells($var,2).Text
                                    $empl.EmailEmployee = $ExcelWorkSheet.UsedRange.Cells($var,3).Text
                                    $empl.EmailManger = $ExcelWorkSheet.UsedRange.Cells($var,4).Text

                                    $allEmpl += $empl

                                }
                                Catch {
                                    Add-Content -Path $nameFileException -Value "Get Employee - Not  EmailManger not correct (row $var column 3)"
                                }
  
                            }
                            else
                            {
                                Add-Content -Path $nameFileException -Value "Get Employee - Not fill EmailManger (row $var column 4)"
                            }
                        }
                        Catch {
                            Add-Content -Path $nameFileException -Value "Get Employee -Not  EmailEmployee not correct (row $var column 3)"
                        }

                    }
                    else
                    {
                        Add-Content -Path $nameFileException -Value "Get Employee -Not fill EmailEmployee(row $var column 3)"
                    }
                }
                else
                {
                    Add-Content -Path $nameFileException -Value "Get Employee - Not fill NameEmployee (row $var column 2)"
                }
            }
            else
            {
               Add-Content -Path $nameFileException -Value "Get Employee - Not  find Division (row $var column 3)"
 
            }


        }
        else
        {
            Add-Content -Path $nameFileException -Value "Get Employee - Not fill NameDivision (row $var  column 1)"
        }
    }  

    $allEmpl
    #endregion

    #region Create folder Quarter 
    $Url=$UrlFolderLib+$nameQuarter

    $Folder=$Ctx.Web.Folders.Add($Url)
    $Ctx.ExecuteQuery()
    write-host -f Green "Create Folder"  $Url
    #endregion

    #region create folder Division 
    foreach ($division in $allDiv)
    {
        $Url=$UrlFolderLib+$nameQuarter+"/"+$division.NameDivision

        $Folder=$Ctx.Web.Folders.Add($Url)
        $Ctx.ExecuteQuery()
        write-host -f Green "Create Folder"  $Url
    }
    #endregion

    #region create folder employee 
    foreach ($employee in $allEmpl)
    {
        $Url=$UrlFolderLib+$nameQuarter+"/"+$employee.NameDivision+"/"+ $employee.NameEmployee

         #$Url=$UrlFolderLib+$nameQuarter+"/"+$employee.NameDivision+"/"+ "Пашков Р. О."


        $Folder=$Ctx.Web.Folders.Add($Url)
        $Ctx.ExecuteQuery()
        write-host -f Green "Create Folder"  $Url
    }
    #endregion

    #region Get RoleDefinitions 
    <#$RoleDefColl=$Ctx.web.RoleDefinitions
    $Ctx.Load($RoleDefColl)
    $Ctx.ExecuteQuery()

    $RoleDefColl | Select -Property Name#>
    #endregion

    #region Set Permission for  folder Quarter 
    $FolderURLQuarter=$partUrlSite+$UrlFolderLib+$nameQuarter

    $FolderQuarter = $Web.GetFolderByServerRelativeUrl($FolderURLQuarter)
    $Ctx.Load($FolderQuarter)
    $Ctx.ExecuteQuery()

    #Break Permission inheritence of the folder - Keep all existing folder permissions & keep Item level permissions
    $FolderQuarter.ListItemAllFields.BreakRoleInheritance($False,$True)
    $Ctx.ExecuteQuery()
    Write-host -f Yellow "Folder's $($FolderURLQuarter) Permission inheritance broken..."

    $User = $Web.EnsureUser("spsitecoladm@smart-holding.com")
    $Ctx.load($User)
    $FolderQuarter.ListItemAllFields.RoleAssignments.GetByPrincipal($User).DeleteObject()
    $Ctx.ExecuteQuery()

    <#$PermissionLevelName="Read"
    $Role = $Ctx.Web.RoleDefinitions.GetByName($PermissionLevelName)#("Совместная работа")
    $RoleDB = New-Object Microsoft.Contribute.Client.RoleDefinitionBindingCollection($Ctx)
    $RoleDB.Add($Role)#>

    #set edit Permissions 
    foreach($grEdit in $arrGroupEdit)
    {
        $Group =$Web.SiteGroups.GetByName($grEdit)
        $Ctx.load($Group)
        $Ctx.ExecuteQuery()

        $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")#("Совместная работа")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)

        $GroupPermissions = $FolderQuarter.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
        $FolderQuarter.Update()
        $Ctx.ExecuteQuery()
     }
    Write-Host "Set edit Group  Permissions" -ForegroundColor DarkMagenta 

    #set read Permission arrGroupRead
    foreach($grRead in $arrGroupRead)
    {
        $Group =$Web.SiteGroups.GetByName($grRead)
        $Ctx.load($Group)
        $Ctx.ExecuteQuery()

        $Role = $Ctx.web.RoleDefinitions.GetByName("Read")#("Чтение")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)

        $GroupPermissions = $FolderQuarter.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
        $FolderQuarter.Update()
        $Ctx.ExecuteQuery()
     }
     Write-Host "Set read Group  Permissions" -ForegroundColor DarkMagenta 

     #set managers read Permissions
     foreach($managersDiv in $allDiv)
     {
        $managersDiv.EmailManger
        $User = $Web.EnsureUser($managersDiv.EmailManger)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

        $Role = $web.RoleDefinitions.GetByName("Read")#("Чтение")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
        
        #powershell add user to sharepoint online folder
        $UserPermissions = $FolderQuarter.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $FolderQuarter.Update()
        $Ctx.ExecuteQuery()
      } 
      Write-Host "Set read managers Permissions for FolderQuarter" -ForegroundColor DarkMagenta 

      #set managers read Permissions
     foreach($employee in $allEmpl)
     {
        $employee.EmailEmployee
        $User = $Web.EnsureUser($employee.EmailEmployee)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

        $Role = $web.RoleDefinitions.GetByName("Read")#("Чтение")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
        
        #powershell add user to sharepoint online folder
        $UserPermissions = $FolderQuarter.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $FolderQuarter.Update()
        $Ctx.ExecuteQuery()
      } 
      Write-Host "Set read Employee Permissions for FolderQuarter" -ForegroundColor DarkMagenta 


    #endregion

    #region Set Permission For Division 
    foreach ($division in $allDiv)
    {

        $FolderURL=$partUrlSite+$UrlFolderLib+$nameQuarter+"/"+$division.NameDivision
        Write-Host "----Start" $FolderURL

        $Folder = $Web.GetFolderByServerRelativeUrl($FolderURL)
        $Ctx.Load($Folder)
        $Ctx.ExecuteQuery()
     
        #Break Permission inheritence of the folder - Keep all existing folder permissions & keep Item level permissions
        $Folder.ListItemAllFields.BreakRoleInheritance($False,$True)
        $Ctx.ExecuteQuery()
        Write-host -f Yellow "Folder's Permission inheritance broken..."

        $User = $Web.EnsureUser("spsitecoladm@smart-holding.com")
        $Ctx.load($User)
        $Folder.ListItemAllFields.RoleAssignments.GetByPrincipal($User).DeleteObject()
        $Ctx.ExecuteQuery()

        $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")#("Совместная работа")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)

        #set edit Permissions 
        foreach($grEdit in $arrGroupEdit)
        {
            $Group =$Web.SiteGroups.GetByName($grEdit)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")#("Совместная работа")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        }
        Write-Host "Set edit Group  Permissions" -ForegroundColor DarkMagenta 

        #set read Permission
        foreach($grRead in $arrGroupRead)
        {
            $Group =$Web.SiteGroups.GetByName($grRead)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.web.RoleDefinitions.GetByName("Read")#("Чтение")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        }
        Write-Host "Set read Group  Permissions" -ForegroundColor DarkMagenta 

        #set Manager permission
        $User = $Web.EnsureUser($division.EmailManger)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

        $Role = $web.RoleDefinitions.GetByName("Read")#("Чтение")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
        
        #powershell add user to sharepoint online folder
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()

        Write-Host "Set read EmailManger  Permissions" -ForegroundColor DarkMagenta 

        #set Users permission
        $usersDiv = $allEmpl | Where-Object {$_.NameDivision -eq $division.NameDivision}
        foreach($usersRead in $usersDiv)
        {
        $usersRead.EmailEmployee
            $User = $Web.EnsureUser($usersRead.EmailEmployee)
            $Ctx.load($User)
            $Ctx.ExecuteQuery()

            $Role = $web.RoleDefinitions.GetByName("Read")#("Чтение")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)
        
            #powershell add user to sharepoint online folder
            $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        } 
        Write-Host "Set read users  Permissions" -ForegroundColor DarkMagenta 

        <#$Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")#("Совместная работа")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)#>

        <##set edit Permissions 
        foreach($grEdit in $arrGroupEdit)
        {
            $Group =$Web.SiteGroups.GetByName($grEdit)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")#("Совместная работа")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        }
        Write-Host "Set edit Group  Permissions" -ForegroundColor DarkMagenta #>
    
    }
    #endregion

    #region Set Permission For employee Folder
    Foreach($employeeF in $allEmpl)
    {
        $FolderURL=$partUrlSite+$UrlFolderLib+$nameQuarter+"/"+$employeeF.NameDivision+"/"+$employeeF.NameEmployee
        $FolderURL

        $Folder = $Web.GetFolderByServerRelativeUrl($FolderURL)
         #$Folder = $Web.GetFolderByServerRelativeUrl("/sites/sbs_hr/KPI/2025/Квартал 2/Центр юридичних сервісів/Берко Н.В")
        $Ctx.Load($Folder)
        $Ctx.ExecuteQuery()
     
        #Break Permission inheritence of the folder - Keep all existing folder permissions & keep Item level permissions
        $Folder.ListItemAllFields.BreakRoleInheritance($False,$True)
        $Ctx.ExecuteQuery()
        Write-host -f Yellow "Folder's Permission inheritance broken..."

        $User = $Web.EnsureUser("spsitecoladm@smart-holding.com")
        $Ctx.load($User)
        $Folder.ListItemAllFields.RoleAssignments.GetByPrincipal($User).DeleteObject()
        $Ctx.ExecuteQuery()

        $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")#("Совместная работа")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)

        #set edit Permissions 
        foreach($grEdit in $arrGroupEdit)
        {
            $Group =$Web.SiteGroups.GetByName($grEdit)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")#("Совместная работа")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        }
        Write-Host "Set edit Group  Permissions" -ForegroundColor Green 

        #set read Permission
        foreach($grRead in $arrGroupRead)
        {
            $Group =$Web.SiteGroups.GetByName($grRead)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.web.RoleDefinitions.GetByName("Read")#("Чтение")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        }
        Write-Host "Set read Group  Permissions" -ForegroundColor Green 

        #set Manager permission
        $User = $Web.EnsureUser($employeeF.EmailManger)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

        $Role = $web.RoleDefinitions.GetByName("Contribute")#("Совместная работа")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
        
        #powershell add user to sharepoint online folder
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()

        Write-Host "Set edit EmailManger  Permissions" -ForegroundColor Green 

        #set user permission
        $User = $Web.EnsureUser($employeeF.EmailEmployee)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

        $Role = $web.RoleDefinitions.GetByName("Contribute")#("Совместная работа")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
        
        #powershell add user to sharepoint online folder
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()

        Write-Host "Set edit EmailEmployee  Permissions" -ForegroundColor Green 
    }
    #endregion
}
Catch {
    write-host -f Red "Create folder block Quarter and set permission" $_.Exception.Message
}

$ExcelWorkBook.Close($false)
$ExcelObj.Quit()

###########################################################33
#region Create folder block Year and set permission
try
{
    #region Get Empl for year KPI
    $ExcelWorkSheet = $ExcelWorkBook.Sheets.Item("Year")   

    $countRow = ($ExcelWorkSheet.UsedRange.Rows).count
    $allEmplYear = @() 
    for ($var = 2; $var -le $countRow; $var++) {
        if ($ExcelWorkSheet.UsedRange.Cells($var,1).Text)
        {
            #Write-Host "not empty"
            if ($ExcelWorkSheet.UsedRange.Cells($var,2).Text)
            {
                if ($ExcelWorkSheet.UsedRange.Cells($var,3).Text)
                {
                    Try {
                        $User = $Web.EnsureUser($ExcelWorkSheet.UsedRange.Cells($var,3).Text)
                        $Ctx.load($User)
                        $Ctx.ExecuteQuery()
                    
                        #$ExcelWorkSheet.UsedRange.Cells($var,3).Text
                        
                        if($ExcelWorkSheet.UsedRange.Cells($var,4).Text)
                        {
                            Try {
                                $UserManager = $Web.EnsureUser($ExcelWorkSheet.UsedRange.Cells($var,4).Text)
                                $Ctx.load($UserManager)
                                $Ctx.ExecuteQuery()

                                $empl = [Employee]::new()

                                $empl.NameDivision = $ExcelWorkSheet.UsedRange.Cells($var,1).Text
                                $empl.NameEmployee = $ExcelWorkSheet.UsedRange.Cells($var,2).Text
                                $empl.EmailEmployee = $ExcelWorkSheet.UsedRange.Cells($var,3).Text
                                $empl.EmailManger = $ExcelWorkSheet.UsedRange.Cells($var,4).Text

                                $allEmplYear += $empl

                            }
                            Catch {
                                Add-Content -Path $nameFileException -Value "Get Year - Not  EmailManger not correct (row $var column 3)"
                            }
  
                        }
                        else
                        {
                            Add-Content -Path $nameFileException -Value "Get Year - Not fill EmailManger (row $var column 4)"
                        }
                    }
                    Catch {
                        Add-Content -Path $nameFileException -Value "Get Year  -Not  EmailEmployee not correct (row $var column 3)"
                    }

                }
                else
                {
                    Add-Content -Path $nameFileException -Value "Get Year -Not fill EmailEmployee(row $var column 3)"
                }
            }
            else
            {
                Add-Content -Path $nameFileException -Value "Get Year - Not fill NameEmployee (row $var column 2)"
            }


        }
        else
        {
            Add-Content -Path $nameFileException -Value "Get Year - Not fill NameDivision (row $var  column 1)"
        }
    }  

    $allEmplYear
    #endregion
    
    #region Create folder for Year KPI "Річні" 
    $Url=$UrlFolderLib+$nameYear

    $Folder=$Ctx.Web.Folders.Add($Url)
    $Ctx.ExecuteQuery()
    write-host -f Green "Create Folder"  $Url
    #endregion
  
    #region create folder Emplo Year "Річні" 
    foreach ($empYear in $allEmplYear)
    {
        $Url=$UrlFolderLib+$nameYear+"/"+$empYear.NameEmployee

        $Folder=$Ctx.Web.Folders.Add($Url)
        $Ctx.ExecuteQuery()
        write-host -f Green "Create Folder"  $Url
    }
    #endregion

    #region Permission to folder Річні
    $FolderURL=$partUrlSite+$UrlFolderLib+$nameYear
    $FolderUR

    $Folder = $Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Break Permission inheritence of the folder - Keep all existing folder permissions & keep Item level permissions
    $Folder.ListItemAllFields.BreakRoleInheritance($False,$True)
    $Ctx.ExecuteQuery()
    Write-host -f Yellow "Folder's Permission inheritance broken..."

    $User = $Web.EnsureUser("spsitecoladm@smart-holding.com")
    $Ctx.load($User)
    $Folder.ListItemAllFields.RoleAssignments.GetByPrincipal($User).DeleteObject()
    $Ctx.ExecuteQuery()

    $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")
    $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
    $RoleDB.Add($Role)

    #set edit Permissions "Річні" 
    foreach($grEdit in $arrGroupEdit)
    {
        $Group =$Web.SiteGroups.GetByName($grEdit)
        $Ctx.load($Group)
        $Ctx.ExecuteQuery()

        $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)

        $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()
    }
    Write-Host "Set edit Group  Permissions Folder Richni" -ForegroundColor Green 

    #set read Permission "Річні" 
    foreach($grRead in $arrGroupRead)
    {
        $Group =$Web.SiteGroups.GetByName($grRead)
        $Ctx.load($Group)
        $Ctx.ExecuteQuery()

        $Role = $Ctx.web.RoleDefinitions.GetByName("Read")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)

        $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()
    }
    Write-Host "Set read Group  Permissions Folder Richni" -ForegroundColor Green 

    #Set Manager read Permission  "Річні" 
    $managerUniqyeValue = $allEmplYear | Sort-Object -Property EmailManger -Unique
    foreach($managerKPI in $managerUniqyeValue)
    {
        $User = $Web.EnsureUser($managerKPI.EmailManger)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

        $Role = $web.RoleDefinitions.GetByName("Read")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
        
        #powershell add user to sharepoint online folder
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()
    }
    Write-Host "Set read EmailManger  Permissions Folder Richni" -ForegroundColor Green 

    #Set User read Permission  "Річні" 
    foreach($emplKPI in $allEmplYear)
    {
        $User = $Web.EnsureUser($emplKPI.EmailEmployee)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

        $Role = $web.RoleDefinitions.GetByName("Read")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
        
        #powershell add user to sharepoint online folder
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()
    }    
    Write-Host "Set read EmailEmployee  Permissions Folder Richni" -ForegroundColor Green 

    #endregion

    #region Set Permission For employee Folder Річні KPI
    Foreach($employeeYearPerm in $allEmplYear)
    {
        $FolderURL=$partUrlSite+$UrlFolderLib+$nameYear+"/"+$employeeYearPerm.NameEmployee
        $FolderUR

        $Folder = $Web.GetFolderByServerRelativeUrl($FolderURL)
        $Ctx.Load($Folder)
        $Ctx.ExecuteQuery()
     
        #Break Permission inheritence of the folder - Keep all existing folder permissions & keep Item level permissions
        $Folder.ListItemAllFields.BreakRoleInheritance($False,$True)
        $Ctx.ExecuteQuery()
        Write-host -f Yellow "Folder's Permission inheritance broken..."

        $User = $Web.EnsureUser("spsitecoladm@smart-holding.com")
        $Ctx.load($User)
        $Folder.ListItemAllFields.RoleAssignments.GetByPrincipal($User).DeleteObject()
        $Ctx.ExecuteQuery()

        $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)

        #set edit Permissions employee Folder Річні KPI
        foreach($grEdit in $arrGroupEdit)
        {
            $Group =$Web.SiteGroups.GetByName($grEdit)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        }
        Write-Host "Set edit Group  Permissions employee Folder Річні KPI" -ForegroundColor Green 

        #set read Permission employee Folder Річні KPI
        foreach($grRead in $arrGroupRead)
        {
            $Group =$Web.SiteGroups.GetByName($grRead)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.web.RoleDefinitions.GetByName("Read")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        }
        Write-Host "Set read Group  Permissions employee Folder Річні KPI" -ForegroundColor Green 

        #set Manager permission
        $User = $Web.EnsureUser($employeeYearPerm.EmailManger)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

        $Role = $web.RoleDefinitions.GetByName("Contribute")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
        
        #powershell add user to sharepoint online folder
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()
         
        Write-Host "Set edit EmailManger  Permissions employee Folder Річні KPI" -ForegroundColor Green 

        #set user permission
        $User = $Web.EnsureUser($employeeYearPerm.EmailEmployee)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

        $Role = $web.RoleDefinitions.GetByName("Contribute")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
        
        #powershell add user to sharepoint online folder
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()

        Write-Host "Set edit EmailEmployee  Permissions employee Folder Річні KPI" -ForegroundColor Green 
    }
    #endregion
}
Catch {
    write-host -f Red "Create folder block Quarter and set permission" $_.Exception.Message
}


#endregion

#Add-Content -Path C:\Temp\first-file.txt -Value "This will be appended beneath the second line"

#Get the SharePoint Group & User
        $Group =$Web.SiteGroups.GetByName($GroupName)
        $User = $Web.EnsureUser($UserAccount)
        $Ctx.load($Group)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()
 
        #sharepoint online powershell set permissions on folder
        #Get the role required
        $Role = $web.RoleDefinitions.GetByName($PermissionLevel)
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
          
        #add sharepoint online group to folder using powershell
        $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
 
        #powershell add user to sharepoint online folder
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()