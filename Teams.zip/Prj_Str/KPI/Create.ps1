﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"

#Variable Year and URL
$UrlFolderLib= "KPI/"
$nameQuarter = "2023/Квартал 4"


#Variables SPO
$SiteURL="https://smartholdingcom.sharepoint.com/sites/sbs_hr" #Or https://crescent.sharepoint.com/sites/Marketing
$nameLibraryEng = "Kpi"
$nameLibraryUkr = "KPI"
$partUrlSite = "/sites/sbs_hr/"
#group for permission
$arrGroupEdit = "Керівник Центр сервісів з управління персоналом", "Провідний фахівець по роботі з персоналом"
$arrGroupRead = "Директор СБС"


$ExcelObj = New-Object -comobject Excel.Application
$currDate = Get-Date -Format "ddMMyyy HHmm"
$ExcelWorkBook = $ExcelObj.Workbooks.Open("C:\Temp\Example2023Q3.xlsx")

$nameFileException = "C:\Temp\ErrorCreateKPI"+$currDate+".txt"

"Start create " | Out-File -FilePath $nameFileException -Append


#$ExcelWorkBook | fl Name, Path, Author

$el = $ExcelWorkSheet.UsedRange.Cells(6,2).Text 
if ($el) { 'not empty' } else { 'empty' }


#region init class  
class Division {
    [string]$NameDivision
    [string]$NameManager
    [string]$EmailManger
}

class Employee {
    [string]$NameDivision
    [string]$NameEmployee
    [string]$EmailEmployee
    [string]$EmailManger
}
#endregion


Try {
    #region get SPO obj
    #$Cred= Get-Credential
    #$Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)

    $LoginName ="spsitecoladm@smart-holding.com"
    $LoginPassword ="uZ#RJpSS2%U9!PR"

    $SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
    $Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)
  
    #Setup the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = $Credentials
    $Web = $Ctx.web
    #endregion

    #region Get data Divisions
    $ExcelWorkSheet = $ExcelWorkBook.Sheets.Item("Division")   

    $countRow = ($ExcelWorkSheet.UsedRange.Rows).count
    $allDiv = @() 
    for ($var = 2; $var -le $countRow-1; $var++) {
        #$divis = New-Object -TypeName Division

        if ($ExcelWorkSheet.UsedRange.Cells($var,1).Text)
        {
            #Write-Host "not empty"

            if ($ExcelWorkSheet.UsedRange.Cells($var,2).Text)
            {
                if ($ExcelWorkSheet.UsedRange.Cells($var,3).Text)
                {
                    Try {
                        $User = $Web.EnsureUser($ExcelWorkSheet.UsedRange.Cells($var,3).Text)
                        $Ctx.load($User)
                        $Ctx.ExecuteQuery()
                    
                        $ExcelWorkSheet.UsedRange.Cells($var,3).Text
                        $divis = [Division]::new()

                        $divis.NameDivision = $ExcelWorkSheet.UsedRange.Cells($var,1).Text
                        $divis.NameManager = $ExcelWorkSheet.UsedRange.Cells($var,2).Text
                        $divis.EmailManger = $ExcelWorkSheet.UsedRange.Cells($var,3).Text

                        $allDiv += $divis
                    }
                    Catch {
                        Add-Content -Path $nameFileException -Value "Get Division - Not  EmailManger not correct (row $var column 3)"
                   }

                }
                else
                {
                    Add-Content -Path $nameFileException -Value "Get Division - Not fill EmailManger (row $var column 3)"
                }
            }
            else
            {
                Add-Content -Path $nameFileException -Value "Get Division - Not fill NameManager (row $var column 2)"
            }
        }
        else
        {
            Add-Content -Path $nameFileException -Value "Get Division -  Not fill NameDivision (row $var  column 1)"
        }

         <#$divis = [Division]::new()

        $divis.NameDivision = $ExcelWorkSheet.UsedRange.Cells(2,1).Text
      

        $divis | Add-Member -Name $ExcelWorkSheet.UsedRange.Cells(1,1).Text -Value $ExcelWorkSheet.UsedRange.Cells($var,1).Text -MemberType NoteProperty
        $divis | Add-Member -Name $ExcelWorkSheet.UsedRange.Cells(1,2).Text -Value $ExcelWorkSheet.UsedRange.Cells($var,2).Text -MemberType NoteProperty
        $divis | Add-Member -Name $ExcelWorkSheet.UsedRange.Cells(1,3).Text -Value $ExcelWorkSheet.UsedRange.Cells($var,3).Text -MemberType NoteProperty
        $allDiv += $divis#>
    }
     $allDiv
    #endregion

    #region Get data Employee
    $ExcelWorkSheet = $ExcelWorkBook.Sheets.Item("Employee")

    $countRow = ($ExcelWorkSheet.UsedRange.Rows).count
    $allEmpl = @() 
    for ($var = 2; $var -le $countRow; $var++) {
        if ($ExcelWorkSheet.UsedRange.Cells($var,1).Text)
        {
            #Write-Host "not empty"

            $data = $allDiv |  Where-Object {$_.NameDivision -eq $ExcelWorkSheet.UsedRange.Cells($var,1).Text}
            if($data)
            {
                #$data
                if ($ExcelWorkSheet.UsedRange.Cells($var,2).Text)
                {
                    if ($ExcelWorkSheet.UsedRange.Cells($var,3).Text)
                    {
                        Try {
                            $User = $Web.EnsureUser($ExcelWorkSheet.UsedRange.Cells($var,3).Text)
                            $Ctx.load($User)
                            $Ctx.ExecuteQuery()
                    
                            #$ExcelWorkSheet.UsedRange.Cells($var,3).Text
                        
                            if($ExcelWorkSheet.UsedRange.Cells($var,4).Text)
                            {
                              Try {
                                    $UserManager = $Web.EnsureUser($ExcelWorkSheet.UsedRange.Cells($var,4).Text)
                                    $Ctx.load($UserManager)
                                    $Ctx.ExecuteQuery()

                                    $empl = [Employee]::new()

                                    $empl.NameDivision = $ExcelWorkSheet.UsedRange.Cells($var,1).Text
                                    $empl.NameEmployee = $ExcelWorkSheet.UsedRange.Cells($var,2).Text
                                    $empl.EmailEmployee = $ExcelWorkSheet.UsedRange.Cells($var,3).Text
                                    $empl.EmailManger = $ExcelWorkSheet.UsedRange.Cells($var,4).Text

                                    $allEmpl += $empl

                                }
                                Catch {
                                    Add-Content -Path $nameFileException -Value "Get Employee - Not  EmailManger not correct (row $var column 3)"
                                }
  
                            }
                            else
                            {
                                Add-Content -Path $nameFileException -Value "Get Employee - Not fill EmailManger (row $var column 4)"
                            }
                        }
                        Catch {
                            Add-Content -Path $nameFileException -Value "Get Employee -Not  EmailEmployee not correct (row $var column 3)"
                        }

                    }
                    else
                    {
                        Add-Content -Path $nameFileException -Value "Get Employee -Not fill EmailEmployee(row $var column 3)"
                    }
                }
                else
                {
                    Add-Content -Path $nameFileException -Value "Get Employee - Not fill NameEmployee (row $var column 2)"
                }
            }
            else
            {
               Add-Content -Path $nameFileException -Value "Get Employee - Not  find Division (row $var column 3)"
 
            }


        }
        else
        {
            Add-Content -Path $nameFileException -Value "Get Employee - Not fill NameDivision (row $var  column 1)"
        }
    }  

    $allEmpl
    #endregion

    #region Create folder Quarter 
    $Url=$UrlFolderLib+$nameQuarter

    $Folder=$Ctx.Web.Folders.Add($Url)
    $Ctx.ExecuteQuery()
    write-host -f Green "Create Folder"  $Url
    #endregion

    #region create folder Division 
    foreach ($division in $allDiv)
    {
        $Url=$UrlFolderLib+$nameQuarter+"/"+$division.NameDivision

        $Folder=$Ctx.Web.Folders.Add($Url)
        $Ctx.ExecuteQuery()
        write-host -f Green "Create Folder"  $Url
    }
    #endregion

    #region create folder employee 
    foreach ($employee in $allEmpl)
    {
        $Url=$UrlFolderLib+$nameQuarter+"/"+$employee.NameDivision+"/"+ $employee.NameEmployee

        $Folder=$Ctx.Web.Folders.Add($Url)
        $Ctx.ExecuteQuery()
        write-host -f Green "Create Folder"  $Url
    }
    #endregion

    #region Set Permission For Division 
    foreach ($division in $allDiv)
    {
        
        $FolderURL=$partUrlSite+$UrlFolderLib+$nameQuarter+"/"+$division.NameDivision

        $Folder = $Web.GetFolderByServerRelativeUrl($FolderURL)
        $Ctx.Load($Folder)
        $Ctx.ExecuteQuery()
     
        #Break Permission inheritence of the folder - Keep all existing folder permissions & keep Item level permissions
        $Folder.ListItemAllFields.BreakRoleInheritance($False,$True)
        $Ctx.ExecuteQuery()
        Write-host -f Yellow "Folder's Permission inheritance broken..."

        $User = $Web.EnsureUser("spsitecoladm@smart-holding.com")
        $Ctx.load($User)
        $Folder.ListItemAllFields.RoleAssignments.GetByPrincipal($User).DeleteObject()
        $Ctx.ExecuteQuery()

        $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)

        #set edit Permissions 
        foreach($grEdit in $arrGroupEdit)
        {
            $Group =$Web.SiteGroups.GetByName($grEdit)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        }
        Write-Host "Set edit Group  Permissions" -ForegroundColor DarkMagenta 

        #set read Permission
        foreach($grRead in $arrGroupRead)
        {
            $Group =$Web.SiteGroups.GetByName($grRead)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.web.RoleDefinitions.GetByName("Read")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        }
        Write-Host "Set read Group  Permissions" -ForegroundColor DarkMagenta 

        #set Manager permission
        $User = $Web.EnsureUser($division.EmailManger)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

        $Role = $web.RoleDefinitions.GetByName("Read")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
        
        #powershell add user to sharepoint online folder
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()

        Write-Host "Set read EmailManger  Permissions" -ForegroundColor DarkMagenta 

        #set Users permission
        $usersDiv = $allEmpl | Where-Object {$_.NameDivision -eq $division.NameDivision}
        foreach($usersRead in $usersDiv)
        {
        $usersRead.EmailEmployee
            $User = $Web.EnsureUser($usersRead.EmailEmployee)
            $Ctx.load($User)
            $Ctx.ExecuteQuery()

            $Role = $web.RoleDefinitions.GetByName("Read")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)
        
            #powershell add user to sharepoint online folder
            $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        } 
        Write-Host "Set read users  Permissions" -ForegroundColor DarkMagenta 

        $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)

        #set edit Permissions 
        foreach($grEdit in $arrGroupEdit)
        {
            $Group =$Web.SiteGroups.GetByName($grEdit)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        }
        Write-Host "Set edit Group  Permissions" -ForegroundColor DarkMagenta 
    
    }
    #endregion

    #region Set Permission For employee Folder
    Foreach($employeeF in $allEmpl)
    {
        $FolderURL=$partUrlSite+$UrlFolderLib+$nameQuarter+"/"+$employeeF.NameDivision+"/"+$employeeF.NameEmployee
        $FolderUR

        $Folder = $Web.GetFolderByServerRelativeUrl($FolderURL)
        $Ctx.Load($Folder)
        $Ctx.ExecuteQuery()
     
        #Break Permission inheritence of the folder - Keep all existing folder permissions & keep Item level permissions
        $Folder.ListItemAllFields.BreakRoleInheritance($False,$True)
        $Ctx.ExecuteQuery()
        Write-host -f Yellow "Folder's Permission inheritance broken..."

        $User = $Web.EnsureUser("spsitecoladm@smart-holding.com")
        $Ctx.load($User)
        $Folder.ListItemAllFields.RoleAssignments.GetByPrincipal($User).DeleteObject()
        $Ctx.ExecuteQuery()

        $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)

        #set edit Permissions 
        foreach($grEdit in $arrGroupEdit)
        {
            $Group =$Web.SiteGroups.GetByName($grEdit)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.web.RoleDefinitions.GetByName("Contribute")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        }
        Write-Host "Set edit Group  Permissions" -ForegroundColor Green 

        #set read Permission
        foreach($grRead in $arrGroupRead)
        {
            $Group =$Web.SiteGroups.GetByName($grRead)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            $Role = $Ctx.web.RoleDefinitions.GetByName("Read")
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
            $Folder.Update()
            $Ctx.ExecuteQuery()
        }
        Write-Host "Set read Group  Permissions" -ForegroundColor Green 

        #set Manager permission
        $User = $Web.EnsureUser($employeeF.EmailManger)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

        $Role = $web.RoleDefinitions.GetByName("Contribute")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
        
        #powershell add user to sharepoint online folder
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()

        Write-Host "Set edit EmailManger  Permissions" -ForegroundColor Green 

        #set user permission
        $User = $Web.EnsureUser($employeeF.EmailEmployee)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

        $Role = $web.RoleDefinitions.GetByName("Contribute")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
        
        #powershell add user to sharepoint online folder
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()

        Write-Host "Set edit EmailEmployee  Permissions" -ForegroundColor Green 
    }
    #endregion
}
Catch {
    write-host -f Red "Error Granting permission to  Folder!" $_.Exception.Message
}


#Add-Content -Path C:\Temp\first-file.txt -Value "This will be appended beneath the second line"

#Get the SharePoint Group & User
        $Group =$Web.SiteGroups.GetByName($GroupName)
        $User = $Web.EnsureUser($UserAccount)
        $Ctx.load($Group)
        $Ctx.load($User)
        $Ctx.ExecuteQuery()
 
        #sharepoint online powershell set permissions on folder
        #Get the role required
        $Role = $web.RoleDefinitions.GetByName($PermissionLevel)
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
          
        #add sharepoint online group to folder using powershell
        $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
 
        #powershell add user to sharepoint online folder
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()
        $Ctx.ExecuteQuery()