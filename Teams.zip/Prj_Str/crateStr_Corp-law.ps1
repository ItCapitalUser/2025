﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
 
#Variables for Processing
$SiteURL ="https://smartholdingcom.sharepoint.com/sites/sh_corp-law_gov" # "https://smartholdingcom.sharepoint.com/sites/testEmptySite" "https://smartholdingcom.sharepoint.com/sites/sh_corp-law_comp"
#https://smartholdingcom.sharepoint.com/sites/sh_corp-law_comp
#https://smartholdingcom.sharepoint.com/sites/sh_compl_main_demo
#region Description Gr Company
$arr_groupCompany = @(
    [PSCustomObject]@{Title = 'SMART ENERGY Group Residents of Ukraine'; Url = "GrSEUa"; arrFirstLevel = "arr_folderFirstLevelGrSEUa"}
    [PSCustomObject]@{Title = 'SMART ENERGY Group Non-residents of Ukraine'; Url = "GrSENonRUa"; arrFirstLevel = "arr_folderFirstLevelGrSENonRUa"}

    [PSCustomObject]@{Title = 'SMART STEEL Group Non-residents of Ukraine'; Url = "GrSSNonRUa"; arrFirstLevel = "arr_folderFirstLevelGrSSNonRUa"}

    [PSCustomObject]@{Title = 'SMART MARITIME Group Residents of Ukraine'; Url = "GrSMGUa"; arrFirstLevel = "arr_folderFirstLevelGrSMGUa"}

    [PSCustomObject]@{Title = 'SMART HOLDING Group Residents of Ukraine'; Url = "GrSHUa"; arrFirstLevel = "arr_folderFirstLevelGrSHUa"}
    [PSCustomObject]@{Title = 'SMART HOLDING Group Non-residents of Ukraine'; Url = "GrSHNonRUa"; arrFirstLevel = "arr_folderFirstLevelGrSHNonRUa"}

    [PSCustomObject]@{Title = 'REAL ESTATE Group (SH) Residents of Ukraine'; Url = "GrRESHUa"; arrFirstLevel = "arr_folderFirstLevelGrRESHUa"}
    [PSCustomObject]@{Title = 'REAL ESTATE Group (SH) Non-residents of Ukraine'; Url = "GrRESHNonRUa"; arrFirstLevel = "arr_folderFirstLevelGrRESHNonRUa"}

    [PSCustomObject]@{Title = 'REAL ESTATE Group (SI) Residents of Ukraine'; Url = "GrRESIUa"; arrFirstLevel = "arr_folderFirstLevelGrRESIUa"}
    [PSCustomObject]@{Title = 'REAL ESTATE Group (SI) Non-residents of Ukraine'; Url = "GrRESINonRUa"; arrFirstLevel = "arr_folderFirstLevelGrRESINonRUa"}

    [PSCustomObject]@{Title = 'INDUSTRIAL PARK Group Residents of Ukraine'; Url = "GrIPUa"; arrFirstLevel = "arr_folderFirstLevelGrIPUa"}

    [PSCustomObject]@{Title = 'SMART INVESTMENTS Group Residents of Ukraine'; Url = "GrSIUa"; arrFirstLevel = "arr_folderFirstLevelGrSIUa"}
    [PSCustomObject]@{Title = 'SMART INVESTMENTS Group Non-residents of Ukraine'; Url = "GrSINonRUa"; arrFirstLevel = "arr_folderFirstLevelGrSINonRUa"}

    [PSCustomObject]@{Title = 'IF SMART Group Residents of Ukraine'; Url = "GrIFSUa"; arrFirstLevel = "arr_folderFirstLevelGrIFSUa"}
    [PSCustomObject]@{Title = 'IF SMART Group Non-residents of Ukraine'; Url = "GrIFSNonRUa"; arrFirstLevel = "arr_folderFirstLevelGrIFSNonRUa"}

    [PSCustomObject]@{Title = 'VERES Group Residents of Ukraine'; Url = "GrVUa"; arrFirstLevel = "arr_folderFirstLevelGrVUa"}
    [PSCustomObject]@{Title = 'VERES Group Non-residents of Ukraine'; Url = "GrVNonRUa"; arrFirstLevel = "arr_folderFirstLevelGrVNonRUa"}
)

$arr_groupCompany = @(
    [PSCustomObject]@{Title = 'SMART ENERGY Group Non-residents of Ukraine'; Url = "GrSENonRUa"; arrFirstLevel = "arr_folderFirstLevelGrSENonRUa"; Group = 1; TypeResd=1}
    [PSCustomObject]@{Title = 'SMART ENERGY Group Residents of Ukraine'; Url = "GrSEUa"; arrFirstLevel = "arr_folderFirstLevelGrSEUa"; Group = 1; TypeResd=2}

    [PSCustomObject]@{Title = 'SMART STEEL Group Non-residents of Ukraine'; Url = "GrSSNonRUa"; arrFirstLevel = "arr_folderFirstLevelGrSSNonRUa"; Group = 2; TypeResd=1}

    [PSCustomObject]@{Title = 'SMART MARITIME Group Residents of Ukraine'; Url = "GrSMGUa"; arrFirstLevel = "arr_folderFirstLevelGrSMGUa"; Group = 3; TypeResd=2}

    [PSCustomObject]@{Title = 'SMART HOLDING Group Non-residents of Ukraine'; Url = "GrSHNonRUa"; arrFirstLevel = "arr_folderFirstLevelGrSHNonRUa";  Group = 4; TypeResd=1}
    [PSCustomObject]@{Title = 'SMART HOLDING Group Residents of Ukraine'; Url = "GrSHUa"; arrFirstLevel = "arr_folderFirstLevelGrSHUa";  Group = 4; TypeResd=2}

    [PSCustomObject]@{Title = 'REAL ESTATE Group (SH) Non-residents of Ukraine'; Url = "GrRESHNonRUa"; arrFirstLevel = "arr_folderFirstLevelGrRESHNonRUa";  Group = 5; TypeResd=1}
    [PSCustomObject]@{Title = 'REAL ESTATE Group (SH) Residents of Ukraine'; Url = "GrRESHUa"; arrFirstLevel = "arr_folderFirstLevelGrRESHUa";  Group = 5; TypeResd=2}

    [PSCustomObject]@{Title = 'REAL ESTATE Group (SI) Non-residents of Ukraine'; Url = "GrRESINonRUa"; arrFirstLevel = "arr_folderFirstLevelGrRESINonRUa";  Group = 6; TypeResd=1}
    [PSCustomObject]@{Title = 'REAL ESTATE Group (SI) Residents of Ukraine'; Url = "GrRESIUa"; arrFirstLevel = "arr_folderFirstLevelGrRESIUa";  Group = 6; TypeResd=2}

    [PSCustomObject]@{Title = 'INDUSTRIAL PARK Group Residents of Ukraine'; Url = "GrIPUa"; arrFirstLevel = "arr_folderFirstLevelGrIPUa";  Group = 7; TypeResd=2}

    [PSCustomObject]@{Title = 'SMART INVESTMENTS Group Non-residents of Ukraine'; Url = "GrSINonRUa"; arrFirstLevel = "arr_folderFirstLevelGrSINonRUa";  Group = 8; TypeResd=1}
    [PSCustomObject]@{Title = 'SMART INVESTMENTS Group Residents of Ukraine'; Url = "GrSIUa"; arrFirstLevel = "arr_folderFirstLevelGrSIUa";  Group = 8; TypeResd=2}

    [PSCustomObject]@{Title = 'IF SMART Group Non-residents of Ukraine'; Url = "GrIFSNonRUa"; arrFirstLevel = "arr_folderFirstLevelGrIFSNonRUa";  Group = 9; TypeResd=1}
    [PSCustomObject]@{Title = 'IF SMART Group Residents of Ukraine'; Url = "GrIFSUa"; arrFirstLevel = "arr_folderFirstLevelGrIFSUa";  Group = 9; TypeResd=2}

    [PSCustomObject]@{Title = 'VERES Group Non-residents of Ukraine'; Url = "GrVNonRUa"; arrFirstLevel = "arr_folderFirstLevelGrVNonRUa";  Group = 10; TypeResd=1}
    [PSCustomObject]@{Title = 'VERES Group Residents of Ukraine'; Url = "GrVUa"; arrFirstLevel = "arr_folderFirstLevelGrVUa";  Group = 10; TypeResd=2}
)
$arr_grCompanyForMenu = @(
    [PSCustomObject]@{Title = 'SMART ENERGY Group'; id=1; NavigNum=1}
    [PSCustomObject]@{Title = 'SMART STEEL Group'; id=2; NavigNum=2}
    [PSCustomObject]@{Title = 'SMART MARITIME Group'; id=3; NavigNum=3}
    [PSCustomObject]@{Title = 'SMART HOLDING Group'; id=4; NavigNum=4}
    [PSCustomObject]@{Title = 'REAL ESTATE Group (SH)'; id=5; NavigNum=5}
    [PSCustomObject]@{Title = 'REAL ESTATE Group (SI)'; id=6; NavigNum=6}
    [PSCustomObject]@{Title = 'INDUSTRIAL PARK Group'; id=7; NavigNum=7}
    [PSCustomObject]@{Title = 'SMART INVESTMENTS Group'; id=8; NavigNum=8}
    [PSCustomObject]@{Title = 'IF SMART Group'; id=9; NavigNum=9}
    [PSCustomObject]@{Title = 'VERES Group'; id=10; NavigNum=10}
)

$arr_typeResidentsComp = @(
    [PSCustomObject]@{Title = 'Non-residents of Ukraine'; id=1; shTitle="UA Non-residents"}
    [PSCustomObject]@{Title = 'Residents of Ukraine'; id=2; shTitle="UA Residents"}
)
#"SMART ENERGY Group", "SMART STEEL Group", "SMART MARITIME Group", "SMART HOLDING Group"

$arr_folderFirstLevelGrSENonRUa = @(
    [PSCustomObject]@{Name = 'SMART ENERGY (CY) LTD (CYP)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'ENWELL ENERGY PLC (GB)'; Ordinal = "2"}
    [PSCustomObject]@{Name = 'REGAL PETROLEUM CORPORATION LTD (JEY)'; Ordinal = "3"}
    [PSCustomObject]@{Name = 'SMART ENERGY B.V. (NLD)'; Ordinal = "4"}
)

$arr_folderFirstLevelGrSEUa = @(
    [PSCustomObject]@{Name = 'SMART ENERGY LLC (UKR)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'UKRGAZVYDOBUTOK PRAT (UKR)'; Ordinal = "2"}
    [PSCustomObject]@{Name = 'REPRESENTATIVE REGAL PETROLEUM (UKR)'; Ordinal = "3"}
    [PSCustomObject]@{Name = 'REGAL PETROLEUM CORPORATION (UKR.) LIMITED LLC (UKR)'; Ordinal = "4"}
    [PSCustomObject]@{Name = 'PROM-ENERHO PRODUKT LLC (UKR)'; Ordinal = "5"}
    [PSCustomObject]@{Name = 'ARKONA GAS-ENERGY LLC (UKR)'; Ordinal = "6"}
    [PSCustomObject]@{Name = 'WELL INVESTUM LLC (UKR)'; Ordinal = "7"}
)

$arr_folderFirstLevelGrSSNonRUa = @(
    [PSCustomObject]@{Name = 'SMART STEEL LTD (CYP)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'METINVEST B.V. (NLD)'; Ordinal = "2"}
)

$arr_folderFirstLevelGrSMGUa = @(
    [PSCustomObject]@{Name = 'SMART MARITIME ACTIVE LLC (UKR)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'SMART MARITIME GROUP LLC (UKR)'; Ordinal = "2"}
)

$arr_folderFirstLevelGrSHNonRUa = @(
    [PSCustomObject]@{Name = 'SMART HOLDING (CYPRUS) LTD'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'SMART CORPORATE SERVICE LTD (CYP)'; Ordinal = "2"}
    [PSCustomObject]@{Name = 'ERISTA LIMITED (CYP)'; Ordinal = "3"}
)

$arr_folderFirstLevelGrSHUa = @(
    [PSCustomObject]@{Name = 'SMART- HOLDING LLC (UKR)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'IT CAPITAL LLC (UKR)'; Ordinal = "2"}
    [PSCustomObject]@{Name = 'SMART BUSINESS SERVICE LLC (UKR)'; Ordinal = "3"}
    [PSCustomObject]@{Name = 'PODIL 2000 LLC (UKR)'; Ordinal = "4"}
    [PSCustomObject]@{Name = 'SMART CORPORATE SERVICE REPRESENTATIVE (UKR)'; Ordinal = "5"}
    [PSCustomObject]@{Name = 'MBF Na chest Pokrovy Presvatoi Bogorodytsi (UKR)'; Ordinal = "6"}
    [PSCustomObject]@{Name = 'KHARKIVOBLENERGO JSC (UKR)'; Ordinal = "7"}
    [PSCustomObject]@{Name = 'KHARKIVENERGOZBUT PrJSC (UKR)'; Ordinal = "8"}
)

$arr_folderFirstLevelGrRESHNonRUa = @(
    [PSCustomObject]@{Name = 'SMART URBAN SOLUTIONS (CYP)'; Ordinal = "1"}
)

$arr_folderFirstLevelGrRESHUa = @(
    [PSCustomObject]@{Name = 'SMART URBAN SOLUTIONS LLC (UKR)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'SEDVERS LLC (UKR)'; Ordinal = "2"}
    [PSCustomObject]@{Name = 'TROITSKIY PLAZA LLC (UKR)'; Ordinal = "3"}
    [PSCustomObject]@{Name = 'POWER BUILD DEVELOPMENT LLC (UKR)'; Ordinal = "4"}
    [PSCustomObject]@{Name = 'EUGENE LLC (UKR)'; Ordinal = "5"}
    [PSCustomObject]@{Name = 'PRODHIM-INDUSTRIYA LLC (UKR)'; Ordinal = "6"}
)

$arr_folderFirstLevelGrRESINonRUa = @(
    [PSCustomObject]@{Name = 'SMART RETAIL GROUP (CYP)'; Ordinal = "1"}
)

$arr_folderFirstLevelGrRESIUa = @(
    [PSCustomObject]@{Name = 'KOLUMBUS LLC (UKR)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'BS PROPERTY LLC (UKR)'; Ordinal = "2"}
    [PSCustomObject]@{Name = 'POLITRADE COMPANY LLC (UKR)'; Ordinal = "3"}
    [PSCustomObject]@{Name = 'EAST SOLUTION GROUP LLC (UKR)'; Ordinal = "4"}
    [PSCustomObject]@{Name = 'URBAN ACTIVITY LLC (UKR)'; Ordinal = "5"}
    [PSCustomObject]@{Name = 'MADERA DEVELOPMENT LLC (UKR)'; Ordinal = "6"}
)

$arr_folderFirstLevelGrIPUa = @(
    [PSCustomObject]@{Name = 'NAVAL LOGISTIC LLC (UKR)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'NAVAL PARK LLC (UKR)'; Ordinal = "2"}
    [PSCustomObject]@{Name = 'OCHAKIV PARK LLC (UKR)'; Ordinal = "3"}
    [PSCustomObject]@{Name = 'PORT OCHAKOV LLC (UKR)'; Ordinal = "4"}
)

$arr_folderFirstLevelGrSINonRUa = @(
    [PSCustomObject]@{Name = 'SMART INVESTMENTS (CY) LTD (CYP)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'SH FUNDING (CYP)'; Ordinal = "2"}
    [PSCustomObject]@{Name = 'JERAND HOLDINGS (BVI)'; Ordinal = "3"}
    [PSCustomObject]@{Name = 'AVELIZARO HOLDINGS (CYP)'; Ordinal = "4"}
    [PSCustomObject]@{Name = 'ITSH HOLDINGS GmbH (AUT)'; Ordinal = "5"}
)

$arr_folderFirstLevelGrSIUa = @(
    [PSCustomObject]@{Name = 'SMART LEASING LLC (UKR)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'SMART-EXPERT UKRAINE LLC (UKR)'; Ordinal = "2"}
    [PSCustomObject]@{Name = 'NAVY LLC (UKR)'; Ordinal = "3"}
    [PSCustomObject]@{Name = 'AZOV PETROLIUM LLC (UKR)'; Ordinal = "4"}
)

$arr_folderFirstLevelGrIFSNonRUa = @(
    [PSCustomObject]@{Name = 'IF SMART LTD (CYP)'; Ordinal = "1"}
)

$arr_folderFirstLevelGrIFSUa = @(
    [PSCustomObject]@{Name = 'INVESTMENT FUND SMART LLC (UKR)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'SMART GRANITE LLC (UKR)'; Ordinal = "2"}
    [PSCustomObject]@{Name = 'SOTON LLC (UKR)'; Ordinal = "3"}
    [PSCustomObject]@{Name = 'SMART VYDOBUTOK LLC (UKR)'; Ordinal = "4"}
    [PSCustomObject]@{Name = 'FESTLAND LLC (UKR)'; Ordinal = "5"}
    [PSCustomObject]@{Name = 'MODUS CAPITAL LLC (UKR)'; Ordinal = "6"}
    [PSCustomObject]@{Name = 'ACUS LLC (UKR)'; Ordinal = "7"}
    [PSCustomObject]@{Name = 'MEZHREGIONALNAYA PELETNAYA COMPANY LLC (UKR)'; Ordinal = "8"}
)

$arr_folderFirstLevelGrVNonRUa = @(
    [PSCustomObject]@{Name = 'VERES HOLDING LIMITED (CYP)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'VERES IP LIMITED (CYP)'; Ordinal = "2"}
    [PSCustomObject]@{Name = 'ALIMA ASIA LLC (KAZ)'; Ordinal = "3"}
)

$arr_folderFirstLevelGrVUa = @(
    [PSCustomObject]@{Name = 'VG TRADE LLC (UKR)'; Ordinal = "1"}
    [PSCustomObject]@{Name = 'VG FARMING LLC (UKR)'; Ordinal = "2"}
    [PSCustomObject]@{Name = 'VG AGRO LLC (UKR)'; Ordinal = "3"}
    [PSCustomObject]@{Name = 'VG PRODUCTION LLC (UKR)'; Ordinal = "4"}
    [PSCustomObject]@{Name = 'INVEST 2018 LLC (UKR)'; Ordinal = "5"}
    [PSCustomObject]@{Name = 'KORSUN LOGISTICS LLC (UKR)'; Ordinal = "6"}
    [PSCustomObject]@{Name = 'PONOMAR LLC (UKR)'; Ordinal = "7"}
)
#endregion

$arr_folderFirstLevel= "SMART CORPORATE SERVICE LTD", "SMART CORPORATE FINANCE LTD", "SMART HOLDING (CYPRUS) LTD"
$arr_folderSecondLevel= "2021", "2022", "2023", "2024"

$nameGrManagetDivision = "Керівник Дирекції корп прав"

$prefixesGroupCompliance="Compliance"
$prefixesGroupCorpGovern="Corp govern"
$prefixesGroupManagement = "Management"

$suffixWrite = "RW"
$suffixRead = "R"

#coll in doc lib
$NameColN="Ordinal"
$DisplayNameColN="N"
$DescriptionColN="Порядковий номер для сортування"



#Setup Credentials to connect
$Cred = Get-Credential
$Cred = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.UserName,$Cred.Password)
 
Function Add-NumberColumnToList()
{
    param
    (
        #[Parameter(Mandatory=$true)] [string] $SiteURL,
        [Parameter(Mandatory=$true)] [string] $ListName,
        [Parameter(Mandatory=$true)] [string] $Name,
        [Parameter(Mandatory=$true)] [string] $DisplayName,
        [Parameter(Mandatory=$true)] [Microsoft.SharePoint.Client.ClientRuntimeContext]$Ctx,
        [Parameter(Mandatory=$false)] [string] $Description=[string]::Empty,
        [Parameter(Mandatory=$false)] [string] $IsRequired = "FALSE",
        [Parameter(Mandatory=$false)] [string] $EnforceUniqueValues = "FALSE"

    )
 
    #Generate new GUID for Field ID
    $FieldID = New-Guid
 
    Try {
        #Setup the context
        #$Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
        #$Ctx.Credentials = $Credentials
         
        #Get the List
        $List = $Ctx.Web.Lists.GetByTitle($ListName)
        $Ctx.Load($List)
        $Ctx.ExecuteQuery()
 
        #Check if the column exists in list already
        $Fields = $List.Fields
        $Ctx.Load($Fields)
        $Ctx.executeQuery()
        $NewField = $Fields | where { ($_.Internalname -eq $Name) -or ($_.Title -eq $DisplayName) }
        if($NewField -ne $NULL) 
        {
            Write-host "Column $Name already exists in the List!" -f Yellow
        }
        else
        {
            $FieldSchema = "<Field Type='Number' ID='{$FieldID}' DisplayName='$DisplayName' Name='$Name' Description='$Description' Required='$IsRequired' EnforceUniqueValues='$EnforceUniqueValues' />"
            $NewField = $List.Fields.AddFieldAsXml($FieldSchema,$True,[Microsoft.SharePoint.Client.AddFieldOptions]::AddFieldInternalNameHint)
            $Ctx.ExecuteQuery()   
 
            Write-host "New Column Added to the List Successfully!" -ForegroundColor Green 
        }
    }
    Catch {
        write-host -f Red "Error Adding Column to List!" $_.Exception.Message
    }
}

Function Create-DocumentLibrary()
{
    param
    (
        #[Parameter(Mandatory=$true)] [string] $SiteURL,
        [Parameter(Mandatory=$true)] [string] $DocLibraryName,
        [Parameter(Mandatory=$true)] [string] $DocLibraryUrl,
        [Parameter(Mandatory=$true)] [Microsoft.SharePoint.Client.ClientRuntimeContext]$Ctx

    )    
    Try {
        #Setup Credentials to connect
 
        #Set up the context
        <#$Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL) 
        $Ctx.Credentials = $Credential#>
 
        #Get All Lists from the web
        $Lists = $Ctx.Web.Lists
        $Ctx.Load($Lists)
        $Ctx.ExecuteQuery()
  
        #Check if Library name doesn't exists already and create document library
        if(!($Lists.Title -contains $DocLibraryName))
        { 
            #create document library in sharepoint online powershell
            $ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
            $ListInfo.Title = $DocLibraryName
            $ListInfo.Url=$DocLibraryUrl
            $ListInfo.TemplateType = 101 #Document Library
            $List = $Ctx.Web.Lists.Add($ListInfo)
            $List.Update()
            $Ctx.ExecuteQuery()

            $List =  $Ctx.Web.Lists.GetByTitle($DocLibraryName);
            $List.OnQuickLaunch = 1;
            $List.Update()
            $Ctx.ExecuteQuery()
    
            write-host  -f Green "New Document Library  $DocLibraryName  has been created!"
        }
        else
        {
            Write-Host -f Yellow "List or Library '$DocLibraryName' already exist!"
        }
    }
    Catch {
        write-host -f Red "Error Creating Document Library!" $_.Exception.Message
    }
}

Function Create-Folder()
{
    param(
        [Parameter(Mandatory=$true)][string]$FolderName,
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.SecurableObject ]$ListObj
    )
 
    Try {
 
        #Check Folder Exists already
        $Folders = $ListObj.RootFolder.Folders
        $Ctx.Load($Folders)
        $Ctx.ExecuteQuery()

 
        #Get existing folder names
        $FolderNames = $Folders | Select -ExpandProperty Name
        if($FolderNames -contains $FolderName)
        {
            write-host "Folder Exists Already!" -ForegroundColor Yellow
        }
        else #powershell sharepoint online create folder if not exist
        {
            #sharepoint online create folder powershell
            $NewFolder = $List.RootFolder.Folders.Add($FolderName)
            $Ctx.ExecuteQuery()
            Write-host "Folder '$FolderName' Created Successfully!" -ForegroundColor Green
        }
        
    }
    Catch {
        write-host -f Red "Error Creating Folder!" $_.Exception.Message
    }
}

Function Create-Group()
{
    param(
        [Parameter(Mandatory=$true)][string]$GroupName,
        [Parameter(Mandatory=$true)][string]$PermissionLevel,
        [Parameter(Mandatory=$true)] [Microsoft.SharePoint.Client.ClientRuntimeContext]$CtxFunc
    )
 
    Try {
 
         $GroupInfo = New-Object Microsoft.SharePoint.Client.GroupCreationInformation
         $GroupInfo.Title = $GroupName     
         $Group = $CtxFunc.web.SiteGroups.Add($GroupInfo)
         $CtxFunc.ExecuteQuery()
 
            #Assign permission to the group
         $RoleDef = $CtxFunc.web.RoleDefinitions.GetByName($PermissionLevel)
         $RoleDefBind = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($CtxFunc)
         $RoleDefBind.Add($RoleDef)
         $CtxFunc.Load($CtxFunc.Web.RoleAssignments.Add($Group,$RoleDefBind))
         $CtxFunc.ExecuteQuery()

         write-Host "Group: $GroupName created successfully!" -ForegroundColor Green
    }
    Catch {
        write-host -f Red "Error Creating Group!" $_.Exception.Message
    }
}

Function Add-SPONavigationNode()
{
    Param(
        [Microsoft.SharePoint.Client.NavigationNodeCollection]$Navigation,
        [parameter(Mandatory=$false)][String]$ParentNodeTitle,
        [String]$Title,
        [String]$URL
    )
    #Populate New node data
    $NavigationNode = New-Object Microsoft.SharePoint.Client.NavigationNodeCreationInformation
    $NavigationNode.Title = $Title
    $NavigationNode.Url = $URL
    $NavigationNode.AsLastNode = $true

    #region Check level menu
   <# if($ParentNodeTitle -like "*/*")
    {
        $arrParentsNode = $ParentNodeTitle -split "/"
        $topNavigation = $Navigation
        for($i=0; $i -lt $arrParentsNode.count; $i++)
        {
            Write-Host "Part:" $arrParentsNode[$i]
            #$topNavigation
            $topNode = $topNavigation | Where-Object {$_.Title -eq $arrParentsNode[$i]}
            If($topNode -eq $null)
            {
                Write-Host "Don't find node $($arrParentsNode[$i])" -f Red
                return;
            }
            else
            {
                Write-Host "Get childrenNode" -f Green
                $Ctx.Load($topNode)
                $childrenNode = $topNode.Children
                $Ctx.Load($childrenNode)
                $Ctx.ExecuteQuery()

                $topNavigation = $childrenNode
            }
  
        }
        $ParentNode=$topNavigation
    }
    else
    {
        #Get the Parent Node
        $ParentNode = $Navigation | Where-Object {$_.Title -eq $ParentNodeTitle}
     }#>
    #endregion

    
 
    #Add New node to the navigation
    if( [string]::IsNullOrEmpty($ParentNodeTitle))
    {
        #Check if the Link with Title exists already
        $Node = $Navigation | Where-Object {$_.Title -eq $Title}
        If($Node -eq $Null)
        {
            #Add Link to Root node of the Navigation
            $Ctx.Load($Navigation.Add($NavigationNode))
            $Ctx.ExecuteQuery()
            Write-Host -f Green "New Navigation Node '$Title' Added to the Navigation Root!"
        }
        Else
        {
            Write-Host -f Yellow "Navigation Node '$Title' Already Exists in Root!"
        }
    }
    else
    {
        #Get the Parent Node
        #$Ctx.Load($ParentNode)
        #$Ctx.Load($ParentNode.Children)
        #$Ctx.ExecuteQuery()


        $arrParentsNode = $ParentNodeTitle -split "/"
        $topNavigation = $Navigation
        for($i=0; $i -lt $arrParentsNode.count; $i++)
        {
            Write-Host "Part:" $arrParentsNode[$i] -f Yellow
            #$topNavigation
            $topNode = $topNavigation | Where-Object {$_.Title -eq $arrParentsNode[$i]}
            If($topNode -eq $null)
            {
                Write-Host "Don't find node $($arrParentsNode[$i])" -f Red
                return;
            }
            else
            {
                Write-Host "Get childrenNode" -f Green
                $Ctx.Load($topNode)
                $childrenNode = $topNode.Children
                $Ctx.Load($childrenNode)
                $Ctx.ExecuteQuery()

                $topNavigation = $childrenNode
                $topNavigation
                Write-Host "-------------"
            }
  
        }

  
        $Node = $topNavigation  | Where-Object {$_.Title -eq $Title}
        If($Node -eq $Null)
        {
            Write-Host "==========="
            #Add Link to Parent Node
            $Ctx.Load($topNavigation.Add($NavigationNode))
            $Ctx.ExecuteQuery()
            Write-Host -f Green "New Navigation Link '$Title' Added to the Parent '$ParentNodeTitle'!"
        }
        Else
        {
            Write-Host -f Yellow "Navigation Node '$Title' Already Exists in Parnet Node '$ParentNodeTitle'!"
        }
    }#>
}

<#$QuickLaunch = $Ctx.Web.Navigation.QuickLaunch
    $Ctx.load($QuickLaunch)
    $Ctx.ExecuteQuery()


    Add-SPONavigationNode -Navigation $QuickLaunch -ParentNodeTitle  "Сервіси/Board Maps"  -Title "Te3" -URL "https://smartholdingcom.sharepoint.com/sites/sh_compl_main_demo" # -ParentNodeTitle  "Сервіси/Board Maps"#>


try
{
    
    #Initialize the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = $Cred

    $Web =  $Ctx.Web
    $Ctx.Load($Web)

    #Create DocLib by groupCompany
    Foreach($groupCom in $arr_groupCompany)
    {
       Write-Host "----------"$groupCom.Title
       Create-DocumentLibrary -DocLibraryName $groupCom.Title -DocLibraryUrl  $groupCom.Url -Ctx $Ctx
       Add-NumberColumnToList -ListName $groupCom.Title -Name $NameColN -DisplayName $DisplayNameColN -Description $DescriptionColN -Ctx $Ctx

    }    

    #region For Test
    #Get the Library by Name
    $List = $Ctx.Web.Lists.GetByTitle("SMART ENERGY Group Non-residents of Ukraine")
    $Ctx.Load($List)

    $io=$List.RootFolder
    $Ctx.Load($io)
    $Ctx.ExecuteQuery()

    $io.ServerRelativeUrl


    $InternalNameLib = "GrSENonRUa"
    $pathFolder2Level= $InternalNameLib +"/" + "yyy"

    Create-Folder  -FolderName $pathFolder2Level -ListObj $List
    $FileRelativeUrl = "/sites/sh_compl_main_demo/"+$pathFolder2Level
    $FileRelativeUrl = "/sites/sh_compl_main_demo/GrSENonRUa/yyy"

    $File = $Ctx.web.GetFolderByServerRelativeUrl($FileRelativeUrl)
        $Ctx.Load($File)
        $Ctx.ExecuteQuery()
 
        #Set Metadata of the File
        $ListItem = $File.ListItemAllFields
        $Ctx.Load(  $ListItem)
        $Ctx.ExecuteQuery()
        $Listitem["Ordinal"] = 2
                $ListItem.Update()
        $Ctx.ExecuteQuery()
    #endregion
    
    $Web =  $Ctx.Web
    $Ctx.Load($Web)

    #create Folders 
    Foreach($groupCom in $arr_groupCompany)
    {
        Write-Host "--- Start $($groupCom.Title)" -f Blue

        if (-not([string]::IsNullOrEmpty($groupCom.arrFirstLevel)))
        {
            Write-Host $groupCom.arrFirstLevel -ForegroundColor Yellow
            $List = $Ctx.Web.Lists.GetByTitle($groupCom.Title)
            $Ctx.Load($List)

            $RootF=$List.RootFolder
            $Ctx.Load($RootF)
            $Ctx.ExecuteQuery()
            
            $arr= Get-Variable $groupCom.arrFirstLevel
            ForEach($SubFolder in $arr.Value)
            {
                Write-Host "-- Start process create Folder $($SubFolder.Name)"
                $pathFolder1Level= $groupCom.Url +"/" + $SubFolder.Name
                Create-Folder  -FolderName $pathFolder1Level -ListObj $List
                Write-Host "++"$pathFolder1Level

                foreach ($folder2Level in $arr_folderSecondLevel)
                {
                     $pathFolder2Level= $pathFolder1Level +"/" + $folder2Level
                     Write-Host "+"$pathFolder2Level -f Magenta
                     Create-Folder  -FolderName $pathFolder2Level -ListObj $List
                }

                $FolderRelativeUrl = $RootF.ServerRelativeUrl +"/" + $SubFolder.Name
                Write-Host "------" $FolderRelativeUrl

                $Folder= $Ctx.web.GetFolderByServerRelativeUrl($FolderRelativeUrl)
                $Ctx.Load($Folder)
                $Ctx.ExecuteQuery()
 
                #Set Metadata of the File
                $ListItem = $Folder.ListItemAllFields
                $Ctx.Load($ListItem)
                $Ctx.ExecuteQuery()
                $Listitem["Ordinal"] = $SubFolder.Ordinal
                $ListItem.Update()
                $Ctx.ExecuteQuery()
            }
        }
    }

    #region For one Group
    <#foreach ($folder in $arr_folderFirstLevel)
    {
        $pathFolder1Level= $InternalNameLib +"/" + $folder
        Create-Folder  -FolderName $pathFolder1Level -ListObj $List

        foreach ($folder2Level in $arr_folderSecondLevel)
        {
             $pathFolder2Level= $pathFolder1Level +"/" + $folder2Level
             Create-Folder  -FolderName $pathFolder2Level -ListObj $List

        }
    }#>
    #endregion

    #region Create Node QuickLaunch
    #Get the Quick Launch Navigation of the web
    $QuickLaunch = $Ctx.Web.Navigation.QuickLaunch
    $Ctx.load($QuickLaunch)
    $Ctx.ExecuteQuery()

    #region Test Menu
    $ParentNode = $QuickLaunch | Where-Object {$_.Title -eq "Інтернет веб-сайти"}
   $Ctx.Load($ParentNode)
   $uuu = $ParentNode.Children
        $Ctx.Load($uuu)
        $Ctx.ExecuteQuery()

   $ParentNode = $uuu | Where-Object {$_.Title -eq "Smart Urban Group"}
   $Ctx.Load($ParentNode)
   $yyy = $ParentNode.Children
        $Ctx.Load($yyy)
        $Ctx.ExecuteQuery()

    Add-SPONavigationNode -Navigation $QuickLaunch -ParentNodeTitle  "Інтернет веб-сайти/Smart Urban Group"  -Title "Test" #-URL $FolderCompanyRelativeUrl

    #endregion

    $sortArrForMenu=$arr_grCompanyForMenu |Sort-Object -Property NavigNum

    foreach($grCompNode in $sortArrForMenu)
    {
        Write-Host "   Strart create menu item" -f Yellow
        $FirstNode=$grCompNode.Title
        Write-Host $FirstNode  " Id" $grCompNode.Id
        $idGroup =$grCompNode.Id
        $grCompForLibrary = $arr_groupCompany | Where-Object {$_.Group -eq $idGroup}

        If($grCompForLibrary -ne $null)
         {
            #Create First 
            Add-SPONavigationNode -Navigation $QuickLaunch -Title $FirstNode 
            Write-Host "Create first level Menu" -f Green
            Foreach($levelResidents in $grCompForLibrary)
            {
                Write-Host $levelResidents.TypeResd
                $nameResidGrCompany = $arr_typeResidentsComp | Where-Object {$_.id -eq $levelResidents.TypeResd}
                Write-Host "--- Create typeResidents" + $nameResidGrCompany.Title
                $nameTypeResidents = $nameResidGrCompany.Title

                
                if (-not([string]::IsNullOrEmpty($levelResidents.arrFirstLevel)))
                {
                    Write-Host $levelResidents.arrFirstLevel -ForegroundColor Yellow
                   $List = $Ctx.Web.Lists.GetByTitle($levelResidents.Title)
                    $RootFList = $List.RootFolder
                    $Ctx.Load( $RootFList)
                    $Ctx.ExecuteQuery()
                    $UrlList=  $RootFList.ServerRelativeUrl
                    Write-Host "Url List --- " + $UrlList

                    $SecondNode = $nameTypeResidents
                    Add-SPONavigationNode -Navigation $QuickLaunch -ParentNodeTitle  $FirstNode  -Title $SecondNode -URL $UrlList
                    Write-Host "Create Second level Menu" -f Green

                    $nameParentNode= $FirstNode+"/"+$SecondNode
                    Write-Host $nameParentNode -f Cyan

                    $arrCompForMenu= Get-Variable $levelResidents.arrFirstLevel
                    ForEach($subMenuComp in $arrCompForMenu.Value)
                    {
                        $nameFolder = $subMenuComp.Name
                        Write-Host "==== company $($nameFolder)"
                        $FolderCompanyRelativeUrl = $RootFList.ServerRelativeUrl +"/" + $subMenuComp.Name
                        
                        Write-Host "Url --- $( $FolderCompanyRelativeUrl)"
                        Add-SPONavigationNode -Navigation $QuickLaunch -ParentNodeTitle  $nameParentNode -Title $nameFolder -URL $FolderCompanyRelativeUrl
                        Write-Host "Create Company level Menu" -f Green
                    }

                }
            }
         }
        else
         {
            Write-Host "No" -f Red
         }
    
    }
    #endregion

    #region create Group 
    Write-Host "----- Srtart create group"
    $PermissionLevelForSite="Чтение"#"Read"
    $PermissionLevelManagDivis = "Совместная работа"#"Contribute"
    $PermissionLevelContribute ="Совместная работа"#"Contribute"
    $PermissionLevelRead="Чтение"#"Read"


    $Groups = $Ctx.Web.SiteGroups
    $Ctx.load($Groups)
    $Ctx.ExecuteQuery()
     
    $GroupNames =  $Groups | Select -ExpandProperty Title

    #Create Group for specialist
    Foreach($groupCom in $arr_groupCompany)
    {
        $groupName = $arr_grCompanyForMenu | Where-Object -Property id -eq $groupCom.Group
        $typeResidents = $arr_typeResidentsComp | Where-Object -Property id -eq $groupCom.TypeResd

        $nameGroup =  $groupName.Title +" " + $typeResidents.shTitle + " " + $suffixWrite #$prefixesGroupCorpGovern $prefixesGroupCompliance
        $nameGroup

        If($GroupNames -notcontains $nameGroup)
        {
            Create-Group -GroupName $nameGroup -PermissionLevel $PermissionLevelForSite -CtxFunc $Ctx
            write-host  -f Green "User Group has been Added Successfully!"
        }
        else
        {
            Write-host -f Yellow "Group Exists already!"
        }

     }

     Foreach($groupCom in $arr_groupCompany)
     {
         Write-Host "--- Start $($groupCom.Title)" -f Blue

        if (-not([string]::IsNullOrEmpty($groupCom.arrFirstLevel)))
        {
            $arrComp= Get-Variable $groupCom.arrFirstLevel
            ForEach($Company in $arrComp.Value)
            {
                $nameGroup = $prefixesGroupManagement + " " +$Company.Name + " " + $suffixRead #$prefixesGroupCorpGovern
                $nameGroup
                If($GroupNames -notcontains $nameGroup)
               {
                   Create-Group -GroupName $nameGroup -PermissionLevel $PermissionLevelForSite -CtxFunc $Ctx
                   write-host  -f Green "User Group has been Added Successfully!"
               }
               else
               {
                    Write-host -f Yellow "Group Exists already!"
                }
            }

        }
     }



    Create-Group -GroupName $nameGrManagetDivision -PermissionLevel $PermissionLevelManagDivis -CtxFunc $Ctx
    #endregion

    #region Set permissions doc library 
    Foreach($groupCom in $arr_groupCompany)
    {
        Write-Host "--- Start Perm $($groupCom.Title) ---"
        $List=$Ctx.Web.Lists.GetByTitle($groupCom.Title)
     
        #Break Permission inheritence - keep existing list permissions & Item level permissions
        $List.BreakRoleInheritance($False,$True)
        $Ctx.ExecuteQuery()
        Write-host -f Yellow "Doc Lib Permission inheritance broken..."

        $User = $Web.EnsureUser("vira.chorna@it-capital.com.ua")#spsitecoladm@smart-holding.com")
        $Ctx.load($User)
        $List.RoleAssignments.GetByPrincipal($User).DeleteObject()
        $Ctx.ExecuteQuery()
     
        #Get the group or user
        $GroupMamager =$Web.SiteGroups.GetByName($nameGrManagetDivision) #For User: $Web.EnsureUser('salaudeen@crescent.com')
        $Ctx.load($GroupMamager)
        $Ctx.ExecuteQuery()
 
        #Grant permission to Group    
        #Get the role required
        $Role = $web.RoleDefinitions.GetByName($PermissionLevelContribute)
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)
         
        #Assign list permissions to the group
        $PermissionsManager = $List.RoleAssignments.Add($GroupMamager,$RoleDB)
        #$List.Update()
        #$Ctx.ExecuteQuery()

        Write-Host "Added permission to $nameGrManagetDivision group in $($groupCom.Title) list. " -foregroundcolor Green
        $groupName = $arr_grCompanyForMenu | Where-Object -Property id -eq $groupCom.Group
        $typeResidents = $arr_typeResidentsComp | Where-Object -Property id -eq $groupCom.TypeResd

        $nameGroupEmpl =  $groupName.Title +" " + $typeResidents.shTitle + " " + $suffixWrite 
        
        $GroupComp =$Web.SiteGroups.GetByName($nameGroupEmpl) #For User: $Web.EnsureUser('salaudeen@crescent.com')
        $Ctx.load($GroupComp)
        $Ctx.ExecuteQuery()

        #Get the role required
        $Role = $web.RoleDefinitions.GetByName($PermissionLevelContribute)
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)

        $PermissionsComp = $List.RoleAssignments.Add($GroupComp,$RoleDB)
        $List.Update()
        $Ctx.ExecuteQuery()

        Write-Host "Added $PermissionLevelContribute permission to $nameGroupCompl group in  $($groupCom.Title) list. " -foregroundcolor Green

    }
    #endregion

    #region Test Perm Folder
      $List = $Ctx.Web.Lists.GetByTitle("SMART ENERGY Group Non-residents of Ukraine")
    $Ctx.Load($List)

    $io=$List.RootFolder
    $Ctx.Load($io)
    $Ctx.ExecuteQuery()

    $io.ServerRelativeUrl


    $InternalNameLib = "GrSENonRUa"
    $nameComTest="ENWELL ENERGY PLC (GB)"
    $pathFolder2Level= $InternalNameLib +"/" + "ENWELL ENERGY PLC (GB)"

    Create-Folder  -FolderName $pathFolder2Level -ListObj $List
    $FileRelativeUrl = "/sites/sh_compl_main_demo/"+$pathFolder2Level
    $FileRelativeUrl = "/sites/sh_compl_main_demo/GrSENonRUa/yyy"

     $Folder = $Web.GetFolderByServerRelativeUrl($pathFolder2Level)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()

     $Folder.ListItemAllFields.BreakRoleInheritance($True,$True)
    $Ctx.ExecuteQuery()
    Write-host -f Yellow "Folder's Permission inheritance broken..."

     $nameGroup = $prefixesGroupManagement + " " +$nameComTest + " " + $suffixRead #$prefixesGroupCorpGovern

      $GroupComp =$Web.SiteGroups.GetByName($nameGroup) #For User: $Web.EnsureUser('salaudeen@crescent.com')
      $Ctx.load($GroupComp)
      $Ctx.ExecuteQuery()

        #Get the role required
      $Role = $web.RoleDefinitions.GetByName($PermissionLevelRead)
      $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
      $RoleDB.Add($Role)

      $GroupPermissions  = $Folder.ListItemAllFields.RoleAssignments.Add($GroupComp,$RoleDB)
      $Folder.Update()
      $Ctx.ExecuteQuery()
    #endregion

    #region Set permission folder
    Foreach($librGrCom in $arr_groupCompany)
    {
        Write-Host "--- Start $($librGrCom.Title)" -f Blue

        if (-not([string]::IsNullOrEmpty($librGrCom.arrFirstLevel)))
        {
            $arrComp= Get-Variable $librGrCom.arrFirstLevel
            ForEach($Company in $arrComp.Value)
            {
                $pathFolderCompany = $librGrCom.Url +"/" + $Company.Name
                $pathFolderCompany

                $Folder = $Web.GetFolderByServerRelativeUrl($pathFolderCompany)
                $Ctx.Load($Folder)
                $Ctx.ExecuteQuery()

                $Folder.ListItemAllFields.BreakRoleInheritance($True,$True)
                $Ctx.ExecuteQuery()
                Write-host -f Yellow "Folder's Permission inheritance broken..."

                $nameGroup = $prefixesGroupManagement + " " + $Company.Name + " " + $suffixRead #$prefixesGroupCorpGovern

                $GroupComp =$Web.SiteGroups.GetByName($nameGroup) #For User: $Web.EnsureUser('salaudeen@crescent.com')
                $Ctx.load($GroupComp)
                $Ctx.ExecuteQuery()

                 #Get the role required
                $Role = $web.RoleDefinitions.GetByName($PermissionLevelRead)
                $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
                $RoleDB.Add($Role)

                $GroupPermissions  = $Folder.ListItemAllFields.RoleAssignments.Add($GroupComp,$RoleDB)
                $Folder.Update()
                $Ctx.ExecuteQuery()

                Write-Host "Added $PermissionLevelRead permission to $GroupComp group in  $pathFolderCompany " -foregroundcolor Green

    
            }
        }
    }
    #endregion
}
catch
{
    Write-Host -f Red "Error main block " $_.Exception.Message
}
