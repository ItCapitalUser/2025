﻿$cred= Add-PnPStoredCredential -Name https://smartholdingcom.sharepoint.com -Username spsitecoladm@smart-holding.com -Password (ConvertTo-SecureString -String "*" -AsPlainText -Force)
$siteurl="https://smartholdingcom.sharepoint.com/sites/FTI_SOTON_087"
Connect-PnPOnline -Url $siteurl -Credentials $cred
            
New-PnPList -Title "Стратегия" -Url "Strategy" -Template DocumentLibrary  -OnQuickLaunch 
Set-PnPList -Identity "Стратегия" -EnableVersioning $True  -MajorVersions 200  
Write-Host ("Стратегия is created ")

Add-PnPFolder -Name "Прочее" -Folder "/Strategy"
Add-PnPFolder -Name "Рабочие документы" -Folder "/Strategy"
Add-PnPFolder -Name "Операционная модель" -Folder "/Strategy"
Add-PnPFolder -Name "Инвестиции" -Folder "/Strategy"
Add-PnPFolder -Name "Стратегия и модель" -Folder "/Strategy"


New-PnPList -Title "Бюджет" -Url "Budget" -Template DocumentLibrary  -OnQuickLaunch 
Set-PnPList -Identity "Бюджет" -EnableVersioning $True  -MajorVersions 200  
Write-Host ("Бюджет is created ")

Add-PnPFolder -Name "Бюджет" -Folder "/Budget"
Add-PnPFolder -Name "Анализ бюджетных показателей" -Folder "/Budget"
Add-PnPFolder -Name "Регламентные документы" -Folder "/Budget"


New-PnPList -Title "Отчетность" -Url "Reporting" -Template DocumentLibrary  -OnQuickLaunch 
Set-PnPList -Identity "Отчетность" -EnableVersioning $True  -MajorVersions 200  
Write-Host ("Отчетность is created ")


New-PnPList -Title "Производство" -Url "Production" -Template DocumentLibrary  -OnQuickLaunch 
Set-PnPList -Identity "Производство" -EnableVersioning $True  -MajorVersions 200  
Write-Host ("Производство is created ")

New-PnPList -Title "Продажи" -Url "Sales" -Template DocumentLibrary  -OnQuickLaunch 
Set-PnPList -Identity "Продажи" -EnableVersioning $True  -MajorVersions 200  
Write-Host ("Продажи is created ")

Add-PnPFolder -Name "Операционная отчетность" -Folder "/Reporting"
Add-PnPFolder -Name "Финансовая отчетность" -Folder "/Reporting"
Add-PnPFolder -Name "Статистическая отчетность" -Folder "/Reporting"
Add-PnPFolder -Name "Налоговая отчетность" -Folder "/Reporting"
Add-PnPFolder -Name "Решения Правления" -Folder "/Reporting"
Add-PnPFolder -Name "Решения УК" -Folder "/Reporting"
Add-PnPFolder -Name "Решения ОС" -Folder "/Reporting"

Add-PnPFolder -Name "Технологические карты" -Folder "/Production"
Add-PnPFolder -Name "Производственная программа" -Folder "/Production"
Add-PnPFolder -Name "Охрана труда" -Folder "/Production"
Add-PnPFolder -Name "Прочее" -Folder "/Production"

Add-PnPFolder -Name "Базы данных" -Folder "/Sales"
Add-PnPFolder -Name "Статистика по рынку" -Folder "/Sales"
Add-PnPFolder -Name "Продуктовый микс" -Folder "/Sales"
Add-PnPFolder -Name "Конкуренты" -Folder "/Sales"
Add-PnPFolder -Name "Тендеры" -Folder "/Sales"
Add-PnPFolder -Name "Аналитика по продажам" -Folder "/Sales"
Add-PnPFolder -Name "Цены" -Folder "/Sales"


New-PnPList -Title "Закупки" -Url "Purchase" -Template DocumentLibrary  -OnQuickLaunch 
Set-PnPList -Identity "Закупки" -EnableVersioning $True  -MajorVersions 200  
Write-Host ("Закупки is created ")

New-PnPList -Title "Финансы" -Url "Finance" -Template DocumentLibrary  -OnQuickLaunch 
Set-PnPList -Identity "Финансы" -EnableVersioning $True  -MajorVersions 200  
Write-Host ("Финансы is created ")

New-PnPList -Title "Налоги" -Url "Tax" -Template DocumentLibrary  -OnQuickLaunch 
Set-PnPList -Identity "Налоги" -EnableVersioning $True  -MajorVersions 200  
Write-Host ("Налоги is created ")

Add-PnPFolder -Name "Базы данных" -Folder "/Purchase"
Add-PnPFolder -Name "Основные закупки" -Folder "/Purchase"
Add-PnPFolder -Name "Тендерная документация" -Folder "/Purchase"

Add-PnPFolder -Name "Финансовая стратегия" -Folder "/Finance"
Add-PnPFolder -Name "Банки" -Folder "/Finance"
Add-PnPFolder -Name "Размещение средств" -Folder "/Finance"
Add-PnPFolder -Name "Ликвидность" -Folder "/Finance"
Add-PnPFolder -Name "Контроллинг" -Folder "/Finance"
Add-PnPFolder -Name "Бюджетирование" -Folder "/Finance"

Add-PnPFolder -Name "Возмещение НДС" -Folder "/Tax"
Add-PnPFolder -Name "Налог на прибыль" -Folder "/Tax"
Add-PnPFolder -Name "Ресурсные платежи" -Folder "/Tax"
Add-PnPFolder -Name "Разъяснения" -Folder "/Tax"
Add-PnPFolder -Name "Прочее" -Folder "/Tax"

New-PnPList -Title "Юридические вопросы" -Url "LegalIssues" -Template DocumentLibrary  -OnQuickLaunch 
Set-PnPList -Identity "Юридические вопросы" -EnableVersioning $True  -MajorVersions 200  
Write-Host ("Юридические вопросы is created ")

New-PnPList -Title "HR" -Url "HR" -Template DocumentLibrary  -OnQuickLaunch 
Set-PnPList -Identity "HR" -EnableVersioning $True  -MajorVersions 200  
Write-Host ("HR is created ")

New-PnPList -Title "ИТ" -Url "IT" -Template DocumentLibrary  -OnQuickLaunch 
Set-PnPList -Identity "ИТ" -EnableVersioning $True  -MajorVersions 200  
Write-Host ("ИТ is created ")

New-PnPList -Title "Прочие" -Url "Other" -Template DocumentLibrary  -OnQuickLaunch 
Set-PnPList -Identity "Прочие" -EnableVersioning $True  -MajorVersions 200  
Write-Host ("Прочие is created ")

Add-PnPFolder -Name "Правовой комитет" -Folder "/LegalIssues"
Add-PnPFolder -Name "Уставные документы" -Folder "/LegalIssues"
Add-PnPFolder -Name "Правоустанавливающие документы" -Folder "/LegalIssues"
Add-PnPFolder -Name "Приказы по основной деятельности" -Folder "/LegalIssues"
Add-PnPFolder -Name "Типовые договоры" -Folder "/LegalIssues"
Add-PnPFolder -Name "Судебные споры, исполнительные производства" -Folder "/LegalIssues"
Add-PnPFolder -Name "Сертификация, лицензирование, иное" -Folder "/LegalIssues"
Add-PnPFolder -Name "Оценка" -Folder "/LegalIssues"
Add-PnPFolder -Name "Прочее" -Folder "/LegalIssues"

Add-PnPFolder -Name "HR комитет" -Folder "/HR"
Add-PnPFolder -Name "Организационная структура" -Folder "/HR"
Add-PnPFolder -Name "Эффективность и мотивация сотрудников" -Folder "/HR"
Add-PnPFolder -Name "Отчетность" -Folder "/HR"


Add-PnPFolder -Name "ИТ комитет" -Folder "/IT"
Add-PnPFolder -Name "Обслуживание" -Folder "/IT"
Add-PnPFolder -Name "Инфраструктура" -Folder "/IT"
Add-PnPFolder -Name "Учетная база" -Folder "/IT"
Add-PnPFolder -Name "Прочее" -Folder "/IT"
