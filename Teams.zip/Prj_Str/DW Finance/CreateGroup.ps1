﻿	
#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
  
#Variables for Processing
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/SEFinancial-Controlling"
$GroupName="Заместитель начальника отдела ФУ и НВН"
 
#Setup Credentials to connect
$Cred = Get-Credential

$Cred = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.UserName,$Cred.Password)

$LoginName ="spsitecoladm@smart-holding.com"
$LoginPassword ="uZ#RJpSS2%U9!PR"
 
#Setup the context
$Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
$Ctx.Credentials = $Cred
 
#sharepoint online create group powershell
$GroupInfo = New-Object Microsoft.SharePoint.Client.GroupCreationInformation
$GroupInfo.Title = $GroupName     
$Group = $Ctx.web.SiteGroups.Add($GroupInfo)
$Ctx.ExecuteQuery()

Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
    
#Variables for Processing
$SiteURL= "https://smartholdingcom.sharepoint.com/sites/testEmptySite"
$UserAccount = "irina.melnychuk@regalukraine.com"
$PermissionLevel = "Чтение"
$GroupName="МСФЗ"



#Setup Credentials to connect
$Cred = Get-Credential
$Cred = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.UserName,$Cred.Password)
 
Try {
    #Setup the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = $Cred
     
       
    #Get the Web
    $Web = $Ctx.Web
    $Ctx.Load($Web)
    $Ctx.ExecuteQuery()
 
    #Ensure the user
    $User=$web.EnsureUser($UserAccount)
    $Ctx.Load($User)
    $Ctx.ExecuteQuery()

   
 

    $Groups=$Ctx.Web.SiteGroups
    $Ctx.Load($Groups)
    $Ctx.ExecuteQuery()

    $gr=$Groups.GetByName($GroupName)
    $Ctx.Load($gr)
    $Ctx.ExecuteQuery()

     $Result = $gr.Users.AddUser($User)
    $Ctx.Load($Result)
    $Ctx.ExecuteQuery()
 
    #Get the Permission Level  
    $RoleDefinition = $web.RoleDefinitions.GetByName($PermissionLevel) 
    $RoleAssignment = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
    $RoleAssignment.Add($RoleDefinition)  
     
    #Assign Role Assignment to User
    $Permissions = $Web.RoleAssignments.Add( $gr,$RoleAssignment) 
    $Web.Update()
    $Ctx.ExecuteQuery()


   
    Write-host  -f Green "User '$UserAccount' has been Granted with Access '$PermissionLevel'!"
}
Catch {
    write-host -f Red "Error:" $_.Exception.Message}