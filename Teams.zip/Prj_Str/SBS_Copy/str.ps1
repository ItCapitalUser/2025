﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
 
#Variables for Processing
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/SBS_FD_310"

$LoginName ="spsitecoladm@smart-holding.com"
$LoginPassword ="uZ#RJpSS2%U9!PR"
 
 
#Get the Client Context
$Context = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
 
#supply Login Credentials
$SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
$Credential = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)
$Context.Credentials = $Credential

Function Create-DocumentLibrary()
{
    param
    (
        [Parameter(Mandatory=$true)] [string] $SiteURL,
        [Parameter(Mandatory=$true)] [string] $DocLibraryName,
        [Parameter(Mandatory=$true)] [string] $DocLibraryUrl

    )    
    Try {
    #Setup Credentials to connect
 
    #Set up the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL) 
    $Ctx.Credentials = $Credential
 
    #Get All Lists from the web
    $Lists = $Ctx.Web.Lists
    $Ctx.Load($Lists)
    $Ctx.ExecuteQuery()
  
    #Check if Library name doesn't exists already and create document library
    if(!($Lists.Title -contains $DocLibraryName))
    { 
        #create document library in sharepoint online powershell
        $ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
        $ListInfo.Title = $DocLibraryName
        $ListInfo.Url=$DocLibraryUrl
        $ListInfo.TemplateType = 101 #Document Library
        $List = $Ctx.Web.Lists.Add($ListInfo)
        $List.Update()
        $Ctx.ExecuteQuery()

        $List =  $Ctx.Web.Lists.GetByTitle($DocLibraryName);
        $List.OnQuickLaunch = 1;
        $List.Update()
        $Ctx.ExecuteQuery()
   
        write-host  -f Green "New Document Library has been created!"
    }
    else
    {
        Write-Host -f Yellow "List or Library '$DocLibraryName' already exist!"
    }
}
Catch {
    write-host -f Red "Error Creating Document Library!" $_.Exception.Message
}
}

Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Бюджетування" -DocLibraryUrl "Budgeting"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Калькуляції" -DocLibraryUrl "Costing"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Загальні документи" -DocLibraryUrl "GenralDoc"

$foldersSBS  = @("Центр адміністративних сервісів", "Центр сервісів з управління нерухомістю", "Центр сервісів з управління персоналом", "Центр юридичних сервісів", "Центр фінансових сервісів")
$foldersIT  = @("Проєктний офіс", "Відділ автоматизації обліку та управління підприємств", "Відділ впровадження та супроводження ІС", "Відділ інформаційної безпеки", "Відділ інфраструктури")


  ForEach($folder in $foldersSBS)
 {
  
   $Url = "Budgeting/СБС/"+$folder
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
 }

   ForEach($folder in $foldersSBS)
 {
  
   $Url = "Costing/СБС/"+$folder
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
 }

  ForEach($folder in $foldersIT)
 {
  
   $Url = "Budgeting/ІТ Капітал/"+$folder
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
 }

   ForEach($folder in $foldersIT)
 {
  
   $Url = "Costing/ІТ Капітал/"+$folder
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
 }