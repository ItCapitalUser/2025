﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
 
#Variables for Processing
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/sbs_hr"

class Company {
    [string]$Business
    [string]$BusinessShort
    [string]$LegalEntity
    [string]$LegalEntityShort
}

$companySH = @(

       [Company]@{Business='СМАРТ БІЗНЕС СЕРВІС';BusinessShort='СБС';LegalEntity='ТОВ "СМАРТ БІЗНЕС СЕРВІС"'; LegalEntityShort='СБС'}
       [Company]@{Business='СМАРТ БІЗНЕС СЕРВІС';BusinessShort='СБС';LegalEntity='ТОВ "ІТ КАПІТАЛ"'; LegalEntityShort='ІТ КАПІТАЛ'}
       [Company]@{Business='СМАРТ БІЗНЕС СЕРВІС';BusinessShort='СБС';LegalEntity='ТОВ "ПОДІЛ-2000"'; LegalEntityShort='ПОДІЛ'}

       [Company]@{Business='СМАРТ ХОЛДИНГ';BusinessShort='СХ';LegalEntity='ТОВ "СМАРТ-ХОЛДИНГ"'; LegalEntityShort='СХ'}
       [Company]@{Business='СМАРТ ХОЛДИНГ';BusinessShort='СХ';LegalEntity='ТОВ "ФІНЛАЙН ЛТД"'; LegalEntityShort='ФІНЛАЙН'}
       [Company]@{Business='СМАРТ ХОЛДИНГ';BusinessShort='СХ';LegalEntity='ТОВ "ПРОМ МИНЕРАЛС"'; LegalEntityShort='ПРОМ МІНЕРАЛС'}
       [Company]@{Business='СМАРТ ХОЛДИНГ';BusinessShort='СХ';LegalEntity='ТОВ "СМАРТ ЛІЗИНГ"'; LegalEntityShort='СМАРТ ЛІЗИНГ'}

       [Company]@{Business='Інвестиційний Фонд Смарт';BusinessShort='ІФС';LegalEntity='ТОВ "ІНВЕСТИЦІЙНИЙ ФОНД "СМАРТ"'; LegalEntityShort='ІФС'}

       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ТОВ "АРКОНА ГАЗ-ЕНЕРГІЯ"'; LegalEntityShort='АРКОНА'}
       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ПРЕДСТАВНИЦТВО"РЕГАЛ ПЕТРОЛЕУМ КОРПОРЕЙШН ЛІМІТЕД"'; LegalEntityShort='РП (ПР)'}
       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ТОВ "ПРОМ-ЕНЕРГО ПРОДУКТ"'; LegalEntityShort='ПЕП'}
       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ТОВ "СМАРТ ЕНЕРДЖІ"'; LegalEntityShort='СЕ'}
       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ТОВ "РЕГАЛ ПЕТРОЛЕУМ КОРПОРЕЙШН (ЮКРЕЙН) ЛІМІТЕД"'; LegalEntityShort='РП (ЮКРЕЙН)'}
       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ФОП Строй Наталія Пертівна'; LegalEntityShort='ФОП СТРОЙ Н.П.'}
       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ПрАТ "УКРГАЗВИДОБУТОК"'; LegalEntityShort='УГВ'}

       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "БС ПРОПЕРТІ"'; LegalEntityShort='БС ПРОПЕРТІ'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "ІСТ СОЛЮШН ГРУП"'; LegalEntityShort='ІСГ'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "КОЛУМБУС"'; LegalEntityShort='КОЛУМБУС'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "МАДЕРА ДЕВЕЛОПМЕНТ" "КОЛУМБУС"'; LegalEntityShort='МАДЕРА'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "ПАУЕР БУД ДЕВЕЛОПМЕНТ"'; LegalEntityShort='ПБД'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "КОМПАНІЯ ПОЛІТРЕЙД"'; LegalEntityShort='ПОЛІТРЕЙД'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "ПРОДХІМІНДУСТРІЯ"'; LegalEntityShort='ПХІ'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "СЕДВЕРС"'; LegalEntityShort='СЕДВЕРС'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "СМАРТ УРБАН СОЛЮШНС"'; LegalEntityShort='СУ'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "ТРОЇЦЬКИЙ ПЛАЗА"'; LegalEntityShort='ТРОЇЦЬКИЙ ПЛАЗА'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "УРБАН АКТІВІТІ"'; LegalEntityShort='УРБАН АКТІВІТІ'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "ЮДЖИН"'; LegalEntityShort='ЮДЖИН'}

       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "ВІДЖИ АГРО"'; LegalEntityShort='ВІДЖИ АГРО'}
       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "ВІДЖИ ПРОДАКШН"'; LegalEntityShort='ВІДЖИ ПРОДАКШН'}
       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "ВІДЖИ ТРЕЙД"'; LegalEntityShort='ВІДЖИ ТРЕЙД'}
       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "ВІДЖИ ФАРМІНГ"'; LegalEntityShort='ВІДЖИ ФАРМІНГ'}
       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "ІНВЕСТ-2018"'; LegalEntityShort='ІНВЕСТ-2018'}
       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "КОРСУНЬ ЛОГІСТІК"'; LegalEntityShort='КОРСУНЬ ЛОГІСТІК'}
       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "ПОНОМАР"'; LegalEntityShort='ПОНОМАР'}

       [Company]@{Business='Індустриальний парк Наваль';BusinessShort='ІПНАВАЛЬ';LegalEntity='ТОВ "НАВАЛЬ ЛОГІСТІК"'; LegalEntityShort='НАВАЛЬ ЛОГІСТІК'}
       [Company]@{Business='Індустриальний парк Наваль';BusinessShort='ІПНАВАЛЬ';LegalEntity='ТОВ "НАВАЛЬ ПАРК"'; LegalEntityShort='НАВАЛЬ ПАРК'}
       [Company]@{Business='Індустриальний парк Наваль';BusinessShort='ІПНАВАЛЬ';LegalEntity='ТОВ "ПОРТ ОЧАКІВ"'; LegalEntityShort='ПОРТ ОЧАКІВ'}
       [Company]@{Business='Індустриальний парк Наваль';BusinessShort='ІПНАВАЛЬ';LegalEntity='ТОВ "ОЧАКІВ ПАРК"'; LegalEntityShort='ОЧАКІВ ПАРК'}

       [Company]@{Business='Смарт Мерітайм Груп';BusinessShort='СМГ';LegalEntity='ТОВ "СМАРТ-МЕРІТАЙМ АКТИВ"'; LegalEntityShort='СМА'}
       [Company]@{Business='Смарт Мерітайм Груп';BusinessShort='СМГ';LegalEntity='ТОВ "СМАРТ-МЕРІТАЙМ ГРУП"'; LegalEntityShort='СМГ'}

       #[Company]@{Business='Marquette';BusinessShort='Marquette';LegalEntity='Marquette'; LegalEntityShort='Marquette'}
       #[Company]@{Business='Marquette';BusinessShort='Marquette';LegalEntity='Marquette'; LegalEntityShort='Marquette'}

   )

   $arrBusiness = $companySH | Select-Object -Unique -Property BusinessShort, Business

   ForEach ($iii In $io){
   Write-Host $iii.Business
   }

$business = @("СМАРТ БІЗНЕС СЕРВІС", "СМАРТ ХОЛДИНГ", "Інвестиційний Фонд Смарт", "Смарт Енерджі", "Смарт Урбан Солюшнз", "Верес", "Індустриальний парк Наваль", "Смарт Мерітайм Груп")
$businessShort = @("СБС", "СХ", "ІФС", "СЕ", "СУ", "Верес", "ІПНАВАЛЬ", "СМГ")
 $businessSBS = @("СБС", "ІТ КАПІТАЛ", "ПОДІЛ")
 $businessSH = @("СХ", "ФІНЛАЙН", "ПРОМ МІНЕРАЛС", "СМАРТ ЛІЗИНГ")
 $businessIFS = @("ІФС")
 $businessSE = @("АРКОНА", "РП (ПР)", "ПЕП", "СЕ", "РП (ЮКРЕЙН)", "ФОП СТРОЙ Н.П.", "УГВ")
 $businessSU = @("БС ПРОПЕРТІ", "ІСГ", "КОЛУМБУС", "МАДЕРА", "ПБД", "ПОЛІТРЕЙД", "ПХІ", "СЕДВЕРС", "СУ", "ТРОЇЦЬКИЙ ПЛАЗА", "УРБАН АКТІВІТІ", "ЮДЖИН")
 $businessVeres = @("ВІДЖИ АГРО", "ВІДЖИ ПРОДАКШН", "ВІДЖИ ТРЕЙД", "ВІДЖИ ФАРМІНГ", "ІНВЕСТ-2018", "КОРСУНЬ ЛОГІСТІК", "ПОНОМАР")
 $businessNaval = @("НАВАЛЬ ЛОГІСТІК", "НАВАЛЬ ПАРК", "ПОРТ ОЧАКІВ", "ОЧАКІВ ПАРК")
 $businessSMG = @("СМА",  "СМГ")


$LoginName ="spsitecoladm@smart-holding.com"
$LoginPassword ="uZ#RJpSS2%U9!PR"
 
 
#Get the Client Context
$Context = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
 
#supply Login Credentials
$SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
$Credential = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)
$Context.Credentials = $Credential
 
#powershell create document library sharepoint online

Function Create-DocumentLibrary()
{
    param
    (
        [Parameter(Mandatory=$true)] [string] $SiteURL,
        [Parameter(Mandatory=$true)] [string] $DocLibraryName,
        [Parameter(Mandatory=$true)] [string] $DocLibraryUrl

    )    
    Try {
    #Setup Credentials to connect
 
    #Set up the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL) 
    $Ctx.Credentials = $Credential
 
    #Get All Lists from the web
    $Lists = $Ctx.Web.Lists
    $Ctx.Load($Lists)
    $Ctx.ExecuteQuery()
  
    #Check if Library name doesn't exists already and create document library
    if(!($Lists.Title -contains $DocLibraryName))
    { 
        #create document library in sharepoint online powershell
        $ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
        $ListInfo.Title = $DocLibraryName
        $ListInfo.Url=$DocLibraryUrl
        $ListInfo.TemplateType = 101 #Document Library
        $List = $Ctx.Web.Lists.Add($ListInfo)
        $List.Update()
        $Ctx.ExecuteQuery()

        $List =  $Ctx.Web.Lists.GetByTitle($DocLibraryName);
        $List.OnQuickLaunch = 1;
        $List.Update()
        $Ctx.ExecuteQuery()
   
        write-host  -f Green "New Document Library has been created!"
    }
    else
    {
        Write-Host -f Yellow "List or Library '$DocLibraryName' already exist!"
    }
}
Catch {
    write-host -f Red "Error Creating Document Library!" $_.Exception.Message
}
}


Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Кадровий облік" -DocLibraryUrl "PersRecords"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Методологія" -DocLibraryUrl "Methodology"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Розрахунки з персоналом" -DocLibraryUrl "BudgetPresentation"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Бюджет на персонал" -DocLibraryUrl "BudgetStaff"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Аудит" -DocLibraryUrl "Audit"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Навчання та розвиток персоналу" -DocLibraryUrl "StudTrng"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Оцінка персоналу" -DocLibraryUrl "PersonAssessment"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Програми мотивації персоналу" -DocLibraryUrl "MotivatManagProg"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Договори центру" -DocLibraryUrl "Contracts"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Презентації" -DocLibraryUrl "Presentations"

Function Create-Folder()
{
    param(
        [Parameter(Mandatory=$true)][string]$SiteURL,
        [Parameter(Mandatory=$true)][string]$LibraryName,
        [Parameter(Mandatory=$true)][string]$FolderName
    )
 
    Try {
 
        #Setup the context
        $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
        $Ctx.Credentials = $Credential

 
        #Get the Library by Name
        $List = $Ctx.Web.Lists.GetByTitle($LibraryName)
 
        #Check Folder Exists already
        $Folders = $List.RootFolder.Folders
        $Ctx.Load($Folders)
        $Ctx.ExecuteQuery()

        $Folder=$Ctx.Web.Folders.Add("Methodology/Колективні договори/СМАРТ БІЗНЕС СЕРВІС")
        $Context.ExecuteQuery()
 
        #Get existing folder names
        $FolderNames = $Folders | Select -ExpandProperty Name
        if($FolderNames -contains $FolderName)
        {
            write-host "Folder Exists Already!" -ForegroundColor Yellow
        }
        else #powershell sharepoint online create folder if not exist
        {
            #sharepoint online create folder powershell
            $NewFolder = $List.RootFolder.Folders.Add($FolderName)
            $Ctx.ExecuteQuery()
            Write-host "Folder '$FolderName' Created Successfully!" -ForegroundColor Green
        }
    }
    Catch {
        write-host -f Red "Error Creating Folder!" $_.Exception.Message
    }
}
#region Кадровий облік
 $foldersPersDoc = @("Атестація робочих місць", "Довідки МСЕК", "Заяви на пільгу (ПСП)", "Дані про чорнобильців", "Табелі обліку робочого часу", "Лікарняні",
                    "Відрядження", "ЦПХ (договори)", "Графіки роб.часу", "Простої", "Донори", "Військовий облік", "Штатні розписи", "Журнали реєстрації", "Звіти", "Довідки",
                    "Відпустки", "Документи для оформлення на роботу","Прогули", "Накази кадрові тривалого зберігання", "Накази тимчасового зберігання","Накази по загальній діяльності",
                    "Скан. копії трудових книжок працівників")

$foldersOrdersLongTerm  = @("Прийом на роботу", "Переведення", "Звільнення", "Декретні відпустки", "Мобілізація і ТРО", "Відпустки без збереження",
                    "Припинення ТД", "Надурочні і вихідні дні", "Матдопомога (накази, заяви)")

 ForEach($fPersDoc in $foldersPersDoc)
 {
   Create-Folder -SiteURL $SiteURL  -LibraryName "Кадровий облік" -FolderName $fPersDoc
   Write-Host "Create folder " $fPersDoc
 }

  ForEach($folder in $foldersOrdersLongTerm)
 {
  
   $Url = "PersRecords/Накази кадрові тривалого зберігання/"+$folder
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
 }

  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Атестація робочих місць/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

   ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Довідки МСЕК/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Відпустки/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Відрядження/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Військовий облік/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Графіки роб.часу/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Дані про чорнобильців/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Довідки/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }


  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Документи для оформлення на роботу/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }


  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Донори/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }


  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Журнали реєстрації/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

   ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Заяви на пільгу (ПСП)/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

   ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Звіти/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

   ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Лікарняні/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

   ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Накази кадрові тривалого зберігання/Прийом на роботу/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

   ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Накази кадрові тривалого зберігання/Відпустки без збереження/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

    ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Накази кадрові тривалого зберігання/Декретні відпустки/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

    ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Накази кадрові тривалого зберігання/Звільнення/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

 
    ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Накази кадрові тривалого зберігання/Матдопомога (накази, заяви)/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }


    ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Накази кадрові тривалого зберігання/Мобілізація і ТРО/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }



    ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Накази кадрові тривалого зберігання/Надурочні і вихідні дні/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }



    ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Накази кадрові тривалого зберігання/Переведення/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }
 

    ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Накази кадрові тривалого зберігання/Припинення ТД/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

 $Url = "PersRecords/Накази тимчасового зберігання/Відпустки оплачувані"
 $Url
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

     ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Накази тимчасового зберігання/Відпустки оплачувані/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }
 
 ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Накази по загальній діяльності/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
  }
  
  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Прогули/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }


 ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Простої/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Скан. копії трудових книжок працівників/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }
 
  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Табелі обліку робочого часу/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }  

   ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/ЦПХ (договори)/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 } 

   ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "PersRecords/Штатні розписи/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 } 

#endregion Кадровий облік

#region Розрахунки з персоналом

$foldersBudgetPres = @("Графіки виплати ЗП", "Накази для нарахування (тривалого терміну)", "Акти ЦПХ", "Утримання із ЗП", "Виконавча служба", "Фінансування лікарняних (заявки+ повідомлення)",
                    "Інвентаризація резервів (річна)", "Звітність по відпусткам ЧАЕС", "Довідки з ДПІ для банків - ЄСВ", "Листування з держорганами", "Установчі документи ")

                    
 ForEach($fPersDoc in $foldersBudgetPres)
 {
   Create-Folder -SiteURL $SiteURL  -LibraryName "Розрахунки з персоналом" -FolderName $fPersDoc
   Write-Host "Create folder " $fPersDoc
 }

  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Акти ЦПХ/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

   ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Виконавча служба/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
  
 }

    ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Графіки виплати ЗП/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()  
 }

     ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Довідки з ДПІ для банків - ЄСВ/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
 
 }


     ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Звітність по відпусткам ЧАЕС/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
 
 }

      ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Інвентаризація резервів (річна)/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
  
 }

      ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Листування з держорганами/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
  
 }

      ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Установчі документи/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
 }

 
      ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Накази для нарахування (тривалого терміну)/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

 
      ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Утримання із ЗП/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }

 
      ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Фінансування лікарняних (заявки+ повідомлення)/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   
 }

#endregion Розрахунки з персоналом

#region Методологія
#Folder in the document library 
Create-Folder -SiteURL $SiteURL  -LibraryName "Методологія" -FolderName "Колективні договори"
Create-Folder -SiteURL $SiteURL  -LibraryName "Методологія" -FolderName "Регламентуючі документи"
Create-Folder -SiteURL $SiteURL  -LibraryName "Методологія" -FolderName "Бізнес-процеси"
Create-Folder -SiteURL $SiteURL  -LibraryName "Методологія" -FolderName "Налаштування систем обліку"

Create-Folder -SiteURL $SiteURL  -LibraryName "Методологія" -FolderName "Бланки та шаблони документів"
Create-Folder -SiteURL $SiteURL  -LibraryName "Методологія" -FolderName "Консультації"
Create-Folder -SiteURL $SiteURL  -LibraryName "Методологія" -FolderName "Результати перевірок"

   $Url = "Methodology/Бланки та шаблони документів/Формати дня внутрішнього використання"
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
   $Context.ExecuteQuery()

   $Url = "Methodology/Бланки та шаблони документів/Типові бланки для співробітників"
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
   $Context.ExecuteQuery()

        
 ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "Methodology/Результати перевірок/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
  
 }

  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "Methodology/Бізнес-процеси/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
  
 }

   ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "Methodology/Колективні договори/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
  
 }

    ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "Methodology/Налаштування систем обліку/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
  
 }

#endregion Методологія

#region Договори центру
  ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "Contracts/"+$item.Business
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()

   $arrCompanyBusiness = $companySH | Where-Object Business -EQ $item.Business 

    ForEach ($itemY In $arrCompanyBusiness)
    {
        Write-Host $itemY.LegalEntityShort -f Green
        $UrlSubFolder=$Url+"/"+$itemY.LegalEntityShort
        $Folder=$Context.Web.Folders.Add($UrlSubFolder)
        $Context.ExecuteQuery()
    }  
 }
#endregion Договори центру"

ForEach ($item In $business)
 {Write-Host $item

 $Url = "Methodology/Колективні договори/"+$item
 $Url
   
        $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
 }

 ForEach ($item In $business)
 {Write-Host $item

 $Url = "Methodology/Бізнес-процеси/"+$item
 $Url
   
        $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
 }

  ForEach ($item In $business)
 {Write-Host $item

 $Url = "Methodology/Налаштування систем обліку/"+$item
 $Url
   
        $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
 }

   ForEach ($item In $business)
 {Write-Host $item

 $Url = "Methodology/Результати перевірок/"+$item
 $Url
   
        $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()
 }




