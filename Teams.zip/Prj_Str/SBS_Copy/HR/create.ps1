﻿Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
   
#Set Variables for Site URL
$SiteURL= "https://smartholdingcom.sharepoint.com/sites/sbs_hr"
$ListName = "Кадровий облік"
$CSVPath = "C:\Temp\testK270423.csv"


 
#Setup Credentials to connect
$Cred = Get-Credential
$Cred = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.UserName,$Cred.Password)

$LoginName ="spsitecoladm@smart-holding.com"
$LoginPassword ="uZ#RJpSS2%U9!PR"

$SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
$Cred = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)

class GroupPerm {
    [string]$Name
    [string]$Type
    [string]$PermLevel
   
}

class FolderPerm {
    [string]$UrlFolder
    [GroupPerm []]$PermMatr
   
}
 
Try {
    #Setup the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = $Cred

 
    #Get all Groups
    $Groups=$Ctx.Web.SiteGroups
    $Ctx.Load($Groups)
    $Ctx.ExecuteQuery()
    $allGroups = @()

     #Get Each member from the Group
    Foreach($Group in $Groups)
    {
        Write-Host "--- $($Group.Title) --- " 
            $nItemGrp =  [GroupPerm]@{
                    Name=$Group.Title
                    Type="Group"
                    PermLevel=""}
                    $nItemGrp 

                    $allGroups+= $nItemGrp
                   
    }
    
    
    #Get the Document Library
    $List =$Ctx.Web.Lists.GetByTitle($ListName)
      
    #Define CAML Query to Get List Items in batches
    $Query = New-Object Microsoft.SharePoint.Client.CamlQuery
    $Query.ViewXml ="
    <View Scope='RecursiveAll'>
        <Query>
            <OrderBy><FieldRef Name='ID' Ascending='TRUE'/></OrderBy>
        </Query>
        <RowLimit Paged='TRUE'>$BatchSize</RowLimit>
    </View>"
 
    $DataCollection = @()
    Do
    {
        #get List items
        $ListItems = $List.GetItems($Query) 
        $Ctx.Load($ListItems)
        $Ctx.ExecuteQuery() 
 
        #Iterate through each item in the document library
        ForEach($ListItem in $ListItems)
        {
            #Collect data        
            $Data = New-Object PSObject -Property ([Ordered] @{
                Name  = $ListItem.FieldValues.FileLeafRef
                RelativeURL = $ListItem.FieldValues.FileRef
                Len=$ListItem.FieldValues.FileRef.Length
                Type =  $ListItem.FileSystemObjectType
                CreatedBy =  $ListItem.FieldValues.Author.Email
                CreatedOn = $ListItem.FieldValues.Created
                ModifiedBy =  $ListItem.FieldValues.Editor.Email
                ModifiedOn = $ListItem.FieldValues.Modified
                FileSize = $ListItem.FieldValues.File_x0020_Size
            })
            $DataCollection += $Data
        }
        $Query.ListItemCollectionPosition = $ListItems.ListItemCollectionPosition
    }While($Query.ListItemCollectionPosition -ne $null)

   $DataSort = $DataCollection   |  Sort-Object RelativeURL -Descending # | Where-Object { $_.RelativeURL -like '*7.2 АНАЛІТИКА ВИТОРГ ТДА (2014)/*' }  
   $DataSort | Export-Csv -Path $CSVPath -Force -NoTypeInformation -Encoding UTF8
     $allPerm = @()
   foreach($itemA in $DataSort)
   {
        if($itemA.Type -eq "Folder")
        {
            $ItemPerm =  [FolderPerm]@{
                    UrlFolder=$itemA.RelativeURL
                    }
             $allPerm+=$ItemPerm
        }
    }

}
Catch {
    write-host -f Red "Error getting groups and users!" $_.Exception.Message
}

$allPerm[0].PermMatr[4].PermLevel


ConvertTo-Json -InputObject $allPerm -Depth 3 | Out-File -FilePath C:\Temp\kadru.json

$allPermissionLib=[FolderPerm []] (Get-Content 'C:\Temp\kadru.json' | Out-String | ConvertFrom-Json)

$op[0].PermMatr[1].Name

Foreach($itemJson in $allPermissionLib)
{
  $itemJson.UrlFolder
  
  Foreach($groupJson in $itemJson.PermMatr)
  {
      Write-Host $groupJson.Name -ForegroundColor Cyan
  }
}

Foreach($itemJson in $allPermissionLib)
{
  $itemJson.UrlFolder
  
  Foreach($groupJson in $itemJson.PermMatr)
  {
      Write-Host $groupJson.Name -ForegroundColor Cyan
  }
}