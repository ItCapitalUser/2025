﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
 
#Variables for Processing
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/testEmptySite"

class Company {
    [string]$Business
    [string]$BusinessShort
    [string]$LegalEntity
    [string]$LegalEntityShort
}

class Folder {
    [string]$Name
    [string]$Ordering
    [string]$Category
    [string]$TypeDoc
    [string]$ArrSubFolders
}

$foldersStaff = @(

       [Folder]@{Name='Атестація робочих місць';Ordering='6';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Відпустки';Ordering='5';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders='foldersStaffHolidays'}
       [Folder]@{Name='Відрядження';Ordering='4';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Військовий облік';Ordering='1';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Графіки роб.часу';Ordering='6';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Довідки';Ordering='5';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Довідки МСЕК';Ordering='5';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Документи для оформлення на роботу';Ordering='1';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Донори';Ordering='3';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders='foldersStaffDonors'}
       [Folder]@{Name='Журнали реєстрації';Ordering='1';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Заяви на пільгу (ПСП)';Ordering='6';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Звіти';Ordering='6';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Лікарняні';Ordering='2';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Накази кадрові тривалого зберігання';Ordering='1';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders='foldersStaffOrdersLongTerm'}
       [Folder]@{Name='Накази по загальній діяльності';Ordering='5';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Прогули';Ordering='6';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Простої';Ordering='4';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Скан. копії трудових книжок працівників + особова справа';Ordering='4';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Скорочення';Ordering='6';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Табелі обліку робочого часу';Ordering='1';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='ЦПХ';Ordering='4';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders='foldersStaffCLN'}
       [Folder]@{Name='Чорнобильці';Ordering='1';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Штатні розписи';Ordering='6';Category='Кадровий облік'; TypeDoc=''; ArrSubFolders='foldersStaffChernobyl'}

       [Folder]@{Name='Виконавча служба';Ordering='1';Category='Розрахунки з персоналом'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Графіки виплати ЗП';Ordering='1';Category='Розрахунки з персоналом'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Довідки з ДПІ для банків - ЄСВ';Ordering='1';Category='Розрахунки з персоналом'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Інвентаризація резервів (річна)';Ordering='1';Category='Розрахунки з персоналом'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Інформація по компаніям';Ordering='1';Category='Розрахунки з персоналом'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Листування з держорганами';Ordering='1';Category='Розрахунки з персоналом'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Накази для нарахування (тривалого терміну)';Ordering='1';Category='Розрахунки з персоналом'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Утримання із ЗП';Ordering='1';Category='Розрахунки з персоналом'; TypeDoc=''; ArrSubFolders=''}
       [Folder]@{Name='Фінансування лікарняних (заявки+ повідомлення)';Ordering='1';Category='Розрахунки з персоналом'; TypeDoc=''; ArrSubFolders=''}

       #[Folder]@{Name='';Ordering='';Category=''; TypeDoc=''; ArrSubFolders=''}
   )

   $foldersStaffOrdersLongTerm  = @(

       [Folder]@{Name='Звільнення';Ordering='1';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Зміна посадового окладу';Ordering='1';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Матдопомога (накази, заяви)';Ordering='1';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Мобілізація і ТРО';Ordering='1';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Надурочні і вихідні дні';Ordering='1';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Переведення';Ordering='1';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Прийом на роботу';Ordering='1';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Припинення ТД';Ordering='1';Category='Кадровий облік'; TypeDoc=''}

   )

     $foldersStaffHolidays  = @(

       [Folder]@{Name='Відпустки без збереження';Ordering='2';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Відпустки декретні, вагітність і пологи';Ordering='3';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Відпустки оплачувані + особливі, шквідливі';Ordering='1';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Відпустки по ЧАЕС';Ordering='4';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Графік відпусток';Ordering='9';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Інвентеризація резерву відпусток';Ordering='9';Category='Кадровий облік'; TypeDoc=''}
   )

 $foldersStaffDonors  = @(

       [Folder]@{Name='Довідки';Ordering='1';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Накази';Ordering='1';Category='Кадровий облік'; TypeDoc=''}     
   )

    $foldersStaffCLN  = @(

       [Folder]@{Name='Акти';Ordering='1';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Договори';Ordering='1';Category='Кадровий облік'; TypeDoc=''}     
   )

       $foldersStaffChernobyl = @(

       [Folder]@{Name='Дані';Ordering='1';Category='Кадровий облік'; TypeDoc=''}
       [Folder]@{Name='Звітність по відпусткам ЧАЕС';Ordering='1';Category='Кадровий облік'; TypeDoc=''}     
   )

$companySH = @(
 
       [Company]@{Business='Тест група long';BusinessShort='Тест група';LegalEntity='Компанія 1 ТОВ'; LegalEntityShort='Компанія 1'; LegalEntityEng='Comp1' }
       [Company]@{Business='Тест група long';BusinessShort='Тест група';LegalEntity='Компанія 2 ТОВ'; LegalEntityShort='Компанія 2'; LegalEntityEng='Comp2'}
       [Company]@{Business='Тест група long';BusinessShort='Тест група';LegalEntity='Компанія 3 ТОВ'; LegalEntityShort='Компанія 3'; LegalEntityEng='Comp3'}

       <#[Company]@{Business='СМАРТ БІЗНЕС СЕРВІС';BusinessShort='СБС';LegalEntity='ТОВ "СМАРТ БІЗНЕС СЕРВІС"'; LegalEntityShort='СБС'}
       [Company]@{Business='СМАРТ БІЗНЕС СЕРВІС';BusinessShort='СБС';LegalEntity='ТОВ "ІТ КАПІТАЛ"'; LegalEntityShort='ІТ КАПІТАЛ'}
       [Company]@{Business='СМАРТ БІЗНЕС СЕРВІС';BusinessShort='СБС';LegalEntity='ТОВ "ПОДІЛ-2000"'; LegalEntityShort='ПОДІЛ'}

       [Company]@{Business='СМАРТ ХОЛДИНГ';BusinessShort='СХ';LegalEntity='ТОВ "СМАРТ-ХОЛДИНГ"'; LegalEntityShort='СХ'}
       [Company]@{Business='СМАРТ ХОЛДИНГ';BusinessShort='СХ';LegalEntity='ТОВ "ФІНЛАЙН ЛТД"'; LegalEntityShort='ФІНЛАЙН'}
       [Company]@{Business='СМАРТ ХОЛДИНГ';BusinessShort='СХ';LegalEntity='ТОВ "ПРОМ МИНЕРАЛС"'; LegalEntityShort='ПРОМ МІНЕРАЛС'}
       [Company]@{Business='СМАРТ ХОЛДИНГ';BusinessShort='СХ';LegalEntity='ТОВ "СМАРТ ЛІЗИНГ"'; LegalEntityShort='СМАРТ ЛІЗИНГ'}

       [Company]@{Business='Інвестиційний Фонд Смарт';BusinessShort='ІФС';LegalEntity='ТОВ "ІНВЕСТИЦІЙНИЙ ФОНД "СМАРТ"'; LegalEntityShort='ІФС'}

       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ТОВ "АРКОНА ГАЗ-ЕНЕРГІЯ"'; LegalEntityShort='АРКОНА'}
       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ПРЕДСТАВНИЦТВО"РЕГАЛ ПЕТРОЛЕУМ КОРПОРЕЙШН ЛІМІТЕД"'; LegalEntityShort='РП (ПР)'}
       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ТОВ "ПРОМ-ЕНЕРГО ПРОДУКТ"'; LegalEntityShort='ПЕП'}
       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ТОВ "СМАРТ ЕНЕРДЖІ"'; LegalEntityShort='СЕ'}
       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ТОВ "РЕГАЛ ПЕТРОЛЕУМ КОРПОРЕЙШН (ЮКРЕЙН) ЛІМІТЕД"'; LegalEntityShort='РП (ЮКРЕЙН)'}
       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ФОП Строй Наталія Пертівна'; LegalEntityShort='ФОП СТРОЙ Н.П.'}
       [Company]@{Business='Смарт Енерджі';BusinessShort='СЕ';LegalEntity='ПрАТ "УКРГАЗВИДОБУТОК"'; LegalEntityShort='УГВ'}

       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "БС ПРОПЕРТІ"'; LegalEntityShort='БС ПРОПЕРТІ'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "ІСТ СОЛЮШН ГРУП"'; LegalEntityShort='ІСГ'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "КОЛУМБУС"'; LegalEntityShort='КОЛУМБУС'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "МАДЕРА ДЕВЕЛОПМЕНТ" "КОЛУМБУС"'; LegalEntityShort='МАДЕРА'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "ПАУЕР БУД ДЕВЕЛОПМЕНТ"'; LegalEntityShort='ПБД'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "КОМПАНІЯ ПОЛІТРЕЙД"'; LegalEntityShort='ПОЛІТРЕЙД'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "ПРОДХІМІНДУСТРІЯ"'; LegalEntityShort='ПХІ'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "СЕДВЕРС"'; LegalEntityShort='СЕДВЕРС'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "СМАРТ УРБАН СОЛЮШНС"'; LegalEntityShort='СУ'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "ТРОЇЦЬКИЙ ПЛАЗА"'; LegalEntityShort='ТРОЇЦЬКИЙ ПЛАЗА'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "УРБАН АКТІВІТІ"'; LegalEntityShort='УРБАН АКТІВІТІ'}
       [Company]@{Business='Смарт Урбан Солюшнз';BusinessShort='СУ';LegalEntity='ТОВ "ЮДЖИН"'; LegalEntityShort='ЮДЖИН'}

       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "ВІДЖИ АГРО"'; LegalEntityShort='ВІДЖИ АГРО'}
       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "ВІДЖИ ПРОДАКШН"'; LegalEntityShort='ВІДЖИ ПРОДАКШН'}
       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "ВІДЖИ ТРЕЙД"'; LegalEntityShort='ВІДЖИ ТРЕЙД'}
       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "ВІДЖИ ФАРМІНГ"'; LegalEntityShort='ВІДЖИ ФАРМІНГ'}
       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "ІНВЕСТ-2018"'; LegalEntityShort='ІНВЕСТ-2018'}
       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "КОРСУНЬ ЛОГІСТІК"'; LegalEntityShort='КОРСУНЬ ЛОГІСТІК'}
       [Company]@{Business='Верес';BusinessShort='ВЕРЕС';LegalEntity='ТОВ "ПОНОМАР"'; LegalEntityShort='ПОНОМАР'}

       [Company]@{Business='Індустриальний парк Наваль';BusinessShort='ІПНАВАЛЬ';LegalEntity='ТОВ "НАВАЛЬ ЛОГІСТІК"'; LegalEntityShort='НАВАЛЬ ЛОГІСТІК'}
       [Company]@{Business='Індустриальний парк Наваль';BusinessShort='ІПНАВАЛЬ';LegalEntity='ТОВ "НАВАЛЬ ПАРК"'; LegalEntityShort='НАВАЛЬ ПАРК'}
       [Company]@{Business='Індустриальний парк Наваль';BusinessShort='ІПНАВАЛЬ';LegalEntity='ТОВ "ПОРТ ОЧАКІВ"'; LegalEntityShort='ПОРТ ОЧАКІВ'}
       [Company]@{Business='Індустриальний парк Наваль';BusinessShort='ІПНАВАЛЬ';LegalEntity='ТОВ "ОЧАКІВ ПАРК"'; LegalEntityShort='ОЧАКІВ ПАРК'}

       [Company]@{Business='Смарт Мерітайм Груп';BusinessShort='СМГ';LegalEntity='ТОВ "СМАРТ-МЕРІТАЙМ АКТИВ"'; LegalEntityShort='СМА'}
       [Company]@{Business='Смарт Мерітайм Груп';BusinessShort='СМГ';LegalEntity='ТОВ "СМАРТ-МЕРІТАЙМ ГРУП"'; LegalEntityShort='СМГ'}#>

       #[Company]@{Business='Marquette';BusinessShort='Marquette';LegalEntity='Marquette'; LegalEntityShort='Marquette'}
       #[Company]@{Business='Marquette';BusinessShort='Marquette';LegalEntity='Marquette'; LegalEntityShort='Marquette'}

   )

   $arrBusiness = $companySH | Where-Object -Property BusinessShort -EQ "СБС" #| Select-Object -Unique -Property BusinessShort, Business 

   
$LoginName ="spsitecoladm@smart-holding.com"
$LoginPassword ="uZ#RJpSS2%U9!PR"
 
 
#Get the Client Context
$Context = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
 
#supply Login Credentials
$SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
$Credential = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)
$Context.Credentials = $Credential

Function Create-DocumentLibrary()
{
    param
    (
        [Parameter(Mandatory=$true)] [string] $SiteURL,
        [Parameter(Mandatory=$true)] [string] $DocLibraryName,
        [Parameter(Mandatory=$true)] [string] $DocLibraryUrl

    )    
    Try {
    #Setup Credentials to connect
 
    #Set up the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL) 
    $Ctx.Credentials = $Credential
 
    #Get All Lists from the web
    $Lists = $Ctx.Web.Lists
    $Ctx.Load($Lists)
    $Ctx.ExecuteQuery()
  
    #Check if Library name doesn't exists already and create document library
    if(!($Lists.Title -contains $DocLibraryName))
    { 
        #create document library in sharepoint online powershell
        $ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
        $ListInfo.Title = $DocLibraryName
        $ListInfo.Url=$DocLibraryUrl
        $ListInfo.TemplateType = 101 #Document Library
        $List = $Ctx.Web.Lists.Add($ListInfo)
        $List.Update()
        $Ctx.ExecuteQuery()

        $List =  $Ctx.Web.Lists.GetByTitle($DocLibraryName);
        $List.OnQuickLaunch = 1;
        $List.Update()
        $Ctx.ExecuteQuery()
    
        write-host  -f Green "New Document Library  $DocLibraryName  has been created!"
    }
    else
    {
        Write-Host -f Yellow "List or Library '$DocLibraryName' already exist!"
    }
}
Catch {
    write-host -f Red "Error Creating Document Library!" $_.Exception.Message
}
}


Function Create-FolderByUrl()
{
   param(
        [Parameter(Mandatory=$true)][string]$SiteURL,
        [Parameter(Mandatory=$true)][string]$NameDocLib,
        [Parameter(Mandatory=$true)][string]$UrlFolder
    )
     Try {
        #Setup the context
        $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
        $Ctx.Credentials = $Credential

         $Url=$NameDocLib+"/"+$UrlFolder
         #$Url
         $Folder=$Context.Web.Folders.Add($Url)
         $Context.ExecuteQuery()
         write-host -f Green "Create Folder"  $Url
     }
     Catch{
        write-host -f Red "Error Creating FolderByUrl!" $_.Exception.Message
     }
}

Function Create-FolderByUrlForPersonalFolder()
{
   param(
        [Parameter(Mandatory=$true)][string]$SiteURL,
        [Parameter(Mandatory=$true)][string]$NameDocLib,
        [Parameter(Mandatory=$true)][string]$UrlFolder,
        [Parameter(Mandatory=$true)][string]$CategoryFolder,
        [Parameter(Mandatory=$true)][string]$OrderFolder
    )
     Try {
        #Setup the context
        $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
        $Ctx.Credentials = $Credential

         $Url=$NameDocLib+"/"+$UrlFolder
         #$Url
         $Folder=$Context.Web.Folders.Add($Url)
         $Context.ExecuteQuery()
         write-host -f Green "Create Folder"  $Url

         $item = $Folder.ListItemAllFields;
         $Context.Load($item);
         $Context.ExecuteQuery();

         if(![string]::IsNullOrEmpty($CategoryFolder))
         {
              $item["Category"]=$CategoryFolder
              $item.Update()
              $Folder.Context.ExecuteQuery()
         }

         if(![string]::IsNullOrEmpty($OrderFolder))
         {
              $item["Ordering"]=$OrderFolder
              $item.Update()
              $Folder.Context.ExecuteQuery()
         }
     }
     Catch{
        write-host -f Red "Error Creating FolderByUrlForPersonalFolder!" $_.Exception.Message
     }
}

Function Add-NumberColumnToList()
{ 
    param
    (
        [Parameter(Mandatory=$true)] [string] $SiteURL,
        [Parameter(Mandatory=$true)] [string] $ListName,
        [Parameter(Mandatory=$true)] [string] $Name,
        [Parameter(Mandatory=$true)] [string] $DisplayName,
        [Parameter(Mandatory=$false)] [string] $Description=[string]::Empty,
        [Parameter(Mandatory=$false)] [string] $IsRequired = "FALSE",
        [Parameter(Mandatory=$false)] [string] $EnforceUniqueValues = "FALSE"
    )
 
    #Generate new GUID for Field ID
    $FieldID = New-Guid
 
    Try {
       
        #Setup the context
        $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
        $Ctx.Credentials = $Credentials
         
        #Get the List
        $List = $Ctx.Web.Lists.GetByTitle($ListName)
        $Ctx.Load($List)
        $Ctx.ExecuteQuery()
 
        #Check if the column exists in list already
        $Fields = $List.Fields
        $Ctx.Load($Fields)
        $Ctx.executeQuery()
        $NewField = $Fields | where { ($_.Internalname -eq $Name) -or ($_.Title -eq $DisplayName) }
        if($NewField -ne $NULL)  
        {
            Write-host "Column $Name already exists in the List!" -f Yellow
        }
        else
        {
            $FieldSchema = "<Field Type='Number' ID='{$FieldID}' DisplayName='$DisplayName' Name='$Name' Description='$Description' Required='$IsRequired' EnforceUniqueValues='$EnforceUniqueValues' />"
            $NewField = $List.Fields.AddFieldAsXml($FieldSchema,$True,[Microsoft.SharePoint.Client.AddFieldOptions]::AddFieldInternalNameHint)
            $Ctx.ExecuteQuery()    
 
            Write-host "New Column Added to the List Successfully!" -ForegroundColor Green  
        }
    }
    Catch {
        write-host -f Red "Error Adding Column to List!" $_.Exception.Message
    }
} 

Function Add-SingleLineTextColumnToList()
{ 
    param
    (
        [Parameter(Mandatory=$true)] [string] $SiteURL,
        [Parameter(Mandatory=$true)] [string] $ListName,
        [Parameter(Mandatory=$true)] [string] $Name,
        [Parameter(Mandatory=$true)] [string] $DisplayName,
        [Parameter(Mandatory=$true)] [string] $Description,
        [Parameter(Mandatory=$true)] [string] $IsRequired,        
        [Parameter(Mandatory=$true)] [string] $EnforceUniqueValues,
        [Parameter(Mandatory=$true)] [string] $MaxLength
    )
 
    #Generate new GUID for Field ID
    $FieldID = New-Guid
 
    Try {
        
        #Setup the context
        $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
        $Ctx.Credentials = $Credentials
         
         $ListName = "Група СБС"
        #Get the List
        $List = $Ctx.Web.Lists.GetByTitle($ListName)
        $Ctx.Load($List)
        $Ctx.ExecuteQuery()
 
        #Check if the column exists in list already
        $Fields = $List.Fields
        $Ctx.Load($Fields)
        $Ctx.executeQuery()
        $NewField = $Fields | where { ($_.Internalname -eq $Name) -or ($_.Title -eq $DisplayName) }
        if($NewField -ne $NULL)  
        {
            Write-host "Column $Name already exists in the List!" -f Yellow
        }
        else
        {
            #Define XML for Field Schema
            $FieldSchema = "<Field Type='Text' ID='{$FieldID}' Name='$Name' StaticName='$Name' DisplayName='$DisplayName' Description='$Description' Required='$IsRequired' EnforceUniqueValues='$EnforceUniqueValues' MaxLength='$MaxLength' />"
            $NewField = $List.Fields.AddFieldAsXml($FieldSchema,$True,[Microsoft.SharePoint.Client.AddFieldOptions]::AddFieldInternalNameHint)
            $Ctx.ExecuteQuery()    
 
            Write-host "New Column Added to the List Successfully!" -ForegroundColor Green  
        }
    }
    Catch {
        write-host -f Red "Error Adding Column to List!" $_.Exception.Message
    }
} 

$foldersPersDoc = @("Атестація робочих місць", "Довідки МСЕК", "Заяви на пільгу (ПСП)", "Дані про чорнобильців", "Табелі обліку робочого часу", "Лікарняні",
                    "Відрядження", "ЦПХ (договори)", "Графіки роб.часу", "Простої", "Донори", "Військовий облік", "Штатні розписи", "Журнали реєстрації", "Звіти", "Довідки",
                    "Відпустки", "Документи для оформлення на роботу","Прогули", "Накази кадрові тривалого зберігання", "Накази тимчасового зберігання","Накази по загальній діяльності",
                    "Скан. копії трудових книжок працівників")

$foldersOrdersLongTerm  = @("Прийом на роботу", "Переведення", "Звільнення", "Декретні відпустки", "Мобілізація і ТРО", "Відпустки без збереження",
                    "Припинення ТД", "Надурочні і вихідні дні", "Матдопомога (накази, заяви)")

$foldersOrdersShortTerm  = @("Відпустки оплачувані")

$foldersBudgetPresentation = @("Графіки виплати ЗП", "Накази для нарахування (тривалого терміну)", "Акти ЦПХ", "Утримання із ЗП", "Виконавча служба",
                  "Фінансування лікарняних (заявки+ повідомлення)", "Інвентаризація резервів (річна)", "Звітність по відпусткам ЧАЕС", "Довідки з ДПІ для банків - ЄСВ",
                   "Листування з держорганами", "Установчі документи" )

$nameLibrary = "GrSBS"
$nameLibraryUkr = "Група СБС"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Група СБС" -DocLibraryUrl "GrSBS"

$Name="Category"
$DisplayName="Категорія"
$Description="Test"
$IsRequired = "FALSE"
$IsRequired = "FALSE"
$EnforceUniqueValues="FALSE" #Must set Indexed="FALSE", if Unique="TRUE"
$MaxLength="200"

 
#Call the function to add column to list
#Add-SingleLineTextColumnToList -SiteURL $SiteURL -ListName $nameLibraryUkr -Name $Name -DisplayName $DisplayName -Description $Description 
Add-SingleLineTextColumnToList -SiteURL $SiteURL -ListName $nameLibrary  -Name $Name -DisplayName $DisplayName -Description $Description -IsRequired $IsRequired -MaxLength $MaxLength -EnforceUniqueValues $EnforceUniqueValues

$Name="Ordering"
$DisplayName="Порядок сортування"
$Description=""
 
#Call the function to add column to list
Add-NumberColumnToList -SiteURL $SiteURL -ListName $nameLibraryUkr -Name $Name -DisplayName $DisplayName -Description $Description

$ServerRelativeUrl= "/sites/sbs_hr/GNaval/Test"

 $Url = $nameLibrary +"/HR процеси"
      $Url
      $Folder=$Context.Web.Folders.Add($Url)
      $Context.ExecuteQuery()


      $Folder.ListItemAllFields.Id
      $item = $Folder.ListItemAllFields;
      $Context.Load($item);
      $Context.ExecuteQuery();

      $item["Category"]

      $item["Category"]="yyy"
      $item.Update()
      $Folder.Context.ExecuteQuery()#>

ForEach($business in $arrBusiness)
 {

   <# $urlBusiness=$nameLibrary+"/"+$business.LegalEntityShort
    $urlBusiness
    $Folder=$Context.Web.Folders.Add($urlBusiness)
    $Context.ExecuteQuery()#>

    Create-FolderByUrl -SiteURL  $SiteURL -NameDocLib  $nameLibrary -UrlFolder $business.LegalEntityShort
    Write-Host $business.LegalEntityShort -ForegroundColor Cyan

    $urlBusiness= $nameLibrary+"/"+$business.LegalEntityShort
    ForEach($fPersDoc in $foldersStaff)
    {
       
      Create-FolderByUrlForPersonalFolder -SiteURL  $SiteURL -NameDocLib  $urlBusiness -UrlFolder $fPersDoc.Name -CategoryFolder $fPersDoc.Category -OrderFolder $fPersDoc.Ordering

       Write-Host $fPersDoc.Name "+" $fPersDoc.ArrSubFolders -ForegroundColor White
       $urlBusinessFolder = $urlBusiness+ "/"+$fPersDoc.Name
       if(![string]::IsNullOrEmpty($fPersDoc.ArrSubFolders))
       {
           $arr= Get-Variable $fPersDoc.ArrSubFolders
           #$arr.Value
           ForEach($fSubFolder in $arr.Value)
           {
               Write-Host $fSubFolder.Name "+" $fSubFolder.ArrSubFolders -ForegroundColor Yellow
               Create-FolderByUrlForPersonalFolder -SiteURL  $SiteURL -NameDocLib  $urlBusiness -UrlFolder $fSubFolder.Name -CategoryFolder $fSubFolder.Category -OrderFolder $fSubFolder.Ordering           }
       }
    }
 }


 ForEach($business in $arrBusiness)
 {
  
    $urlBus=$nameLibrary+"/"+$business.LegalEntityShort
    $Url = $urlBus
    $Url
    $Folder=$Context.Web.Folders.Add($Url)

    $Context.ExecuteQuery()

    ForEach($fPersDoc in $foldersPersDoc)
    {
      $Url = $urlBus +"/"+$fPersDoc
      $Url
      $Folder=$Context.Web.Folders.Add($Url)
      $Context.ExecuteQuery()
      Write-Host "Create folder " $fPersDoc
    }

     ForEach($folder in $foldersOrdersLongTerm)
     {
  
       $Url = $urlBus+ "/Накази кадрові тривалого зберігання/"+$folder
       $Url
       $Folder=$Context.Web.Folders.Add($Url)
            $Context.ExecuteQuery()
     }

     ForEach($folder in $foldersOrdersShortTerm)
     {
  
       $Url = $urlBus+ "/Накази тимчасового зберігання/"+$folder
       $Url
       $Folder=$Context.Web.Folders.Add($Url)
            $Context.ExecuteQuery()
     }

     ForEach($folder in $foldersBudgetPresentation)
     {
  
       $Url = $urlBus+ "/"+$folder
       $Url
       $Folder=$Context.Web.Folders.Add($Url)
            $Context.ExecuteQuery()
     }

 }

 $Url = "PersRecords/Накази кадрові тривалого зберігання/"+$folder
   $Url
   $Folder=$Context.Web.Folders.Add($Url)
        $Context.ExecuteQuery()