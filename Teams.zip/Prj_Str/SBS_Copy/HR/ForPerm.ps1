﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
 
Function Remove-SPOGroupPermissionsFromList()
{
  param
    (
        [Parameter(Mandatory=$true)] [string] $SiteURL,
        [Parameter(Mandatory=$true)] [string] $FolderURL,
        [Parameter(Mandatory=$true)] [string] $GroupName
    )
  
    Try {
        #Get credentials to connect
        $Cred= Get-Credential
        $Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)

        $LoginName ="spsitecoladm@smart-holding.com"
        $LoginPassword ="uZ#RJpSS2%U9!PR"

        $SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
        $Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)
  
        #Setup the context
        $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
        $Ctx.Credentials = $Credentials
        $Web = $Ctx.web

  
        #Get the Folder
        $Folder = $Web.GetFolderByServerRelativeUrl($FolderURL)
        $Ctx.Load($Folder)
        $Ctx.ExecuteQuery()
      
        #Break Permission inheritence - Keep all existing list permissions & Don't keep Item level permissions
        $Folder.ListItemAllFields.BreakRoleInheritance($True,$False)
        $Ctx.ExecuteQuery()
        Write-host -f Yellow "Folder's Permission inheritance broken..."
       
        #Get the SharePoint Site Group object
        $Group =$Web.SiteGroups.GetByName($GroupName)
        $Ctx.load($Group)
 
        #Get permissions assigned to the folder
        $Ctx.Load($Folder.ListItemAllFields.RoleAssignments)
        $Ctx.ExecuteQuery()
 
        #Check if the Group has permission on the list
        [Bool]$GroupFound = $False
        ForEach($RoleAssignment in $Folder.ListItemAllFields.RoleAssignments)
        {
            $ctx.Load($RoleAssignment.Member)
            $Ctx.ExecuteQuery()

            $RoleAssignment.Member.LoginName
 
            #remove Group permission from folder
            If($RoleAssignment.Member.PrincipalType -eq "SharePointGroup")
            {
                Write-Host "group" -ForegroundColor Yellow

                $Group =$Web.SiteGroups.GetByName($RoleAssignment.Member.LoginName)
                $Ctx.load($Group)
                $ObPerm =  $Group 
               
            }else 
            {
              Write-Host "user" -ForegroundColor green
              
              #Get the SharePoint User object from the site
              $User = $Web.EnsureUser($RoleAssignment.Member.LoginName)
              $Ctx.load($User)
              $ObPerm =  $User
            }
            if ($ObPerm -ne $null)
            {
             $Folder.ListItemAllFields.RoleAssignments.GetByPrincipal($ObPerm).DeleteObject()
             $Ctx.ExecuteQuery()
             $GroupFound = $True
             Write-host "Group Permissions Removed from the List Successfully!" -ForegroundColor Green  
             }
        }

        $Role = $Ctx.web.RoleDefinitions.GetByName("Совместная работа")
        $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
        $RoleDB.Add($Role)

        $User = $Ctx.Web.EnsureUser("testsh1@smart-holding.com")
        $Ctx.load($User)
        $Ctx.ExecuteQuery()

          $Group =$Web.SiteGroups.GetByName($GroupName)
  $Ctx.load($Group)
  $Ctx.ExecuteQuery()
 

           
        #Assign permissions
        $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
        $Folder.Update()

         #add sharepoint online group to folder using powershell
    $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
 
    #powershell add user to sharepoint online folder
    $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
    $Folder.Update()
    $Ctx.ExecuteQuery()
           

           $RoleDefColl=$Ctx.web.RoleDefinitions
        $Ctx.Load($RoleDefColl)
        $Ctx.ExecuteQuery()

         ForEach($RoleDef in $RoleDefColl)
        {
            Write-Host -ForegroundColor Green $RoleDef.Name
        }
        #If Group doesn't exist in list permissions
    }
    Catch {
       write-host -f Red "Error Removing Group permissions from the Folder!" $_.Exception.Message
    }
}
 
#Config Variables
$SiteURL="https://smartholdingcom.sharepoint.com/sites/testEmptySite"
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/sbs_hr"
$FolderURL="/sites/testEmptySite/testSearch1/ннннк"
$FolderURL="/sites/sbs_hr/test/еее"
$GroupName="Для теста видачі прав"
 
#Call the function to remove Group permissions from a list
Remove-SPOGroupPermissionsFromList -SiteURL $SiteURL -FolderURL $FolderURL -GroupName $Group