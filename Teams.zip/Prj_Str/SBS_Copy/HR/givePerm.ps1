﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"

#Variables for Processing
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/sbs_hr"

$permOnlyRead='Читання'
$permReadWrite='Участь'

class GroupPerm {
    [string]$Name   
    [string]$type
    [string]$PermLevel
}

class FolderPerm {
    [string]$UrlFolder
    [GroupPerm []]$PermMatr
   
}

Try {

    $LoginName ="spsitecoladm@smart-holding.com"
    $LoginPassword ="uZ#RJpSS2%U9!PR"

    $SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
    $Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)
 
    #Setup the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = $Credentials
    $Web = $Ctx.web
    $opp= Get-Content 'C:\Temp\crl_urls.json' | Out-String | ConvertFrom-Json
    $allPermissionLib=[FolderPerm []] (Get-Content 'C:\Temp\kadruFRegistrationLog.json' | Out-String | ConvertFrom-Json)

    Foreach($itemJson in $allPermissionLib)
    {
      Write-Host "Get Folder " $itemJson.UrlFolder
      $FolderURL = $itemJson.UrlFolder
      #Get the Folder
      $Folder = $Web.GetFolderByServerRelativeUrl($FolderURL)
      $Ctx.Load($Folder)
      $Ctx.ExecuteQuery()

      $Folder.ListItemAllFields.BreakRoleInheritance($False,$False) #Удаляє але залишає права на підпапки
      $Ctx.ExecuteQuery()
      Write-host -f Yellow "Folder's Permission inheritance broken..."

      $User = $Web.EnsureUser("spsitecoladm@smart-holding.com")
      $Ctx.load($User)
      $Folder.ListItemAllFields.RoleAssignments.GetByPrincipal($User).DeleteObject()
      $Ctx.ExecuteQuery()
      Write-host -f Yellow "Folder's Permission all delete ..."

      Foreach($itemPermF in $itemJson.PermMatr)
      {

        if($itemPermF.type -eq "Group")
        {
            $Group =$Web.SiteGroups.GetByName($itemPermF.Name)
            $Ctx.load($Group)
            $Ctx.ExecuteQuery()

            Write-Host $Group.Title -f Blue
            $Role = $Web.RoleDefinitions.GetByName($itemPermF.PermLevel)
            $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
            $RoleDB.Add($Role)

            $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
 
            $Folder.Update()
            $Ctx.ExecuteQuery()
            Write-Host "Yes!"
        }
      }
        
      

     <#$Group =$Web.SiteGroups.GetByName($itemJson.PermMatr[0].Name)
    $Ctx.load($Group)
    $Ctx.ExecuteQuery()
 
    #sharepoint online powershell set permissions on folder
    #Get the role required
    $Role = $web.RoleDefinitions.GetByName($itemJson.PermMatr[0].PermLevel)
    $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
    $RoleDB.Add($Role)
          
    #add sharepoint online group to folder using powershell
    $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
 
    $Folder.Update()
    $Ctx.ExecuteQuery()#>

      
    }
}
Catch {
    write-host -f Red "Error:" $_.Exception.Message
}