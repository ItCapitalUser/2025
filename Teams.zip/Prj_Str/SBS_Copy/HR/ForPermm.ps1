﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
 
#Variables for Processing
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/sbs_hr"

$permOnlyRead='Читання'
$permReadWrite='Участь'

class GroupPerm {
    [string]$NameGr
    [string]$PermLevel
   
}

class FolderPerm {
    [string]$UrlFolder
    [GroupPerm []]$PermMatr
   
}




$r = [FolderPerm]@{UrlFolder='/sites/sbs_hr/BudgetPresentation/Накази для нарахування (тривалого терміну)/';PermMatr=@(

       [GroupPerm]@{NameGr='Директор СБС';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Керівник Центр сервісів з управління персоналом';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Менеджер з бізнес процесів';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Керівник Відділу РЗП';PermLevel=$permReadWrite}
       [GroupPerm]@{NameGr='Менеджер відділу РЗП- СХ СБС ІФС Порт Очаків';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Головний спеціаліст РЗП- СЕ';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Головний спеціаліст РЗП- БНН';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Головний спеціаліст РЗП- Верес';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Головний спеціаліст РЗП- Віджи Трейд';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Головний спеціаліст РЗП- Наваль';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Головний спеціаліст РЗП- СМГ';PermLevel=$permOnlyRead})}

       $r = [FolderPerm]@{UrlFolder='/sites/sbs_hr/test/eee/';PermMatr=@(

       [GroupPerm]@{NameGr='Директор СБС';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Керівник Центр сервісів з управління персоналом';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Менеджер з бізнес процесів';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Керівник Відділу РЗП';PermLevel=$permReadWrite}
       [GroupPerm]@{NameGr='Менеджер відділу РЗП- СХ СБС ІФС Порт Очаків';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Головний спеціаліст РЗП- СЕ';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Головний спеціаліст РЗП- БНН';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Головний спеціаліст РЗП- Верес';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Головний спеціаліст РЗП- Віджи Трейд';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Головний спеціаліст РЗП- Наваль';PermLevel=$permOnlyRead}
       [GroupPerm]@{NameGr='Головний спеціаліст РЗП- СМГ';PermLevel=$permOnlyRead})}

$r.PermMatr.Count

for( $i=0; $i-le $r.PermMatr.Count; $i++){
    $r.PermMatr[$i].NameGr
}
$LoginName ="spsitecoladm@smart-holding.com"
$LoginPassword ="uZ#RJpSS2%U9!PR"

$SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
$Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)

        #Setup the context
$Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
$Ctx.Credentials = $Credentials
$Web = $Ctx.web

Write-Host -f Magenta "Start proces" $r.UrlFolder
$Folder = $Web.GetFolderByServerRelativeUrl($r.UrlFolder)
$Ctx.Load($Folder)
$Ctx.ExecuteQuery()
      
        #Break Permission inheritence - Keep all existing list permissions & Don't keep Item level permissions
$Folder.ListItemAllFields.BreakRoleInheritance($True,$False)
$Ctx.ExecuteQuery()
Write-host -f Yellow "Folder's Permission inheritance broken..."

#Get permissions assigned to the folder
$Ctx.Load($Folder.ListItemAllFields.RoleAssignments)
$Ctx.ExecuteQuery()

$ObPerm=$null

 ForEach($RoleAssignment in $Folder.ListItemAllFields.RoleAssignments)
{
     $Ctx.Load($RoleAssignment.Member)
     $Ctx.ExecuteQuery()

     $RoleAssignment.Member.LoginName
 
            #remove Group permission from folder
     If($RoleAssignment.Member.PrincipalType -eq "SharePointGroup")
     {
        Write-Host "group" -ForegroundColor Yellow

        $Group =$Web.SiteGroups.GetByName($RoleAssignment.Member.LoginName)
        $Ctx.load($Group)
        $ObPerm =  $Group 
               
      }
      else{
         Write-Host "user" -ForegroundColor green
              
         #Get the SharePoint User object from the site
         $User = $Web.EnsureUser($RoleAssignment.Member.LoginName)
         $Ctx.load($User)
         $ObPerm =  $User
       }
            
       if ($ObPerm -ne $null)
       {
           $Folder.ListItemAllFields.RoleAssignments.GetByPrincipal($ObPerm).DeleteObject()
           $Ctx.ExecuteQuery()
           $GroupFound = $True
            
        }
}

Write-host "Group Permissions Removed !" -ForegroundColor Green  

forEach($GroupPerm in $r.PermMatr)
{
  write-host "Start add Perm" $GroupPerm.NameGr " доступ " $GroupPerm.PermLevel

  $Role = $Ctx.web.RoleDefinitions.GetByName("Читання")
  $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
  $RoleDB.Add($Role)


  $Group =$Web.SiteGroups.GetByName("Менеджер відділу РЗП- СХ СБС ІФС Порт Очаків")
  $Ctx.load($Group)
  $Ctx.ExecuteQuery()

  $Group.Title

  $GroupPermissions  = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
    $Folder.Update()
    $Ctx.ExecuteQuery()
 

  write-host "Done! " $GroupPerm.NameGr -f Yellow
}

 $RoleDefColl=$Ctx.web.RoleDefinitions
        $Ctx.Load($RoleDefColl)
        $Ctx.ExecuteQuery()

         ForEach($RoleDef in $RoleDefColl)
        {
            Write-Host -ForegroundColor Green $RoleDef.Name
        }


ForEach($RoleAssignment in $Folder.ListItemAllFields.RoleAssignments)
{
     $Ctx.Load($RoleAssignment.Member)
     $Ctx.ExecuteQuery()

     $RoleAssignment.Member.LoginName
 

}