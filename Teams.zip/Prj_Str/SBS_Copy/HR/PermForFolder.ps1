﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
  
#Variables
$SiteURL="https://smartholdingcom.sharepoint.com/sites/testEmptySite" #Or https://crescent.sharepoint.com/sites/Marketing
$FolderURL="/sites/testEmptySite/testSearch1/Тест 02 група папок" #Or /sites/Marketing/Project Documents/Active - Server Relative URL of the Folder!
$GroupName="Для теста видачі прав"
$UserAccount="testsh1@smart-holding.com"
$PermissionLevel="Участь"

$SiteURL="https://smartholdingcom.sharepoint.com/sites/sbs_hr" #Or https://crescent.sharepoint.com/sites/Marketing

$FolderURL="/sites/sbs_hr/BudgetPresentation/Фінансування лікарняних (заявки+ повідомлення)/Група СУ"
$GroupName="Керівник Відділу РЗП"
$PermissionLevel="Contribute"
 
Try {
    $Cred= Get-Credential
    $Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)

    $LoginName ="spsitecoladm@smart-holding.com"
    $LoginPassword ="uZ#RJpSS2%U9!PR"

    $SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
    $Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)
 
    #Setup the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = $Credentials
    $Web = $Ctx.web
 
    #Get the Folder
    $Folder = $Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Break Permission inheritence of the folder - Keep all existing folder permissions & keep Item level permissions
    #$Folder.ListItemAllFields.BreakRoleInheritance($False,$True)
    #Break Permission inheritence - Keep all existing list permissions & Don't keep Item level permissions
    #$Folder.ListItemAllFields.BreakRoleInheritance($True,$False)

   $Folder.ListItemAllFields.BreakRoleInheritance($False,$False) #Удаляє але залишає права на підпапки
    $Ctx.ExecuteQuery()
    Write-host -f Yellow "Folder's Permission inheritance broken..."

    $User = $Web.EnsureUser("spsitecoladm@smart-holding.com")
    $Ctx.load($User)
    $Folder.ListItemAllFields.RoleAssignments.GetByPrincipal($User).DeleteObject()
    $Ctx.ExecuteQuery()
      
    #Get the SharePoint Group & User
    $Group =$Web.SiteGroups.GetByName($GroupName)
    $User = $Web.EnsureUser($UserAccount)
    $Ctx.load($Group)
    $Ctx.load($User)
    $Ctx.ExecuteQuery()
 
    #sharepoint online powershell set permissions on folder
    #Get the role required
    $Role = $web.RoleDefinitions.GetByName($PermissionLevel)
    $RoleDB = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Ctx)
    $RoleDB.Add($Role)
          
    #add sharepoint online group to folder using powershell
    $GroupPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($Group,$RoleDB)
 
    #powershell add user to sharepoint online folder
    $UserPermissions = $Folder.ListItemAllFields.RoleAssignments.Add($User,$RoleDB)
    $Folder.Update()
    $Ctx.ExecuteQuery()
     
    Write-host "Permission Granted Successfully!" -ForegroundColor Green  
}
Catch {
    write-host -f Red "Error Granting permission to  Folder!" $_.Exception.Message
}