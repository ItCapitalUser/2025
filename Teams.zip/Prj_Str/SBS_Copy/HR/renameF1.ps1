﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
  
#Variables
$SiteURL="https://smartholdingcom.sharepoint.com/sites/sbs_hr"
$FolderURL="/sites/sbs_hr/BudgetPresentation/Акти ЦПХ/Інвестиційний Фонд Смарт" #Server Relative URLs
$FolderNewURL="/sites/sbs_hr/BudgetPresentation/Акти ЦПХ/ІФС"
 
Try {
    $Cred= Get-Credential
    $Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)

    $LoginName ="spsitecoladm@smart-holding.com"
    $LoginPassword ="uZ#RJpSS2%U9!PR"

    $SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
    $Credential = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)
    $Ctx.Credentials = $Credential
 
    #Setup the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = $Credential
 
    #Get the Folder
    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
 
    Write-host -f Green "Folder has been renamed to new URL:"$FolderNewURL
}
Catch {
    write-host -f Red "Error Renaming Folder!" $_.Exception.Message
}

ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Виконавча служба/"+$item.Business


    $FolderURL="/sites/sbs_hr/BudgetPresentation/Виконавча служба/"  +$item.BusinessShort #Server Relative URLs
    $FolderNewURL="/sites/sbs_hr/BudgetPresentation/Виконавча служба/Група " +$item.BusinessShort

    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
    $FolderNewURL
  
 }

    ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Графіки виплати ЗП/"+$item.Business
   $FolderURL="/sites/sbs_hr/BudgetPresentation/Графіки виплати ЗП/"  +$item.BusinessShort #Server Relative URLs
    $FolderNewURL="/sites/sbs_hr/BudgetPresentation/Графіки виплати ЗП/Група " +$item.BusinessShort

    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
    $FolderNewURL
 }

     ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Довідки з ДПІ для банків - ЄСВ/"+$item.Business
   $FolderURL="/sites/sbs_hr/BudgetPresentation/Довідки з ДПІ для банків - ЄСВ/"  +$item.BusinessShort #Server Relative URLs
    $FolderNewURL="/sites/sbs_hr/BudgetPresentation/Довідки з ДПІ для банків - ЄСВ/Група "  +$item.BusinessShort

    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
    $FolderNewURL
 
 }


     ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Звітність по відпусткам ЧАЕС/"+$item.Business
  $FolderURL="/sites/sbs_hr/BudgetPresentation/Звітність по відпусткам ЧАЕС/"  +$item.BusinessShort #Server Relative URLs
    $FolderNewURL="/sites/sbs_hr/BudgetPresentation/Звітність по відпусткам ЧАЕС/Група " +$item.BusinessShort

    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
    $FolderNewURL
 
 }

      ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Інвентаризація резервів (річна)/"+$item.Business
  $FolderURL="/sites/sbs_hr/BudgetPresentation/Інвентаризація резервів (річна)/"  +$item.BusinessShort #Server Relative URLs
    $FolderNewURL="/sites/sbs_hr/BudgetPresentation/Інвентаризація резервів (річна)/Група " +$item.BusinessShort

    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
    $FolderNewURL
  
 }

      ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Листування з держорганами/"+$item.Business
  $FolderURL="/sites/sbs_hr/BudgetPresentation/Листування з держорганами/"  +$item.BusinessShort #Server Relative URLs
    $FolderNewURL="/sites/sbs_hr/BudgetPresentation/Листування з держорганами/Група " +$item.BusinessShort

    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
    $FolderNewURL
  
 }

      ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Установчі документи/"+$item.Business
  $FolderURL="/sites/sbs_hr/BudgetPresentation/Установчі документи/"  +$item.BusinessShort #Server Relative URLs
    $FolderNewURL="/sites/sbs_hr/BudgetPresentation/Установчі документи/Група " +$item.BusinessShort

    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
    $FolderNewURL
 }

 
      ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Накази для нарахування (тривалого терміну)/"+$item.Business
   $FolderURL="/sites/sbs_hr/BudgetPresentation/Накази для нарахування (тривалого терміну)/"  +$item.BusinessShort #Server Relative URLs
    $FolderNewURL="/sites/sbs_hr/BudgetPresentation/Накази для нарахування (тривалого терміну)/Група " +$item.BusinessShort

    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
    $FolderNewURL 
 }

 
      ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Утримання із ЗП/"+$item.Business
   $FolderURL="/sites/sbs_hr/BudgetPresentation/Акти ЦПХ/"  +$item.BusinessShort #Server Relative URLs
    $FolderNewURL="/sites/sbs_hr/BudgetPresentation/Акти ЦПХ/Група " +$item.BusinessShort

    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
    $FolderNewURL  
 }

 
      ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   $Url = "BudgetPresentation/Фінансування лікарняних (заявки+ повідомлення)/"+$item.Business
    $FolderURL="/sites/sbs_hr/BudgetPresentation/Фінансування лікарняних (заявки+ повідомлення)/"  +$item.BusinessShort #Server Relative URLs
    $FolderNewURL="/sites/sbs_hr/BudgetPresentation/Фінансування лікарняних (заявки+ повідомлення)/Група " +$item.BusinessShort

    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
    $FolderNewURL  

   
 }

 #region Кадровий облік
 $foldersPersDoc = @("Атестація робочих місць", "Довідки МСЕК", "Заяви на пільгу (ПСП)", "Дані про чорнобильців", "Табелі обліку робочого часу", "Лікарняні",
                    "Відрядження", "ЦПХ (договори)", "Графіки роб.часу", "Простої", "Донори", "Військовий облік", "Штатні розписи", "Журнали реєстрації", "Звіти", "Довідки",
                    "Відпустки", "Документи для оформлення на роботу","Прогули", "Накази по загальній діяльності",
                    "Скан. копії трудових книжок працівників")


$foldersOrdersLongTerm  = @("Прийом на роботу", "Переведення", "Звільнення", "Декретні відпустки", "Мобілізація і ТРО", "Відпустки без збереження",
                    "Припинення ТД", "Надурочні і вихідні дні", "Матдопомога (накази, заяви)")
                    
 ForEach ($item In $foldersPersDoc)
 {
    ForEach ($itemB In $arrBusiness)
   {
      Write-Host $item
      $FolderURL="/sites/sbs_hr/PersRecords/$($item)/" +$itemB.Business  #Server Relative URLs
      $FolderNewURL="/sites/sbs_hr/PersRecords/$($item)/Група " +$itemB.BusinessShort

      Write-Host $FolderURL -ForegroundColor Red
      $FolderNewURL

        $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
        $Ctx.Load($Folder)
        $Ctx.ExecuteQuery()
     
        #Rename Folder
        $Folder.MoveTo($FolderNewURL)
        $Ctx.ExecuteQuery()
        $FolderNewURL

   }
 }

       ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

    $FolderURL="/sites/sbs_hr/PersRecords/Накази тимчасового зберігання/Відпустки оплачувані/"  +$item.Business #Server Relative URLs
    $FolderNewURL="/sites/sbs_hr/PersRecords/Накази тимчасового зберігання/Відпустки оплачувані/Група " +$item.BusinessShort

    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
    $FolderNewURL  

   
 }

ForEach ($item In $arrBusiness)
 {
   Write-Host $item.Business

   ForEach($innnerFolder in $foldersOrdersLongTerm){

    $FolderURL="/sites/sbs_hr/PersRecords/Накази кадрові тривалого зберігання/" +$innnerFolder+ "/" +$item.Business #Server Relative URLs
    $FolderNewURL="/sites/sbs_hr/PersRecords/Накази кадрові тривалого зберігання/"+$innnerFolder+ "/Група " +$item.BusinessShort

    $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($FolderURL)
    $Ctx.Load($Folder)
    $Ctx.ExecuteQuery()
     
    #Rename Folder
    $Folder.MoveTo($FolderNewURL)
    $Ctx.ExecuteQuery()
    $FolderNewURL  
    }
   
 }