﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
 
#Variables for Processing
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/sbs_recr"


$LoginName ="spsitecoladm@smart-holding.com"
$LoginPassword ="uZ#RJpSS2%U9!PR"
 
 
#Get the Client Context
$Context = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
 
#supply Login Credentials
$SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
$Credential = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)
$Context.Credentials = $Credential

Function Create-DocumentLibrary()
{
    param
    (
        [Parameter(Mandatory=$true)] [string] $SiteURL,
        [Parameter(Mandatory=$true)] [string] $DocLibraryName,
        [Parameter(Mandatory=$true)] [string] $DocLibraryUrl

    )    
    Try {
    #Setup Credentials to connect
 
    #Set up the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL) 
    $Ctx.Credentials = $Credential
 
    #Get All Lists from the web
    $Lists = $Ctx.Web.Lists
    $Ctx.Load($Lists)
    $Ctx.ExecuteQuery()
  
    #Check if Library name doesn't exists already and create document library
    if(!($Lists.Title -contains $DocLibraryName))
    { 
        #create document library in sharepoint online powershell
        $ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
        $ListInfo.Title = $DocLibraryName
        $ListInfo.Url=$DocLibraryUrl
        $ListInfo.TemplateType = 101 #Document Library
        $List = $Ctx.Web.Lists.Add($ListInfo)
        $List.Update()
        $Ctx.ExecuteQuery()

        $List =  $Ctx.Web.Lists.GetByTitle($DocLibraryName);
        $List.OnQuickLaunch = 1;
        $List.Update()
        $Ctx.ExecuteQuery()
   
        write-host  -f Green "New Document Library has been created!"
    }
    else
    {
        Write-Host -f Yellow "List or Library '$DocLibraryName' already exist!"
    }
}
Catch {
    write-host -f Red "Error Creating Document Library!" $_.Exception.Message
}
}

Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Підбір персоналу" -DocLibraryUrl "Recruitment"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Адаптація" -DocLibraryUrl "Onboarding"

#region Recruitment/Регламентація
 $Url = "Recruitment/Регламентація"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Регламентація/Регламенти та бізнес процеси"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/Регламентація/Модель ціноутворення"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/Регламентація/Шаблони"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
#endregion

#region Recruitment/База резюме
 $Url = "Recruitment/База резюме"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/База резюме/HR"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/IT"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/CEO"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/CFO"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/Controlling"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/IFRS"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/Investment"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/Audit"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/CF"
 $Folder=$Context.Web.Folders.Add($Url)

 $Url = "Recruitment/База резюме/Treasury"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/Accounting"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/Tax"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/Strategy"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/Lawyer"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/Marketing"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/PM"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/Admin"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/База резюме/Sales"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/База резюме/Other"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
#endregion

#region Recruitment/Вакансії
 $Url = "Recruitment/Вакансії"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Вакансії/СБС"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Вакансії/СБС/СБС"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Вакансії/СБС/ІТК"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Вакансії/СХ"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Вакансії/ІФС"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Вакансії/ІФС/СОТОН"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Вакансії/ІФС/СГ"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

  $Url = "Recruitment/Вакансії/ІФС/ПЕЛЛЕГРІН"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Вакансії/СУ"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Вакансії/ВЕРЕС"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Вакансії/СЕ"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Вакансії/ФО"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Вакансії/Інші"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
#endregion

#region Recruitment/Пропозиції про роботу
 $Url = "Recruitment/Пропозиції про роботу"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Пропозиції про роботу/СБС"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Пропозиції про роботу/СБС/СБС"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Пропозиції про роботу/СБС/ІТК"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Пропозиції про роботу/СХ"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Пропозиції про роботу/ІФС"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Пропозиції про роботу/ІФС/СОТОН"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Пропозиції про роботу/ІФС/СГ"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

  $Url = "Recruitment/Пропозиції про роботу/ІФС/ПЕЛЛЕГРІН"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Пропозиції про роботу/СУ"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Пропозиції про роботу/ВЕРЕС"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Пропозиції про роботу/СЕ"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Пропозиції про роботу/ФО"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Пропозиції про роботу/Інші"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
#endregion

 $Url = "Recruitment/Анкети СБ"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
 $Url = "Recruitment/Статус_звіт"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 
#region Recruitment/Вакансії
 $Url = "Recruitment/Контрагенти"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Контрагенти/Внутрішні"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Контрагенти/Внутрішні/СБС"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Контрагенти/Внутрішні/СХ"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Контрагенти/Внутрішні/ІФС"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Контрагенти/Внутрішні/СУ"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Контрагенти/Внутрішні/ВЕРЕС"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Контрагенти/Внутрішні/СЕ"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Контрагенти/Внутрішні/ФО"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Контрагенти/Внутрішні/Інші"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

  $Url = "Recruitment/Контрагенти/Зовнішні"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Контрагенти/Зовнішні/GRC"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Контрагенти/Зовнішні/RABOTA"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Контрагенти/Зовнішні/JANSEN"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Контрагенти/Зовнішні/WORK"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Контрагенти/Зовнішні/LINKEDIN"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

  $Url = "Recruitment/Контрагенти/Зовнішні/EXECUTIVE SEARCH"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Контрагенти/Зовнішні/FAMILY OFFICE_Agencies"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()

 $Url = "Recruitment/Контрагенти/Зовнішні/OTHER COMPANIES"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
#endregion

#region Recruitment/Інше
$Url = "Recruitment/Інше"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Інше/Бюджет"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Recruitment/Інше/Робочі матеріали_рекрутинг"
 $Folder=$Context.Web.Folders.Add($Url)
  $Context.ExecuteQuery()
  #endregion

  #region Onboarding/Інше
$Url = "Onboarding/Регламентація"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Onboarding/Регламентація/Регламенти та бізнес процеси"
 $Folder=$Context.Web.Folders.Add($Url)
 $Context.ExecuteQuery()
 
 $Url = "Onboarding/Регламентація/Вихідне інтерв'ю"
 $Folder=$Context.Web.Folders.Add($Url)
  $Context.ExecuteQuery()

   $Url = "Onboarding/Регламентація/Анонси виходів кандидатів"
 $Folder=$Context.Web.Folders.Add($Url)
  $Context.ExecuteQuery()
  #endregion