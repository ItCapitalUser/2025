﻿#Load SharePoint CSOM Assemblies
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
 
#Variables for Processing
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/it_hub"


$LoginName ="vira.chorna@it-capital.com.ua"
$LoginPassword ="#npw24Pars"
 
#Get the Client Context
$Context = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
 
#supply Login Credentials
$SecurePWD = ConvertTo-SecureString $LoginPassword -asplaintext -force 
$Credential = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($LoginName,$SecurePWD)
$Context.Credentials = $Credential

Function Create-DocumentLibrary()
{
    param
    (
        [Parameter(Mandatory=$true)] [string] $SiteURL,
        [Parameter(Mandatory=$true)] [string] $DocLibraryName,
        [Parameter(Mandatory=$true)] [string] $DocLibraryUrl

    )    
    Try {
    #Setup Credentials to connect
 
    #Set up the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL) 
    $Ctx.Credentials = $Credential
 
    #Get All Lists from the web
    $Lists = $Ctx.Web.Lists
    $Ctx.Load($Lists)
    $Ctx.ExecuteQuery()
  
    #Check if Library name doesn't exists already and create document library
    if(!($Lists.Title -contains $DocLibraryName))
    { 
        #create document library in sharepoint online powershell
        $ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
        $ListInfo.Title = $DocLibraryName
        $ListInfo.Url=$DocLibraryUrl
        $ListInfo.TemplateType = 101 #Document Library
        $List = $Ctx.Web.Lists.Add($ListInfo)
        $List.Update()
        $Ctx.ExecuteQuery()

        $List =  $Ctx.Web.Lists.GetByTitle($DocLibraryName);
        $List.OnQuickLaunch = 1;
        $List.Update()
        $Ctx.ExecuteQuery()
   
        write-host  -f Green "New Document Library has been created!"
    }
    else
    {
        Write-Host -f Yellow "List or Library '$DocLibraryName' already exist!"
    }
}
Catch {
    write-host -f Red "Error Creating Document Library!" $_.Exception.Message
}
}
 
#powershell create document library sharepoint online
$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "Бюджетування"
$ListInfo.Url="Lists/Budgeting"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
#$List.Description = "Repository to store project artifacts"
$List.Update()
$Context.ExecuteQuery()

$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "Основні засоби/Активи"
$ListInfo.Url="Lists/FixedAssets"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
$List.Update()
$Context.ExecuteQuery()

$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "Нематеріальні активи"
$ListInfo.Url="Lists/IntangAssets"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
$List.Update()
$Context.ExecuteQuery()

$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "Q&A"
$ListInfo.Url="Lists/Q&A"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
$List.Update()
$Context.ExecuteQuery()
 
write-host "New Document Library has been created!"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Управління постачальниками" -DocLibraryUrl "SupplierManagement"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Board Maps" -DocLibraryUrl "BoardMaps"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "ІС Infobot" -DocLibraryUrl "Infobot"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "ІС Аналітичне хранилище" -DocLibraryUrl "AnalyticalStorage"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "ІС Перевірка Контрагентів" -DocLibraryUrl "CheckCounterparties"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "ІС Fabrikant" -DocLibraryUrl "Fabrikant"


#inf
$SiteURL = "https://smartholdingcom.sharepoint.com/sites/it_inf"
$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "Microsof 365 Platform"
$ListInfo.Url="Lists/Ms365Platform"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
$List.Update()
$Context.ExecuteQuery()

$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "Microsoft Cloud"
$ListInfo.Url="Lists/MsCloud"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
$List.Update()
$Context.ExecuteQuery()

$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "McAfee"
$ListInfo.Url="Lists/McAfee"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
$List.Update()
$Context.ExecuteQuery()

$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "Сервисы аутентификации пользователей (AD, AD FS, MFA, Azure AD Connect). Облачная инфраструктура"
$ListInfo.Url="AAD"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
$List.Update()
$Context.ExecuteQuery()

$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "Сервисы аутентификации пользователей (AD). Наземная инфраструктура"
$ListInfo.Url="AD"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
$List.Update()
$Context.ExecuteQuery()

$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "Инфраструктура выдающих центров сертификации (PKI)"
$ListInfo.Url="PKI"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
$List.Update()
$Context.ExecuteQuery()

$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "Сервисы DNS"
$ListInfo.Url="DNS"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
$List.Update()
$Context.ExecuteQuery()

$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "Сервисы DHCP"
$ListInfo.Url="DHCP"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
$List.Update()
$Context.ExecuteQuery()

$ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
$ListInfo.Title = "Терминальные фермы"
$ListInfo.Url="TerminalFarms"
$ListInfo.TemplateType = 101 #Document Library
$List = $Context.Web.Lists.Add($ListInfo)
$List.Update()
$Context.ExecuteQuery()

Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "ELK" -DocLibraryUrl "ELK"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Файловые ресурсы" -DocLibraryUrl "FileResour"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Сервисы управления конечных устройств(SCCM,SCOM)" -DocLibraryUrl "SCOM"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Сервисы распространения ПО (DP SCCM)" -DocLibraryUrl "DPSCCM"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Сервисы бекапирования файловых ресурсов (DPM)" -DocLibraryUrl "DPM"

Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Сервисы KMS, MBAM" -DocLibraryUrl "KMS"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Сервисы печати (инфраструктура ПО)" -DocLibraryUrl "ServPrint"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "PBX Panasonic" -DocLibraryUrl "PBXPanasonic"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Сервер Cisco VCS" -DocLibraryUrl "CiscoVCS"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Сервер Cisco BE6000" -DocLibraryUrl "CiscoBE6000"

Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "Корпоративная сеть" -DocLibraryUrl "СorpNetwork"
Create-DocumentLibrary -siteURL $SiteURL -DocLibraryName "OpenNMS Horizon Мониторинг" -DocLibraryUrl "OpenNMSHorizon"